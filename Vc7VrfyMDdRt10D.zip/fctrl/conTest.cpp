//03.05.6 ClI.Port
#include <kcommon.h>

int factorial(int inAg)
{
    if ( inAg >= 1){
        return inAg * factorial(inAg - 1);
    }else{
        return 1;
    }
}

#ifdef DfVrfy
#include <VrfyLib.h>
using namespace std;
using namespace kk;

int inResultStt;
void testFunction(int inAg)
{
    inResultStt = factorial(inAg);
}

static class ClTestVctD : public ClVfLibActn {
  public:
  protected:
    virtual void doAtInitialVl( const std::string& crStrAg);
} clTestVctDStt;

void ClTestVctD::doAtInitialVl( const string& crStrAg)
{

    if ( IsSameNocase(crStrAg,"test.vrf") 
      || IsSameNocase(crStrAg,"v\\testFactorial.vrf") 
    ){
        cout << "now in ClTestVctD::doAtInitial(.):" << crStrAg << endl;
        ClTestVct::doAtInitialVl(crStrAg);  // open crStrAg file
        kcout << "Now verifying input file is " << crStrAg << " in main.cpp" << endl;

        RgstVerified(this, tfNewVerified(inResultStt, "inResultStt") );
        RgstVerified(this, tfNewVfFnctn(testFunction, "testFunction") );
    }
}

#endif //DfVrfy
