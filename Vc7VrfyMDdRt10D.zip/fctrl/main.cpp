#include<Verifier.h>
#include<TestVct.h>
#include<string>
#include<iostream>
#include <Windows.h>
#ifdef DfVC_
#   include <crtdbg.h>
#endif  // DfVC_

using namespace std;
using namespace kk;

static kstring strErrorThrowedStt(_T("") );


int main(int argc, char** argv)
{
    try{
        return ClVrfySglt::GetStt()->Main(argc, argv);
    }catch(ClError* pClError){
        strErrorThrowedStt = pClError->m_strCst;
        cout << "Execption Error: " << pClError->m_strCst << endl;
        delete pClError;
        return 1;
    }
}


TyByte Port0;
