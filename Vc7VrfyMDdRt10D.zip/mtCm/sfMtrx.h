/*   ���̃v���O�����̒��쌠�� kVerifeir Lab ���ь������ۗL���܂��B ���̃v���O������
 * ����Ă����Ȃ��Q�E�������������Ă��A��҂͈�ؐӔC�𕉂��܂���B���̃v���O����
 * ��񎟔z�z���邽�߂ɂ� kVerifeir Lab ���ь����̕����ɂ�鏳����K�v�Ƃ��܂��B
 *   ���̃v���O�������z�z���ꂽ zip �t�@�C�����̂��̂�F�l�ɃR�s�[���ēn�����Ƃ͔F
 * �߂܂����A�l�b�g��ŕs���葽���ɔz�z���邱�Ƃ͂��~�߂��������B
 *
 *    �]�����Ԉꃖ���𒴂��Ă��̃v���O�������g�p����ɂ̓\�t�g�g�p���̎x�������K�v��
 *  ���B�ڍׂ� http://www.nasuinfo.or.jp/FreeSpace/kenji/���Q�Ƃ��邩�A
 *      kenji@nasuinfo.or.jp ���� kverifierlab@yahoo.co.jp\n
 *  �ɂ��q�˂��������B"
 */


#ifndef DfSf_H__
#define DfSf_H__

#include <fstream>
#include "matrix.h"
#include "kcommon.h"

namespace kk{

template<class T>
std::string tfGetStrValWtDlmt(const std::valarray<T>& crVlrAg)
{
    std::ostringstream ostrmAt;
    for ( size_t sztAt=0; sztAt<crVlrAg.size();sztAt++){
        if ( sztAt < crVlrAg.size() - 1 ){
            ostrmAt << crVlrAg[sztAt] << ", ";
        }else{
            ostrmAt << crVlrAg[sztAt];
        }
    }
    return ostrmAt.str();
}

template<class T>
class TcSfMtrx{
  protected:
  public:
    size_t m_sztColumn; // if 1x1 matrix then m_sztColumn==1, m_sztRow==1
    size_t m_sztRow;    //  not m_sztColumn==0, m_sztRow==0
  public:
    std::valarray<T>& m_rVlrT;

    //============== constructor ==============================
    /*explicit*/ TcSfMtrx<T>(TcSfMtrx<T>& crVlrAg )
        : m_rVlrT(crVlrAg.m_rVlrT), m_sztColumn(crVlrAg.m_sztColumn)
        , m_sztRow(crVlrAg.m_sztRow){}

    TcSfMtrx<T>(std::valarray<T>& crVlrAg, size_t sztColAg, size_t sztRowAg)
    :m_rVlrT(crVlrAg), m_sztColumn(sztColAg), m_sztRow(sztRowAg)
    {
        assert(crVlrAg.size() == sztColAg * sztRowAg);
    }

    //<============== operator ==============================
    //< operation results are saved in m_rVlrT

    void Add( const TcSfMtrx<T>& crTmAg)
    {
        assert(m_rVlrT.size() == crTmAg.m_rVlrT.size());
        m_rVlrT += crTmAg.m_rVlrT;
    }

    void Minus( const TcSfMtrx<T>& crTmAg)
    {
        assert(m_rVlrT.size() == crTmAg.m_rVlrT.size());
        m_rVlrT -= crTmAg.m_rVlrT;
    }

    void Multiply( const TcSfMtrx<T>& crTmAg)
    {
        assert(m_sztRow == crTmAg.m_sztColumn);

        size_t sztRowAt;
        sztRowAt = m_sztRow;
        std::valarray<T> vlrAt(m_rVlrT);
        m_sztRow = crTmAg.m_sztRow;
        m_rVlrT.resize(m_sztColumn * m_sztRow);
        for (size_t i=0; i< m_sztColumn;++i ){
            for (size_t j=0; j<crTmAg.m_sztRow; ++j){
                T tmpAt(0);
                for (size_t k=0; k<sztRowAt; ++k){
                    tmpAt += vlrAt[i*sztRowAt + k] * crTmAg.m_rVlrT[k*m_sztRow + j];
#if 0   //debugX
                    T tAt=0;
                    tAt += vlrAt[i*sztRowAt + k] * crTmAg.m_rVlrT[k*m_sztRow + j];
                    cout << "Debug: " << "i:="<< i << " j=:" << j
                            << " k=:" << k << "  T=:"<< tAt
                            << " m_rVlrT[i*inRowAt+k]:" << m_rVlrT[i*sztRowAt + k]
                            << " crTmAg.m_rVlrT[k*m_inRow+j]:" << crTmAg.m_rVlrT[k*m_sztRow + j]
                            << endl;
#endif  // deubgX
                }
                m_rVlrT[i*m_sztRow + j] = tmpAt;
            }
        }
        //cout << "Debug:" << tfGetStrVal(m_rVlrT) << endl;   //to debug
    }

    void Multiply( const std::valarray<T>& crVlrAg)
    {
        kAssert("m_inColumn <= 0 at matrix*vector operation.", m_sztColumn > 0);
        kAssert("m_inRow != vector size at matrix*vector.", m_sztRow == crVlrAg.size() );
        std::valarray<T> vlrAt(m_rVlrT);
        m_rVlrT.resize(m_sztColumn, 0); // don't initialize by 0 at Vc7
        m_rVlrT = 0;
        for (size_t i=0; i< m_sztColumn;i++ ){
            //cout << "m_rVlrT:" << tfGetStrVal(m_rVlrT) << endl; // to debug
            for (size_t j=0; j<m_sztRow; j++){
                m_rVlrT[i] += vlrAt[i*m_sztRow + j] * crVlrAg[j];
            }
            //cout << "m_rVlrT:" << tfGetStrVal(m_rVlrT) << endl; // to debug
        }       
    }

};

template<class T>
class TcSfMtrxInvs{
  public:
    enum EnmState{ EnInitial = 0, EnLessThanMinPivot, EnDecomposed, EnInverted } m_enState;

    std::valarray<T> m_vlrT;
    T                m_determinantT;
    TcSfMtrx<T>*     m_pTcSfMtrx;

    TcSfMtrxInvs(size_t sztMtrxRowAg = 0):m_enState(EnInitial)
    {
        m_vlrT.resize( sztMtrxRowAg * sztMtrxRowAg );
        m_vlrT = 0;
        m_pTcSfMtrx = new TcSfMtrx<T>(m_vlrT, sztMtrxRowAg, sztMtrxRowAg);
    }

    TcSfMtrxInvs(const TcSfMtrxInvs& crTcSfMtrxInvsAg)
    {
        size_t sztMtrxRowAt = crTcSfMtrxInvsAg.m_pTcSfMtrx->m_sztRow;
        size_t sztMtrxColumnAt = crTcSfMtrxInvsAg.m_pTcSfMtrx->m_sztColumn;

        m_vlrT.resize( sztMtrxRowAt * sztMtrxColumnAt );
        m_vlrT = crTcSfMtrxInvsAg.m_vlrT;
        m_determinantT = crTcSfMtrxInvsAg.m_determinantT;
        m_pTcSfMtrx = new TcSfMtrx<T>(m_vlrT, sztMtrxRowAt, sztMtrxRowAt);
        m_enState = crTcSfMtrxInvsAg.m_enState;
    }

    TcSfMtrxInvs& operator = ( const TcSfMtrxInvs& crTcSfMtrxInvsAg)
    {
        m_enState = crTcSfMtrxInvsAg.m_enState;
        m_pTcSfMtrx->m_sztRow = crTcSfMtrxInvsAg.m_pTcSfMtrx->m_sztRow;
        m_pTcSfMtrx->m_sztColumn = crTcSfMtrxInvsAg.m_pTcSfMtrx->m_sztColumn;

        m_vlrT.resize( m_pTcSfMtrx->m_sztRow * m_pTcSfMtrx->m_sztColumn );
        m_vlrT = crTcSfMtrxInvsAg.m_vlrT;
        m_determinantT = crTcSfMtrxInvsAg.m_determinantT;
        return *this;
    }

    virtual ~TcSfMtrxInvs()
    {
        delete m_pTcSfMtrx;
    }
};

class ClTerm{
  public:
    std::valarray<double>            m_vlrDb;
    std::valarray<std::complex<double> >  m_vlrCplxDb;

    TcSfMtrx<double>*           m_pTcSfMtrxDb;      //!< if m_pTcSfMtrxDb = 0, m_vlrDb is vector not matrix
    TcSfMtrx<std::complex<double> >*   m_pTcSfMtrxCplxDb;//!< if m_pTcSfMtrxCplxDb = 0, m_vlrCmplxDb is vector not matrix

    int m_inStart;
    int m_inSize;
    int m_inStride;

    //!< m_blNumber:true indicates only number term, not fileName term or parentic term
    //!< Insert + operator if m_blNumber is true and there are no operaotr for 2 scalar terms
    //static bool m_blNumberStt;

    bool m_blCmplx;      //<! complex value indicator

    //! m_strVarName represents variable file name. It is needed to write back LU decomposed data.
    std::string m_strVarName;

    TcSfMtrxInvs<double>*                 m_pTcSfMtrxInvs;
    TcSfMtrxInvs<std::complex<double> >*  m_pTcSfMtrxInvsCplx;

    ClTerm(const std::string crStrAg="") : m_pTcSfMtrxDb(0), m_pTcSfMtrxCplxDb(0), m_inStart(0), m_inSize(0)
                 , m_inStride(0), m_blCmplx(false), m_pTcSfMtrxInvs(0), m_pTcSfMtrxInvsCplx(0), m_strVarName(crStrAg){}
#if 0
    // clTermLeftAt �̌��ʂ� rClResultAg �ɃR�s�[����āA�Ō�ɏo�͂����B
    // �o�͂���I���܂ł� m_pTcSfMtrxDb�E�E�Ȃǂ͑��݂��Ă��Ȃ���΂Ȃ�Ȃ�
    // 03.04.14
    ~ClTerm()
    {
        delete m_pTcSfMtrxDb;
        delete m_pTcSfMtrxCplxDb;
        delete m_pTcSfMtrxInvs;
        delete m_pTcSfMtrxInvsCplx;
    }
#endif
    virtual void ConvertFileToValue(const std::string& crStrFileNameAg);
    //! crClTermRightAt may may be changed from real to complex
    void CalculateFourOperations( const std::string& crStrOperatorAg, ClTerm& crClTermRightAt);
    void CalculateUnitaryMathFnctn( const std::string& crStrOperatorAg, ClTerm& crClTermAG);
    //! ClTerm instance instance clTermRsltValStt is used a number of time, so Initialize() is needed
    //! may generate statistically. It may be 
    void Initialize(void);
    //! rClTermAg class pointer may be copied and delteed and 0 assigned;
    ClTerm& operator = ( ClTerm& rClTermAg);
  protected:
    void makeMatrix(bool blComcples_RealAg, size_t columnAg, size_t rowAg);
    void readInverted(std::ifstream&, size_t sztRowAg);
    void readCplxInverted(std::ifstream&, size_t sztRowAt);

    virtual std::string getStrFileVal(size_t);
    virtual void getStrConsoleVal(size_t);
    std::list<std::string> m_lstStrConsole;
    size_t m_sztConsoleStrLengthMax;
  public:
    static int m_inPrecisionStt;
    static bool m_blPrintStt;
    static bool m_blIniStt;     //!< readSfIniFile() �̍Œ��ł��邱�Ƃ��Ӗ�����t���O�ł�
    static bool IsAbleToPrintStt(void)
    {
        return m_blPrintStt && !m_blIniStt;
    }

    static double m_dbTinyStt;

    static double m_dbZeroSuppressStt;
    static double m_inZeroSuppressStt;

    virtual void PrintTerm(bool blDefaultPrintAg=true);
};

/*!
   1 ClTempVar �� ClTerm* �̃��X�g��ێ�����
   2 ClTempVar* �̃��X�g�� ClTmpVar::m_lstpClTmpVarStt �ɕێ�������
     <-- ClTempVar �� constructor �� this ClTempVar* �� m_lstpClTmpVarStt �� front push
     <-- processAtFileName(.) ����� <<start, size, stride @tempVar| operation>> ���J�n�Ƃ���
        ClTempVar auto �C���X�^���X�����A����ɁATemporary �� ClTemm instance pointer ��ێ�������

  ��          ��<<start,size,strid @t|...>> �̃��[�v�������J�n���钼�O
  ��clTmpVarAt����> ClTerm* list .....
  ��    ��    ��
  ��    ��    ��processAtFileName(strAt, kr rClTermResultAg); �̒��O
  ��clTmpVarAt����> ClTerm* list .....
  ��    ��    ��
  ��    ��    ��main �J�n
  ��clTmpVarAt����> ClTerm* list .....
  ��    ��    ��
  ��    ������������ list<ClTmpVar*> ClTmpVar::m_lstpClTmpVarStt;
  �� stack    ��
!*/

class ClTmpVar{
  public:
    std::list<ClTerm*> m_lstpClTerm;
    //! to control repeater scope variable scope
    static std::list<ClTmpVar*> m_lstpClTmpVarStt;
    //static PushStt(void);
    //static PopStt(void);

    //! constructor push this for m_lstpClTmpVarStt
    ClTmpVar(void);
    //! destructor pop from m_lstpClTmpVarStt
    virtual ~ClTmpVar(void);
    //! If there isn't indicated temporary variable, then return 0 pointer
    static ClTerm* GetTmpVarStt(const std::string& crStrAg
        , std::list<ClTmpVar*>::iterator itrAg = m_lstpClTmpVarStt.begin());
    static bool RegistStt(const std::string& crStrTermAg);
    static void DoAtExitStt(void);
};

void GetRightSideVal(const std::string& crStrResidualAg, ClTerm& rClResultAg);
bool ExecuteChildProcess(const char* cpChCommandAg, int inSizeAg);
inline double GetTinyPivot(void){return ClTerm::m_dbTinyStt;};

}   //namespace kk

#endif  //DfSf_H__
