/*   ���̃v���O�����̒��쌠�� kVerifeir Lab ���ь������ۗL���܂��B ���̃v���O������
 * ����Ă����Ȃ��Q�E�������������Ă��A��҂͈�ؐӔC�𕉂��܂���B���̃v���O����
 * ��񎟔z�z���邽�߂ɂ� kVerifeir Lab ���ь����̕����ɂ�鏳����K�v�Ƃ��܂��B
 *   ���̃v���O�������z�z���ꂽ zip �t�@�C�����̂��̂�F�l�ɃR�s�[���ēn�����Ƃ͔F
 * �߂܂����A�l�b�g��ŕs���葽���ɔz�z���邱�Ƃ͂��~�߂��������B
 *
 *    �]�����Ԉꃖ���𒴂��Ă��̃v���O�������g�p����ɂ̓\�t�g�g�p���̎x�������K�v��
 *  ���B�ڍׂ� http://www.nasuinfo.or.jp/FreeSpace/kenji/���Q�Ƃ��邩�A
 *      kenji@nasuinfo.or.jp ���� kverifierlab@yahoo.co.jp\n
 *  �ɂ��q�˂��������B"
 */
#ifndef DfJacobi_H_
#define DfJacobi_H_

#include<kcommon.h>
#include<kAssert.h>
#include<assert.h>
#include<algorithm>
#include<iostream>
#include<valarray>
#include<complex>
#include<cmath>

#ifdef DfVrfy
#   include <Verifier.h>
#endif

using namespace std;

#include <sfMtrx.h>


namespace kk{
static int cInMaxLoopStt = 50;

static double square(double dbAg)
{
    return dbAg*dbAg;
}

static double square(complex<double> dbAg)
{
    return dbAg.imag()*dbAg.imag() + dbAg.real()*dbAg.real();
}


template<class T>
double tfAddSquare(const std::valarray<T>& crVlrAg)
{
    double dbAt = 0;
    for (size_t sztAt=0; sztAt< crVlrAg.size(); ++sztAt){
        dbAt += square(crVlrAg[sztAt]);
    }
    return dbAt;
}

template<class T>
void tfJacobiReal(const std::valarray<T>& crVlrHermiteMatrixAg
    , std::valarray<T>& rVlrEigenValAg, std::valarray<T>& rVlrEigenVctMtAg)
{   
    size_t sztRowAt = static_cast<size_t>(   sqrt( double(crVlrHermiteMatrixAg.size()) )   );
    kAssert("Your matrix argment is not square matrix."
            , crVlrHermiteMatrixAg.size() == sztRowAt*sztRowAt);
    rVlrEigenValAg.resize(sztRowAt,T(0));
    rVlrEigenValAg = valarray<T>(crVlrHermiteMatrixAg[slice(0,sztRowAt, sztRowAt+1)]);   // Set Diagonal elemnet

    rVlrEigenVctMtAg.resize(sztRowAt*sztRowAt,T(0));
    rVlrEigenVctMtAg[slice(0,sztRowAt, sztRowAt+1)]
            = valarray<T>(T(1), sztRowAt);              // set unit matrix

    valarray<T> vlrOffDiagonalMtAt(crVlrHermiteMatrixAg);

    // Sweep loop
    for(int i=0; i<cInMaxLoopStt; ++i){

        valarray<T> vlrDiagonalAt(rVlrEigenValAg);
        valarray<T> vlrResidualDiagonalAt( T(0.0), rVlrEigenVctMtAg.size());

        vlrOffDiagonalMtAt[slice(0,sztRowAt, sztRowAt+1)]
                = valarray<T>(T(0), sztRowAt);              // set 0 diagonal element
        //cout << "vlrOffDiagonalMtAt first: " << tfGetStrVal(vlrOffDiagonalMtAt) << endl;  // to debug
        //cout << "rVlrEigenValAg: " << tfGetStrVal(rVlrEigenValAg) << endl;  // to debug
        
        double dbSquareSumAt = tfAddSquare(vlrOffDiagonalMtAt);
        if ( dbSquareSumAt == 0){
            return;
        }
        //cout << "dbSquareSumAt: " << dbSquareSumAt << endl; // to debug

        double dbThresholdAt;
        if ( i < 4){
            dbThresholdAt = 0.04 * dbSquareSumAt / (sztRowAt*sztRowAt);
        }else{
            dbThresholdAt = 0;
        }

        //! Rotation loop
        for (size_t p=0; p<sztRowAt; ++p){
            for (size_t q=p+1; q<sztRowAt; ++q){
                //cout << "i: " << i << "    p: " << p << "   q: " << q << endl;    // to debug
                //double dbCriterionAt = 100.0 * sqrt(square(vlrOffDiagonalMtAt[p*sztRowAt+q]));
                double dbCriterionAt = sqrt(square(vlrOffDiagonalMtAt[p*sztRowAt+q]));
                if ( (i > 4)
                  && (  (square(vlrDiagonalAt[p]) + dbCriterionAt) == square(vlrDiagonalAt[p]) )
                  && (  (square(vlrDiagonalAt[q]) + dbCriterionAt) == square(vlrDiagonalAt[q]) )
                ){
                    vlrOffDiagonalMtAt[p*sztRowAt + q] = T(0);
                    vlrOffDiagonalMtAt[q*sztRowAt + p] = T(0);
                }else if ( square(vlrOffDiagonalMtAt[p*sztRowAt + q]) > dbThresholdAt){
                    T tDifferenceAt = vlrDiagonalAt[q] - vlrDiagonalAt[p];
                    T t;
                    if ( sqrt(square(tDifferenceAt)) + dbCriterionAt == sqrt(square(tDifferenceAt)) ){
                        t = vlrOffDiagonalMtAt[p*sztRowAt + q] / tDifferenceAt;
                    }else{
                        T tTempAt = 0.5 *tDifferenceAt / vlrOffDiagonalMtAt[p*sztRowAt + q];
                        t = 1.0 /(sqrt(tTempAt*tTempAt) + sqrt(1.0 + tTempAt * tTempAt) );
                        if ( tTempAt < 0){
                            t = -t;
                        }
                    }

                    T c = 1.0/sqrt(1+t*t);
                    T s = t*c;
                    T tDiffAt =  t * vlrOffDiagonalMtAt[p*sztRowAt+q];

                    vlrDiagonalAt[p] -= tDiffAt;
                    vlrResidualDiagonalAt[p] -= tDiffAt;
                    vlrDiagonalAt[q] += tDiffAt;
                    vlrResidualDiagonalAt[q] += tDiffAt;

                    valarray<T> vlrTpAt(vlrOffDiagonalMtAt[slice(p,sztRowAt,sztRowAt)]);
                    valarray<T> vlrTqAt(vlrOffDiagonalMtAt[slice(q,sztRowAt,sztRowAt)]);

                    vlrOffDiagonalMtAt[slice(p,sztRowAt, sztRowAt)]
                        = c * vlrTpAt - s * vlrTqAt;

                    vlrOffDiagonalMtAt[slice(q,sztRowAt, sztRowAt)]
                        = s * vlrTpAt + c * vlrTqAt;

                    vlrTpAt = valarray<T>(vlrOffDiagonalMtAt[slice(p*sztRowAt,sztRowAt,1)]);
                    vlrTqAt = valarray<T>(vlrOffDiagonalMtAt[slice(q*sztRowAt,sztRowAt,1)]);
                    vlrOffDiagonalMtAt[slice(p*sztRowAt,sztRowAt, 1)]
                            = c * vlrTpAt - s * vlrTqAt;
                    //cout << "vlrTpAt: " << tfGetStrVal(vlrTpAt) << endl;  // to debug
                    //cout << "vlrTqAt: " << tfGetStrVal(vlrTqAt) << endl;            // to debug
                    //cout << "vlrOffDiagonalMtAt[slice(p*sztRowAt,sztRowAt, 1)]: " << tfGetStrVal(valarray<T>(vlrOffDiagonalMtAt[slice(p*sztRowAt,sztRowAt, 1)])) << endl;            // to debug

                    vlrOffDiagonalMtAt[slice(q*sztRowAt,sztRowAt, 1)]
                            = s * vlrTpAt + c * vlrTqAt;

                    vlrOffDiagonalMtAt[p*sztRowAt+q] = T(0);
                    vlrOffDiagonalMtAt[q*sztRowAt+p] = T(0);

                    vlrOffDiagonalMtAt[p*sztRowAt+p] = T(0);
                    vlrOffDiagonalMtAt[q*sztRowAt+q] = T(0);
                    //cout << "vlrOffDiagonalMtAt inner: " << tfGetStrVal(vlrOffDiagonalMtAt) << endl;  // to debug
                    //cout << "vlrDiagonalAt inner: " << tfGetStrVal(vlrDiagonalAt) << endl;            // to debug
                    
                    //! rotae eigen vector matrix
                    vlrTpAt = valarray<T>(rVlrEigenVctMtAg[slice(p,sztRowAt,sztRowAt)]);
                    vlrTqAt = valarray<T>(rVlrEigenVctMtAg[slice(q,sztRowAt,sztRowAt)]);
                    rVlrEigenVctMtAg[slice(p,sztRowAt,sztRowAt)]
                        = c*vlrTpAt - s*vlrTqAt;
                    rVlrEigenVctMtAg[slice(q,sztRowAt,sztRowAt)]
                        = s*vlrTpAt + c*vlrTqAt;
                    //cout << "NORM: " << tfAddSquare(vlrDiagonalAt)+dbSquareSumAt << endl; // to debug
                }
                //cout << "vlrOffDiagonalMtAt: " << tfGetStrVal(vlrOffDiagonalMtAt) << endl;  // to debug
                //cout << "vlrDiagonalAt: " << tfGetStrVal(vlrDiagonalAt) << endl;            // to debug
            }
        }
    
        //After sweep for all matrix elements
        rVlrEigenValAg += vlrResidualDiagonalAt;
    }
    kAssert("Don't converge!.", false);
}

template<class T>
void tfJacobiHermite(const std::valarray<T>& crVlrHermiteMatrixAg
    , std::valarray<T>& rVlrEigenValAg, std::valarray<T>& rVlrEigenVctMtAg)
{   
    size_t sztRowAt = static_cast<size_t>(   sqrt( double(crVlrHermiteMatrixAg.size()) )   );
    kAssert("Your matrix argment is not square matrix."
            , crVlrHermiteMatrixAg.size() == sztRowAt*sztRowAt);

    rVlrEigenVctMtAg.resize(sztRowAt*sztRowAt,T(0));
    rVlrEigenVctMtAg[slice(0,sztRowAt, sztRowAt+1)]
            = valarray<T>(T(1), sztRowAt);              // set unit matrix

    valarray<T> vlrHermiteMtAt(crVlrHermiteMatrixAg);

    // Sweep loop
    for(int i=0; i<cInMaxLoopStt; ++i){

        valarray<T> vlrOffDiagonalMtAt(vlrHermiteMtAt);
        vlrOffDiagonalMtAt[slice(0,sztRowAt, sztRowAt+1)]
                = valarray<T>(T(0), sztRowAt);              // set 0 diagonal element
        //cout << "vlrOffDiagonalMtAt first: " << tfGetStrVal(vlrOffDiagonalMtAt) << endl;  // to debug
        
        double dbSquareSumAt = tfAddSquare(vlrOffDiagonalMtAt);
        if ( dbSquareSumAt == 0){
            //After sweep for all matrix elements
            rVlrEigenValAg.resize(sztRowAt,T(0));
            rVlrEigenValAg += valarray<T>(vlrHermiteMtAt[slice(0,sztRowAt,sztRowAt+1)]);
            return;
        }
        //cout << "dbSquareSumAt: " << dbSquareSumAt << endl; // to debug

        double dbThresholdAt;
        if ( i < 4){
            dbThresholdAt = 0.04 * dbSquareSumAt / (sztRowAt*sztRowAt);
        }else{
            dbThresholdAt = 0;
        }

        //! Rotation loop
        for (size_t p=0; p<sztRowAt; ++p){
            for (size_t q=p+1; q<sztRowAt; ++q){
                //cout << "i: " << i << "    p: " << p << "   q: " << q << endl;    // to debug
                //double dbCriterionAt = 100.0 * sqrt(square(vlrHermiteMtAt[p*sztRowAt+q]));
                // c = (   (aqq - qpp) �} ��( (aqq-app)^2 + 4 (aqp apq) )   )/(4 aqp)
                T tDenominatorAt 
                         = vlrHermiteMtAt[q*sztRowAt + q] - vlrHermiteMtAt[p*sztRowAt + p]
                         + sqrt(
                                (vlrHermiteMtAt[q*sztRowAt + q]
                                 - vlrHermiteMtAt[p*sztRowAt + p]
                                )
                                *
                                (vlrHermiteMtAt[q*sztRowAt + q]
                                 - vlrHermiteMtAt[p*sztRowAt + p]
                                )
                           
                                +
                                T(4)*vlrHermiteMtAt[q*sztRowAt + p]
                                 *vlrHermiteMtAt[p*sztRowAt + q]
                           );

#if 0   // to debug
                cout << "Denominator first: " << vlrHermiteMtAt[q*sztRowAt + q] - vlrHermiteMtAt[p*sztRowAt + p] << endl;
                cout << "Denominator second: " << 
                           sqrt(
                                (vlrHermiteMtAt[q*sztRowAt + q]
                                 - vlrHermiteMtAt[p*sztRowAt + p]
                                )
                                *
                                (vlrHermiteMtAt[q*sztRowAt + q]
                                 - vlrHermiteMtAt[p*sztRowAt + p]
                                )
                           
                                +
                                T(4)*vlrHermiteMtAt[q*sztRowAt + p]
                                 *vlrHermiteMtAt[p*sztRowAt + q]
                           )
                     << endl;
#endif
                T tNumeratorAt = T(4)*vlrHermiteMtAt[q*sztRowAt + p];
                
                double dbCriterionAt = sqrt( square(vlrHermiteMtAt[q*sztRowAt + p]) );
                if ( (i > 4)
                  && (  (square(vlrHermiteMtAt[p*sztRowAt+p]) + dbCriterionAt) == square(vlrHermiteMtAt[p*sztRowAt+p]) )
                  && (  (square(vlrHermiteMtAt[q*sztRowAt+q]) + dbCriterionAt) == square(vlrHermiteMtAt[q*sztRowAt+q]) )
                ){
                    vlrHermiteMtAt[p*sztRowAt + q] = T(0);
                    vlrHermiteMtAt[q*sztRowAt + p] = T(0);
                }else if ( tDenominatorAt + tNumeratorAt == tDenominatorAt ){
                    vlrHermiteMtAt[p*sztRowAt + q] = T(0);
                    vlrHermiteMtAt[q*sztRowAt + p] = T(0);
                }else if ( square(vlrHermiteMtAt[p*sztRowAt + q]) > dbThresholdAt){
                    T s = T(0.5);
                    T c = tDenominatorAt/ tNumeratorAt;

                    //normalize
                    double dbLengthAt = sqrt(square(s) + square(c));
                    s /= dbLengthAt;
                    c /= dbLengthAt;

                    valarray<T> vlrTpAt(vlrHermiteMtAt[slice(p,sztRowAt,sztRowAt)]);
                    valarray<T> vlrTqAt(vlrHermiteMtAt[slice(q,sztRowAt,sztRowAt)]);

                    vlrHermiteMtAt[slice(p,sztRowAt, sztRowAt)]
                        = c * vlrTpAt - conj(s) * vlrTqAt;

                    vlrHermiteMtAt[slice(q,sztRowAt, sztRowAt)]
                        = s * vlrTpAt + conj(c) * vlrTqAt;
                    //cout << "vlrHermiteMtAt norm first: " << tfAddSquare(vlrHermiteMtAt) << endl; // to debug

                    vlrTpAt = valarray<T>(vlrHermiteMtAt[slice(p*sztRowAt,sztRowAt,1)]);
                    vlrTqAt = valarray<T>(vlrHermiteMtAt[slice(q*sztRowAt,sztRowAt,1)]);
                    vlrHermiteMtAt[slice(p*sztRowAt,sztRowAt, 1)]
                            = conj(c) * vlrTpAt - s * vlrTqAt;
                    //cout << "vlrTpAt: " << tfGetStrVal(vlrTpAt) << endl;  // to debug
                    //cout << "vlrTqAt: " << tfGetStrVal(vlrTqAt) << endl;            // to debug
                    //cout << "vlrHermiteMtAt[slice(p*sztRowAt,sztRowAt, 1)]: " << tfGetStrVal(valarray<T>(vlrHermiteMtAt[slice(p*sztRowAt,sztRowAt, 1)])) << endl;            // to debug

                    vlrHermiteMtAt[slice(q*sztRowAt,sztRowAt, 1)]
                            = conj(s) * vlrTpAt + c * vlrTqAt;
                    //cout << "vlrHermiteMtAt norm second: " << tfAddSquare(vlrHermiteMtAt) << endl;    // to debug

                    vlrHermiteMtAt[p*sztRowAt+q] = T(0);
                    vlrHermiteMtAt[q*sztRowAt+p] = T(0);
                    //cout << "vlrHermiteMtAt norm third: " << tfAddSquare(vlrHermiteMtAt) << endl; // to debug
                    
                    //! rotae eigen vector matrix
                    vlrTpAt = valarray<T>(rVlrEigenVctMtAg[slice(p,sztRowAt,sztRowAt)]);
                    vlrTqAt = valarray<T>(rVlrEigenVctMtAg[slice(q,sztRowAt,sztRowAt)]);
                    rVlrEigenVctMtAg[slice(p,sztRowAt,sztRowAt)]
                        = c*vlrTpAt - conj(s)*vlrTqAt;
                    rVlrEigenVctMtAg[slice(q,sztRowAt,sztRowAt)]
                        = s*vlrTpAt + conj(c)*vlrTqAt;
                    //cout << "NORM: " << tfAddSquare(vlrHermiteMtAt) << endl; // to debug
                }
                //cout << "vlrHermiteMtAt: " << tfGetStrVal(vlrHermiteMtAt) << endl;  // to debug
            }
        }
    
    }
    kAssert("Don't converge!.", false);
}


extern void GetRightSideVal(const string& crStrResidualAg, ClTerm& rClResultAg);

}   //namespace kk

#endif  //DfJacobi_H_

#if 1
using namespace kk;
int main(int argc, char** argv)
{
#if 0
    double dbArAt[] = {
             1,2,3,
             2,2,3,
             3,3,3};
    valarray<double> vlrDbAt(dbArAt,9);
    valarray<double> vlrEigenValAt, vlrEigenVctMtAt;
    kk::tfJacobiReal(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
#endif
#if 0
    double dbArAt[] = {
             1,2,3,4,5,
             2,2,3,4,5,
             3,3,3,4,5,
             4,4,4,4,5,
             5,5,5,5,5};
    valarray<double> vlrDbAt(dbArAt,25);
    valarray<double> vlrEigenValAt, vlrEigenVctMtAt;
    kk::tfJacobiReal(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
#endif

#if 0
    typedef complex<double> Ty;
    complex<double> dbArAt[] = {
             Ty(1,0),Ty(2,0),Ty(3,0),
             Ty(2,0),Ty(2,0),Ty(3,0),
             Ty(3,0),Ty(3,0),Ty(3,0)};
    valarray<complex<double> > vlrDbAt(dbArAt,9);
    valarray<complex<double> > vlrEigenValAt, vlrEigenVctMtAt;
    kk::tfJacobiHermite(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
#endif
#if 0
    typedef complex<double> Ty;
    complex<double> dbArAt[] = {
             Ty(1,0),Ty(2,0),Ty(3,0),Ty(4,0),Ty(5,0),
             Ty(2,0),Ty(2,0),Ty(3,0),Ty(4,0),Ty(5,0),
             Ty(3,0),Ty(3,0),Ty(3,0),Ty(4,0),Ty(5,0),
             Ty(4,0),Ty(4,0),Ty(4,0),Ty(4,0),Ty(5,0),
             Ty(5,0),Ty(5,0),Ty(5,0),Ty(5,0),Ty(5,0)};
    valarray<complex<double> > vlrDbAt(dbArAt,25);
    valarray<complex<double> > vlrEigenValAt, vlrEigenVctMtAt;
    kk::tfJacobiHermite(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
#endif

#if 0
    typedef complex<double> Ty;
    complex<double> dbArAt[] = {
             Ty(1,0) , Ty(2,1), Ty(3,1), Ty(4,1), Ty(5,1),
             Ty(2,-1), Ty(2,0), Ty(3,1), Ty(4,1), Ty(5,1),
             Ty(3,-1),Ty(3,-1), Ty(3,0), Ty(4,1), Ty(5,1),
             Ty(4,-1),Ty(4,-1),Ty(4,-1), Ty(4,0), Ty(5,1),
             Ty(5,-1),Ty(5,-1),Ty(5,-1),Ty(5,-1),Ty(5,0)};
    valarray<complex<double> > vlrDbAt(dbArAt,25);
    valarray<complex<double> > vlrEigenValAt, vlrEigenVctMtAt;
    //cout << "At Main(): " << tfGetStrVal(vlrDbAt) << endl;    //to debug
    kk::tfJacobiHermite(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
#endif

#if 0
    // Hermite ���炸�炵�ē�����m�F����
    // �s�񂪑Ώ̂��炸��Ă��A�Ίp�����Ɣ�Ίp���������ɉ�]�����A��Ίp������
    // 0 �N���A���Ă����̂œ��삵�Ă��܂��B�ۂߌ덷�̏W�ϒ��x�Ȃ�Ζ��Ȃ���
    // �ӎ����� Hermite �łȂ������Ƃ��́A�v�Z�����ŗL�l�͐M�p�ł��Ȃ��Ȃ�
    typedef complex<double> Ty;
    complex<double> dbArAt[] = {
             Ty(1,0) , Ty(2,1), Ty(3,1), Ty(4,1), Ty(5,1),
             Ty(2,-1), Ty(2,0), Ty(3,1), Ty(4,1), Ty(5,1),
             Ty(3,-1),Ty(3,-1), Ty(3,0), Ty(4,1), Ty(5,1),
             Ty(4,-1),Ty(4,-1),Ty(4,-1), Ty(4,0), Ty(5,1),
             Ty(5,-0.1),Ty(5,-1),Ty(5,-1),Ty(5,-1),Ty(5,0)};
    valarray<complex<double> > vlrDbAt(dbArAt,25);
    valarray<complex<double> > vlrEigenValAt, vlrEigenVctMtAt;
    //cout << "At Main(): " << tfGetStrVal(vlrDbAt) << endl;    //to debug
    kk::tfJacobiHermite(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
    cout << "vlrEigenValAt: " << tfGetStrVal(vlrEigenValAt) << endl;
    cout << "vlrEigenVctMtAt: " << tfGetStrVal(vlrEigenVctMtAt) << endl;
#endif

#if 0
    // ���f���ŌŗL�x�N�g���̒����� row x column �T�C�Y�ɂȂĂ���̂Ŋm�F����
    typedef complex<double> Ty;
    complex<double> dbArAt[] = {
             Ty(0,0),  Ty(0.125,-0.125),        Ty(0,-0.25), Ty(-0.375,-0.375),
     Ty(0.125,0.125),           Ty(0,0),   Ty(0.125,-0.125),       Ty(0,-0.25),
          Ty(0,0.25),   Ty(0.125,0.125),            Ty(0,0),  Ty(0.125,-0.125),
    Ty(-0.375,0.375),        Ty(0,0.25),    Ty(0.125,0.125),           Ty(0,0)};
    valarray<complex<double> > vlrDbAt(dbArAt,16);
    valarray<complex<double> > vlrEigenValAt, vlrEigenVctMtAt;
    //cout << "At Main(): " << tfGetStrVal(vlrDbAt) << endl;    //to debug
    kk::tfJacobiHermite(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
    cout << "vlrEigenValAt: " << tfGetStrVal(vlrEigenValAt) << endl;
    cout << "vlrEigenVctMtAt: " << tfGetStrVal(vlrEigenVctMtAt) << endl;
#endif
    
#if 0
    // ���f�s�� ��y �̌ŗL�l�x�N�g���� <0,1> �ɂȂ��Ă���̂Ŋm�F����
    typedef complex<double> Ty;
    complex<double> dbArAt[] = {
             Ty(0,0),  Ty(0,-1),
             Ty(0,1),  Ty(0,0) };
    valarray<complex<double> > vlrDbAt(dbArAt,4);
    valarray<complex<double> > vlrEigenValAt, vlrEigenVctMtAt;
    //cout << "At Main(): " << tfGetStrVal(vlrDbAt) << endl;    //to debug
    kk::tfJacobiHermite(vlrDbAt, vlrEigenValAt, vlrEigenVctMtAt);
    cout << "vlrEigenValAt: " << tfGetStrVal(vlrEigenValAt) << endl;
    cout << "vlrEigenVctMtAt: " << tfGetStrVal(vlrEigenVctMtAt) << endl;
#endif

#if 1
    if ( argc != 2){
        cout << "Please input >jacobi fileName." <<endl;
        return 1;
    }

    //! _rs.val �ɌŗL�l�̃x�N�^�[, Jacobi.val �� �ŗL�x�N�^ x size �s��f�[�^���o�͂���
    ClTerm clTermVctAt;
    ClTerm clTermMtAt;
    
    // Convert data from argv sf variable
    GetRightSideVal(argv[1], kr clTermMtAt);


    if ( clTermMtAt.m_blCmplx == true ){
        valarray<complex<double> > vlrEigenValAt, vlrEigenVctMtAt;
        tfJacobiHermite(clTermMtAt.m_vlrCplxDb, vlrEigenValAt, vlrEigenVctMtAt);
        //valarray<double> vlrAt;
        //vlrAt.resize(vlrEigenValAt.size());
        size_t sztRowAt = vlrEigenValAt.size();
        
#if 0
        //2003.12.11 ���R�͕s�������A���̃R�[�h���Ȃ��Ă������ɐ��񂳂�Ă���
        //simple ascending order sort
        for( size_t i=1; i<sztRowAt; ++i){
            if ( vlrEigenValAt[i-1].real() > vlrEigenValAt[i].real() ){
                kSwap( kr vlrEigenVctMtAt[slice(i-1, sztRowAt, sztRowAt)]
                     , kr vlrEigenVctMtAt[slice(i,sztRowAt, sztRowAt)]
                );
                swap(kr vlrEigenValAt[i-1], kr vlrEigenValAt[i]);
                i=0;
                continue;
            }
        }
#endif
        //cout << "vlrEigenValAt: " << tfGetStrVal(vlrEigenValAt) << endl;      //debug
        //cout << "vlrEigenVctMtAt: " << tfGetStrVal(vlrEigenVctMtAt) << endl;    //debug
        clTermMtAt.m_blCmplx = true;
        clTermMtAt.m_vlrCplxDb = vlrEigenVctMtAt;

        // Eigen vector of Hermite matrix has only real value
        //clTermVctAt.m_blCmplx = true;
        clTermVctAt.m_vlrDb.resize(sztRowAt);
        for( size_t i=0; i<sztRowAt; ++i){
            clTermVctAt.m_vlrDb[i] = vlrEigenValAt[i].real();
        }
    }else{
        valarray<double> vlrEigenValAt, vlrEigenVctMtAt;
        tfJacobiReal(clTermMtAt.m_vlrDb, vlrEigenValAt, vlrEigenVctMtAt);

        size_t sztRowAt = vlrEigenValAt.size();
        //simple ascending order sort
        for( size_t i=1; i<sztRowAt; ++i){
            if ( vlrEigenValAt[i-1] > vlrEigenValAt[i]){
                kSwap( kr vlrEigenVctMtAt[slice(i-1, sztRowAt, sztRowAt)]
                     , kr vlrEigenVctMtAt[slice(i,sztRowAt, sztRowAt)]
                );
                swap(kr vlrEigenValAt[i-1], kr vlrEigenValAt[i]);
                i=0;
                continue;
            }
        }

        clTermVctAt.m_vlrDb = vlrEigenValAt;
        clTermMtAt.m_vlrDb = vlrEigenVctMtAt;
    }

    ClTerm::m_blIniStt = false; //To print for console

    clTermMtAt.m_strVarName = "Jacobi.val";
    clTermMtAt.PrintTerm();

    cout << endl;

    clTermVctAt.m_strVarName = "_rs.val";
    clTermVctAt.PrintTerm();

#endif

    return 0;
}
#endif //1

//@@@
//cl jacobi.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\  sfMtrxML.obj vrfyNpML.lib

//cl jacobi.cpp /MDd /W3 /Od /D"DfVC_" /D"DfVrfy" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\  sfMtrx.obj kreg.lib execChild.obj

