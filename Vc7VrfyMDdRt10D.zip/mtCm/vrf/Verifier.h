#ifdef DfVrfy

#ifndef DfVerifier__
#define DfVerifier__
#pragma warning(disable:4786)
#ifndef DfKCommon_H_
#include <kcommon.h>
#endif //DfKCommon_H_
//#include <TestVct.h>
//#include <VrfyVar.h>
#include <list>
#include <process.h>
//#include <iostream>
#include <fstream>
#define DfOutputFileName "Verify.out"
#ifdef DfRT_
//#   include <windows.h>
#endif //DfRT_
namespace kk{
//using namespace std;

class ClTestVct;
class ClVrfyVar;

class ClBaseVerified;
class ClVrfyIntfBase;

class ClVrfySglt{
  public:
    void* m_PvVrfyFiber;

    int Main(int argc, char** argv);
    
    // VrfyLoop() must return bool because it is refferd from user's ::main(.)
    // or WinMain(.)
    bool VrfyLoop(void);
    virtual void StartTick(void);    // called from ClVrfySglt
    // 01.04.02 coding lefted �C���X�g���N�V�����E�t�@�C������̏I���w��
    // �� IsEnded() �ɑg�ݍ���ł��Ȃ�
    virtual ~ClVrfySglt(void);

    std::list<ClVrfyIntfBase*> m_lstpClVrfyIntfBase;
    void AddClVrfyIntfBase(ClVrfyIntfBase* pClAg)
            {m_lstpClVrfyIntfBase.push_back(pClAg);}
    void EraseClVrfyIntfBase(ClVrfyIntfBase* pClAg)
            {m_lstpClVrfyIntfBase.remove(pClAg);}

    virtual void Tick(void);
  private:
    ClVrfySglt( char* pChAg = DfOutputFileName);
    static ClVrfySglt* m_pTheInstanceStt;
    static void* m_pVdVrfySgltFiberStt;

  public:
    virtual bool isEnded(void){ return m_lstpClVrfyIntfBase.size() == 0;}
    static ClVrfySglt* GetStt(void);
    TyTime m_tmNow;
    static TyTime GetNowTimeStt(void){ return GetStt()->m_tmNow;}
    void SetNextTickTime(const TyTime& crTmAg) { m_tmNow = crTmAg; }
    
    virtual void Initialize( int& rArgc, char**& rppArgv);

    bool IsMicroVerification(void){ return m_blMicroSecVrf;}
    
  private:
    enum EnEnd { EnInitial, EnSimEnd};

    std::string m_strFirst;  // reffered by ClTestVct::tick() after ParseLine(.)
    std::string m_strSecond;
    friend class ClTestVct;
    std::ofstream m_outFile;
    bool m_blMicroSecVrf;
  
    // dubugger ��ŔC�ӂ̏ꏊ����Q�Ƃ��邽�� private �ɂ��Ȃ� <-- �{��??
    char* m_pChFileName;

    // control simulation time progress
  public:
    void SetSlow(bool blSlowAg);
    void SetTimeRate(double dbTimeRateAg);
  private:
    bool m_blSlow;        //98.10.29 ���ꂪ true �̂Ƃ������ԃV�~�����[�V�����Ƃ���
    unsigned int m_wdMiliSecTimeAtSlow; // kVerifier Simulated Time
    unsigned int m_wdMiliSecTickAtSlow; // Windows Tick time measured by ::GetTickCount()
    double       m_dbTimeRate;
    void adjustTimeProgress(void);

  protected:
    void parseInstrucitonFile(const std::string& crStrAg);
  public:
    void Out(kc std::string& );     // endl �� Out(.) ���t����
    void OutError(const std::string& );
    void OutWarning(const std::string& );
    void OutWithTime(kc kk::kstring& );

  private:
    void openFnc(char* pChAg);
    
    ClBaseVerified* whereIsMonitoredVar(kc std::string& crStrAg);

  //------------ break time interface --------------
    std::multiset<ClTmString*, ClLessTimeFo > m_mstpClTimeBreak;
  public:
    void AddBreakTime(ClTmString* pClTmStringAg)
        { m_mstpClTimeBreak.insert(pClTmStringAg);}
};


}   //namespace kk

extern void PrintTime(kk::TyTime tmAg);

#endif  /* DfVerifier__ */

#endif  /* DfVrfy */

#ifdef DfVrfy
#   define DfSetRealTimeMode() ClVrfySglt::SetRealTimeMode()        //97.10.03 �ǉ�
#   define DfClearRealTimeMode() ClVrfySglt::ClearRealTimeMode()    //97.10.03 �ǉ�
#else
#   define DfSetRealTimeMode()                          /*97.10.03 �ǉ�*/
#   define DfClearRealTimeMode()                        /*97.10.03 �ǉ�*/
#endif


#ifdef DfVrfy
#   define DfVrfyTickBreak() bool blEndAt; ClVrfySglt::GetStt()->Tick(kr blEndAt); if( blEndAt ){break;}
#   define DfVrfyTick() bool blEndAt; ClVrfySglt::GetStt()->Tick(kr blEndAt)
#   define DfRegistInputVar(x,y) ClVrfySglt::registInputVar( (x), (y) )

#else   /* DfVrfy */
#   define DfVrfyTickBreak()
#   define DfVrfyick()
#endif  /* DfVrfy */

