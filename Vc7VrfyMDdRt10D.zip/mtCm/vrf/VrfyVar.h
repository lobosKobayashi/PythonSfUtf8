#ifdef DfVrfy

#ifndef DfVrfyVar__
#define DfVrfyVar__
#pragma warning(disable:4786)
#include <kcommon.h>
#include <iomanip>
#include <string>
#include <bitset>

#include <sstream>

//if gcc::istringstream >> string has no erro then use
//    class ikStream : public istringstream{..}
//    ikStream& operator >>(ikStream& rIkStreamAg, kr string& rStrAg);
//We use tfRgstVerifier(.) for tfRgstVrfyStr(.)
#define ikStream std::istringstream

namespace kk{
//using namespace std;
typedef void( *TyVdPfVd )(void);

class ClTestVct;
class ClBaseVerified{
  protected:
    std::string m_strVariableName;
    long m_lgIosFlag;
  protected:
  public:
    ClBaseVerified(const std::string&, long lgFlgAg=std::ios::hex);
    virtual void Set(int inDataAg, int inBtSlctAg);   // used at testVct.cpp
    virtual void Set( const std::string&);
    virtual bool Compare(int inDataAg, int inBtSlctAg);   // used at testVct.cpp
    virtual bool Compare(const std::string&);
    //virtual TyVdPfVd GetInterruptFunction(void);
    virtual void* GetInterruptFunction(void);

#if 0
    virtual void Set(void);    // �e�X�g�ň��������̃G���[���o�̂Ƃ��Ɏg��
    virtual void Set(int);
    virtual bool Compare(int);
    virtual void Function(void);
    virtual void Function(int);
    virtual void Function(const char*);
    virtual void Function(const std::string&);
#endif
    virtual std::string WhatValue(void);
    virtual ~ClBaseVerified(){}

  public:
    const std::string& WhatYourName(void) const {return m_strVariableName;}
    virtual const void* WhatAddress(void){ return this;}

  protected:
    void outOperationError(const std::string& crStrAg);

//del03.04//coding lefted 2001.01.29 
//del03.04//monitored �ϐ��� ClTestVct ���ƂɊǗ�����悤�ɂ�����ɁA�ȉ����C������
//del03.04  public:
//del03.04    virtual bool IsChanged(void){ assert(0); return false;}
};


//ikStream& operator >>(ikStream& rIkStreamAg, kr std::string& rStrAg);

template<class T> class TcBaseVerified : public ClBaseVerified{
  protected:
    T& m_rT;
  public:
    //01.05.09 default argment = ios::hex make vc6.0 internal error fatal error C1001
    TcBaseVerified(T& rTAg, const std::string& crStrAg,long lgIosFlgAg/*=ios::hex*/
    ):ClBaseVerified(crStrAg,lgIosFlgAg), m_rT(rTAg){}

#if 1 //01.07.28
    virtual void Set(const std::string& crStrAg)
    {
        ikStream iStrmAt(crStrAg);
        iStrmAt.unsetf(std::ios::basefield);
        iStrmAt >> m_rT;
    }
    virtual std::string WhatValue(void)
    {
        std::ostringstream ostrmAt;
        if (m_lgIosFlag != 0){  // ios::basefield or ios::floatfield is set
            ostrmAt.unsetf(std::ios::basefield | std::ios::floatfield);
            //ostrmAt.setf( static_cast<std::ios_base::fmtflags>(m_lgIosFlag) );
            //ostrmAt.setf( std::ios_base::m_lgIosFlag );
            ostrmAt.setf( (std::ostream::fmtflags)m_lgIosFlag );
        }
        if (m_lgIosFlag & std::ios::hex){
            // hex format is requested
            ostrmAt << "0x";
        }
        
        ostrmAt << m_rT;
        return ostrmAt.str();
    }
#endif
    const void* WhatAddress(void){ return &m_rT;}
};

template<class T> class TcVerified : public TcBaseVerified<T>{
  public:
    TcVerified(T& rTAg, const std::string& crStrAg,long lgIosFlgAg=std::ios::hex
    ):TcBaseVerified<T>(rTAg, crStrAg, lgIosFlgAg){}
    virtual bool Compare(const std::string& crStrAg)
    {
        ikStream iStrmAt(crStrAg);
        iStrmAt.unsetf(std::ios::basefield);
        T tAt;
        iStrmAt >> tAt;
        return m_rT == tAt;
    }
};

template<>
class TcVerified<unsigned char> : public TcBaseVerified<unsigned char>{
  public:
    TcVerified(unsigned char& rTAg, const std::string& crStrAg,long lgIosFlgAg=std::ios::hex
    ):TcBaseVerified<unsigned char>(rTAg, crStrAg, lgIosFlgAg){}
    virtual void Set(const std::string& crStrAg)
    {
        ikStream istrmAt(crStrAg);
        istrmAt.unsetf(std::ios::basefield);
        int inAt;
        istrmAt >> inAt;
        m_rT = inAt;
    }
    virtual void Set(int inDataAg, int inBtSlctAg)
    {
        m_rT &= inBtSlctAg;
        m_rT |= inDataAg & (~inBtSlctAg);
    }
    virtual bool Compare(int inDataAg, int inBtSlctAg)
    {
        return (m_rT & ~inBtSlctAg) == inDataAg;
    }
    virtual bool Compare(const std::string& crStrAg)
    {
        ikStream iStrmAt(crStrAg);
        iStrmAt.unsetf(std::ios::basefield);
        int inAt;
        iStrmAt >> inAt;
        return m_rT == inAt;
    }

    virtual std::string WhatValue(void)
    {
        std::ostringstream ostrmAt;
        if (m_lgIosFlag != 0){  // ios::basefield or ios::floatfield is set
            ostrmAt.unsetf(std::ios::basefield | std::ios::floatfield);
            ostrmAt.setf((std::ostream::fmtflags)m_lgIosFlag);
        }
        if (m_lgIosFlag & std::ios::hex){
            // hex format is requested
            ostrmAt << "0x";
        }
        ostrmAt << int(m_rT);
        return ostrmAt.str();
    }
};


template<class T> class TcVrfyFp : public TcBaseVerified<T>{
    double m_dbPrecision;
  protected:
  public:
    TcVrfyFp(T& rTAg, const std::string& crStrAg, double dbPrecisionRateAg=0.00001
            , long lgIosFlag=std::ios::scientific
    ):TcBaseVerified<T>(rTAg,crStrAg,lgIosFlag), m_dbPrecision(dbPrecisionRateAg){}

    virtual void Set(const std::string& crStrAg)
    {
        ikStream iStrmAt(crStrAg);
        iStrmAt.unsetf(std::ios::basefield);
        T tAt;
        iStrmAt >> tAt;
        m_rT = tAt;
    }
    virtual bool Compare(const std::string& crStrAg)
    {
        std::string strLtAt = crStrAg;
        std::string strRtAt;
        double dbAt=1.0;

        size_t sztAt = crStrAg.find("__prcsnRate");
        if ( sztAt != std::string::npos){
            strLtAt = crStrAg.substr(0,sztAt);
            // 11 == string("__prcsnRate").length()
            strRtAt = crStrAg.substr(sztAt+11, std::string::npos);

            ikStream iStrmRtAt(strRtAt);
            iStrmRtAt.unsetf(std::ios::basefield);
            iStrmRtAt >> dbAt;
            if (dbAt == 0){
                dbAt = 1.0;
            }
        }

        ikStream iStrmLtAt(strLtAt);
        iStrmLtAt.unsetf(std::ios::basefield);
        T tAt;
        iStrmLtAt >> tAt;
        tAt -= m_rT;
        if ( tAt >= 0){
            return  tAt <= (m_dbPrecision * dbAt);
        }else{
            return  (-tAt) <= (m_dbPrecision * dbAt);
        }
    }

};

#if 1
//02.06.14 ���� string �̓��� TcBaseVerified ���g���� gcc �̂Ƃ� __compare "" �� hung up ����
//02.06.27 ToSTL �ŃG���[�ɂȂ�e�X�g�E�x�N�^���K�v�������BCompare(.) �̃R�[�h�� cut and try ��
//gcc �ł���΂Ȃ��悤�ɏC�������B
template<>
class TcVerified<std::string> : public TcBaseVerified<std::string>{
  public:
    TcVerified( std::string& rTAg, const std::string& crStrAg)
            :TcBaseVerified<std::string>(rTAg, crStrAg, 0){}

    virtual void Set(const std::string& crStrAg)
    {
        std::string strAt=crStrAg;
        if ( strAt[0] == _T('\"') ){
            strAt = strAt.substr(1, -1 + strAt.rfind('\"') );
        }
        m_rT = strAt;
    }

    virtual bool Compare(const std::string& crStrAg)
    {
        if ( crStrAg[0] ==_T('\"') ){
            std::string strAt
            = crStrAg.substr(1, -1+crStrAg.rfind('\"'));
            return m_rT == strAt;
        }else{
            return m_rT == crStrAg;
        }
    }
    const void* WhatAddress(void){ return &m_rT;}
};
#endif
//------------------------- User Verifier class begin ------------------------------

template<class T> class TcVrfyCntnr : public ClBaseVerified{
  protected:
    T& m_rT;
  public:
    TcVrfyCntnr(T& rTAg, const std::string& crStrAg,long lgIosFlgAg=std::ios::hex
    ):ClBaseVerified(crStrAg,lgIosFlgAg), m_rT(rTAg){}
    virtual void Set(const std::string& crStrAg)
    {
        tfSet(crStrAg,m_rT);
    }
    virtual bool Compare(const std::string& crStrAg)
    {
        return tfCompare(crStrAg,m_rT);
    }
    std::string WhatValue(void)
    {
        return tfGetStrVal(m_rT);
    }
};

template<class T> class TcVrfyCntnrFp : public ClBaseVerified{
    double m_dbPrecision;
  protected:
    T& m_rT;
  public:
    TcVrfyCntnrFp(T& rTAg, const std::string& crStrAg, double dbPrecisionRateA
            , long lgIosFlag=std::ios::scientific
    ):ClBaseVerified(crStrAg,lgIosFlag), m_rT(rTAg), m_dbPrecision(dbPrecisionRateA){}
    virtual void Set(const std::string& crStrAg)
    {
        tfSet(crStrAg,m_rT);
    }
    virtual bool Compare(const std::string& crStrAg)
    {
        std::string strLtAt = crStrAg;
        std::string strRtAt;
        double dbAt=1.0;

        size_t sztAt = crStrAg.find("__prcsnRate");
        if ( sztAt != std::string::npos){
            strLtAt = crStrAg.substr(0,sztAt);
            // 11 == string("__prcsnRate").length()
            strRtAt = crStrAg.substr(sztAt+11, std::string::npos);

            ikStream iStrmRtAt(strRtAt);
            iStrmRtAt.unsetf(std::ios::basefield);
            iStrmRtAt >> dbAt;
            if (dbAt == 0){
                dbAt = 1.0;
            }
        }

        T tAt;
        tfSet(strLtAt,kr tAt);
        tAt -= m_rT;
        return  (double)tfCntnrAbs(tAt) <= m_dbPrecision * dbAt;
    }
    std::string WhatValue(void)
    {
        return tfGetStrVal(m_rT);
    }
};

//------------------------- User Verifier class end ------------------------------

class ClBtSlct{
  public:
    //01.06.13 coding lefted unsigned char �ɂ��K�p�ł���悤�ɂ���B8 bit size �ϐ��̂Ƃ��A
    //1 byte �݂̂�ύX�E�m�F����悤�ɂ���B�L���X�e�B���O���Ďg��
    int m_inBtSlct;
    ClBtSlct(int inBtSlctAg=0):m_inBtSlct(inBtSlctAg){}
    // if you need complex conversion then you discribe yourself a new WhatValue() funciton.
    virtual std::string WhatValue(int inAg)
    {
        std::bitset<8*sizeof(int)> btAt(m_inBtSlct);
        if ( btAt.count()==1 ){ // 1 bit Mask
            return inAg? std::string("1"): std::string("0");
        }else{
            return "";  // if returned value == "" then use TcBaseVerified<>::WhatValue
        }
    } 
    virtual int ShiftBitInt(int inAg)
    {
        std::bitset<8*sizeof(int)> btAt(m_inBtSlct);
        if ( btAt.count()==1 ){ // 1 bit Mask
            return inAg? m_inBtSlct: 0;
        }else{
            return -1;  // if returned value == "" then use test vector described value
        }
    }
    operator int() const { return m_inBtSlct;}
};

class ClBaseMonitored{
  protected:
    std::string m_strVariableName;
    long m_lgIosFlag;
    // 01.07.27 coding lefted: monitor ���Ԃ���؂��Ďg���� monitor �ϐ��̂��߂ɐ݂���
    bool m_blPermanent;
  public:
    ClBaseMonitored(const std::string& crStrAg, bool blPermanentAg, long lgFlagAg)
        : m_strVariableName(crStrAg), m_blPermanent(blPermanentAg),m_lgIosFlag(lgFlagAg){}
    const std::string& WhatYourName(void) const {return m_strVariableName;}
    virtual bool Monitor(void);
    virtual std::string WhatValue(void);
  
  // trace control
  protected:
    bool m_blPermanet;
    int m_inTraceStart;
    int m_inTraceEnd;
    TyTime m_tmTraceStart;
    TyTime m_tmTraceEnd;
  public:
    void SetTraceCount(int inStartAg, int inEndAg)
    {
        m_inTraceStart = inStartAg;
        m_inTraceEnd = inEndAg;
    }
    void SetTraceCount(TyTime tmStartAg, TyTime tmEndAg)
    {
        m_tmTraceStart = tmStartAg;
        m_tmTraceEnd = tmEndAg;
    }
    bool IsTraceCount(int inCountAg)
    {
        return m_blPermanet
            | (  (m_inTraceStart <= inCountAg)
              && (m_inTraceEnd > inCountAg)
              );
    }
    bool IsTraceCount(TyTime tmAg)
    {
        return m_blPermanet
            | (  (m_tmTraceStart <= tmAg)
              && (m_tmTraceEnd > tmAg)
              );
    }
};

// TcMonitored
template<class T> class TcMonitored : public ClBaseMonitored{
  protected:
    const T& m_crT;
    T m_T;
  public:
    TcMonitored(const T& crTAg, const std::string& crStrAg
            , bool blPermanentAg=true, long lgFlagAg=std::ios::hex)
            : ClBaseMonitored(crStrAg,blPermanentAg, lgFlagAg)
            , m_crT(crTAg), m_T(crTAg){}
    virtual bool Monitor(void)
    {
        if ( m_crT == m_T ){
            return  false;
        }else{
            m_T = m_crT;
            return true;
        }
    }
    virtual std::string WhatValue(void)
    {
        std::ostringstream ostrmAt;
        if (m_lgIosFlag != 0){  // ios::basefield or ios::floatfield is set
            ostrmAt.unsetf(std::ios::basefield | std::ios::floatfield);
#ifdef DfVC_
            ostrmAt.setf(m_lgIosFlag);
#endif // DfVC_
#ifdef DfGcc_
            ostrmAt.setf(m_lgIosFlag);
            //ostrmAt.setf((std::_Ios_Fmtflags)m_lgIosFlag);
#endif //DfGcc_
        }
        if (m_lgIosFlag & std::ios::hex){
            // hex format is requested
            ostrmAt << "0x";
        }
        ostrmAt << m_T;
        return ostrmAt.str();
    }
};


template<>
class TcMonitored<unsigned char> : public ClBaseMonitored{
  protected:
    const unsigned char& m_crT;
    unsigned char  m_T;
  public:
    TcMonitored(const unsigned char& crTAg, const std::string& crStrAg
            , bool blPermanentAg=true, long lgFlagAg=std::ios::hex)
            : ClBaseMonitored(crStrAg,blPermanentAg, lgFlagAg)
            , m_crT(crTAg), m_T(crTAg){}
    virtual bool Monitor(void)
    {
        if ( m_crT == m_T ){
            return  false;
        }else{
            m_T = m_crT;
            return true;
        }
    }
    virtual std::string WhatValue(void)
    {
        std::ostringstream ostrmAt;
        if ( (m_lgIosFlag & std::ios::hex) == 0){
        //if (m_lgIosFlag != 0){  // ios::basefield or ios::floatfield is set
            ostrmAt.unsetf(std::ios::basefield | std::ios::floatfield);
#ifdef DfVC_
            ostrmAt.setf(m_lgIosFlag);
#endif // DfVC_
#ifdef DfGcc_
            ostrmAt.setf((std::ostream::fmtflags)m_lgIosFlag);
            //ostrmAt.setf((std::_Ios_Fmtflags)m_lgIosFlag);
#endif //DfGcc_
        }else{
            ostrmAt.setf(std::ios::hex);
//            ostrmAt.setf(std::ios::showbase);
//            ostrmAt.setf(std::ios::right);
//            ostrmAt.setfill('0');
//            ostrmAt.right();
            ostrmAt << "0x";
        }
        ostrmAt << (unsigned int)m_T;
        return ostrmAt.str();
    }
};

//------------------------- Monitored Container class begin ------------------------------
template<class T> class TcMntrCntnr : public ClBaseMonitored{
  protected:
    const T& m_crT;
    T  m_T;
  public:
    TcMntrCntnr(const T& crTAg, const std::string& crStrAg,bool blPermanentAg=true, long lgIosFlgAg=std::ios::hex
    ):ClBaseMonitored( crStrAg, blPermanentAg, lgIosFlgAg)
            , m_crT(crTAg), m_T(crTAg){}
    virtual bool Monitor(void)
    {
        if ( m_crT == m_T ){
            // same, not changed
            return  false;
        }else{
            m_T = m_crT;
            return true;
        }
    }
    virtual bool Compare(const std::string& crStrAg)
    {
        return tfCompare(crStrAg,m_crT);
    }
    virtual std::string WhatValue(void)
    {
        return tfGetStrVal(m_T);
    }
};
//------------------------- Monitored Container class end ------------------------------

template<class T> class TcMonitoredMkNm : public ClBaseMonitored{
  protected:
    const T& m_crT;
    T m_T;
    ClBtSlct m_clBtSlct;
  public:
    TcMonitoredMkNm(const T& crTAg, const std::string& crStrAg
            , int inBtSlctAg
        , bool blPermanentAg=true, long lgFlagAg=std::ios::hex)
        : ClBaseMonitored(crStrAg,blPermanentAg, lgFlagAg)
        ,m_crT(crTAg), m_T(crTAg), m_clBtSlct(inBtSlctAg){}
    virtual bool Monitor(void)
    {
        if ( m_crT == ( m_clBtSlct & ((int)m_T)) ){
            return  false;
        }else{
            m_T = m_crT;
            return true;
        }
    }
    virtual std::string WhatValue(void)
    {
        std::string strAt = m_clBtSlct.WhatValue(m_clBtSlct & (int)m_crT);;
        if ( strAt == ""){
            std::ostringstream ostrmAt;
            if (m_lgIosFlag != 0){  // ios::basefield or ios::floatfield is set
                ostrmAt.unsetf(std::ios::basefield | std::ios::floatfield);
                ostrmAt.setf(m_lgIosFlag);
            }
            ostrmAt << (m_clBtSlct & (int)m_T);
            return ostrmAt.str();
        
        }
        return strAt;
    }
};
//--------------------- TcVrfyMkNm Begin -----------------------------------

template<class T> class TcVrfyMkNm: public TcBaseVerified<T>{
  protected:
    ClBtSlct m_clBtSlct;
  public:
    TcVrfyMkNm(T& rTAg, const std::string& crStrAg
            , int inBtSlctAg, long lgFlagAg);
    virtual void Set(int inDataAg, int inBtSlctAg=-1);
    virtual bool Compare(const std::string& crStrAg)
    {
        ikStream iStrmAt(crStrAg);
        iStrmAt.unsetf(std::ios::basefield);
        int inAt;
        iStrmAt >> inAt;
        return  Compare(inAt,m_clBtSlct);
    }
    virtual bool Compare(int inDataAg, int inBtSlctAg=-1);
    virtual std::string WhatValue(void)
    {
        std::string strAt = m_clBtSlct.WhatValue(m_clBtSlct & (int)m_rT);;
        if ( strAt == ""){
            std::ostringstream ostrmAt;
            if (m_lgIosFlag != 0){  // ios::basefield or ios::floatfield is set
                ostrmAt.unsetf(std::ios::basefield | std::ios::floatfield);
                ostrmAt.setf(m_lgIosFlag);
            }
            ostrmAt << (m_clBtSlct & (int)m_rT);
            return ostrmAt.str();
        
        }
        return strAt;
    }
};

template<class T>TcVrfyMkNm<T>::TcVrfyMkNm(T& rTAg, const std::string& crStrAg
        , int inBtSlctAg, long lgFlagAg
        ):TcBaseVerified<T>(rTAg, crStrAg, lgFlagAg), m_clBtSlct(inBtSlctAg){}

template<class T> void TcVrfyMkNm<T>::Set(int inDataAg, int inBtSlctAg)
{
    int inAt;
    inAt=m_clBtSlct.ShiftBitInt(inDataAg);
    if ( inAt != -1){
        inDataAg = inAt;
    }
    switch ( sizeof(m_rT) ){
        case 1:{
            (char&)m_rT = ((int&)m_rT & ~inBtSlctAg) | ( inDataAg & inBtSlctAg);
            return;
        }
        case 2:{
            (short&)m_rT = ((int&)m_rT & ~inBtSlctAg) | ( inDataAg & inBtSlctAg);
            return;
        }
        default:{    // size == 4
            (int&)m_rT = ((int&)m_rT & ~inBtSlctAg) | ( inDataAg & inBtSlctAg);
            return;
        }
    }
}

template<class T> bool TcVrfyMkNm<T>::Compare(int inDataAg, int inBtSlctAg)
{
    int inAt;
    inAt=m_clBtSlct.ShiftBitInt(inDataAg);
    if ( inAt != -1){
        inDataAg = inAt;
    }
    switch ( sizeof(m_rT) ){
        case 1:{
           return( ((char&)m_rT ^ (char)inDataAg) & ((char)inBtSlctAg) )== 0;
        }
        case 2:{
            return( ((short&)m_rT ^ (short)inDataAg) & ((short)inBtSlctAg) )== 0;
        }
        default:{    // size == 4
            return( ((int&)m_rT ^ inDataAg) & (inBtSlctAg) )== 0;
        }
    }
}

//--------------------- TcVrfyMkNm End -----------------------------------

//--------------------- TcClFunctionVoid begin ------------------------------
// register class member function. 

template<class R, class T> class TcRgstFnctn: public ClBaseVerified{
    R(*m_pf)(T);
  public:
    TcRgstFnctn(R(*pfAg)(T), const std::string& crStrAg)
        :ClBaseVerified(crStrAg), m_pf(pfAg){}
    virtual void Set(const std::string& crStrAg)
    {
        ikStream iStrmAt(crStrAg);
        iStrmAt.unsetf(std::ios::basefield);
        T tAt;        
        iStrmAt >> tAt;
        m_pf(tAt);
    }
};

template<class R> class TcRgstFnctnVd: public ClBaseVerified{
    R(*m_pf)(void);
  public:
    TcRgstFnctnVd(R(*pfAg)(void), const std::string& crStrAg)
        :ClBaseVerified(crStrAg), m_pf(pfAg){}
    virtual void Set(const std::string& crStrAg){m_pf();}
    virtual void* GetInterruptFunction(void)
    {
        return m_pf;
    }
};


template<class R> class TcRgstFnctnStr: public ClBaseVerified{
    R(*m_pf)(const std::string&);
  public:
    explicit TcRgstFnctnStr(R(*pfAg)(const std::string&), const std::string& crStrAg)
        :ClBaseVerified(crStrAg), m_pf(pfAg){}

    virtual void Set(const std::string& crStrAg)
    {
        std::string strAt=crStrAg;
        if ( strAt[0] == '\"' ){
            strAt = strAt.substr(1, -1 + strAt.rfind('\"') );
        }
        m_pf(strAt);
    }
};



//Ty is application class
template<class Ty, class R> class TcClRgstFnctnVd: public ClBaseVerified{
    R(Ty::*m_pTyf)(void);
    Ty* m_pThis;
  public:
    TcClRgstFnctnVd(R(Ty::*pfAg)(void), Ty* pTyAg,const std::string& crStrAg)
        :ClBaseVerified(crStrAg), m_pTyf(pfAg), m_pThis(pTyAg){}
    virtual void Set(const std::string& crStrAg){(m_pThis->*m_pTyf)();}
};

template<class Ty, class R, class T> class TcClRgstFnctn: public ClBaseVerified{
    R(Ty::*m_pTyf)(T);
    Ty* m_pThis;
  public:
    TcClRgstFnctn(R(Ty::*pfAg)(T), Ty* pTyAg,const std::string& crStrAg)
        :ClBaseVerified(crStrAg), m_pTyf(pfAg), m_pThis(pTyAg){}
    virtual void Set(const std::string& crStrAg)
    {
        ikStream iStrmAt(crStrAg);
        iStrmAt.unsetf(std::ios::basefield);
        T tAt;        
        iStrmAt >> tAt;
        (m_pThis->*m_pTyf)(tAt);
    }
};

template<class Ty, class R> class TcClRgstFnctnStr: public ClBaseVerified{
    R(Ty::*m_pTyf)(const std::string&);
    Ty* m_pThis;
  public:
    TcClRgstFnctnStr(R(Ty::*pfAg)(const std::string&), Ty* pTyAg,const std::string& crStrAg)
        :ClBaseVerified(crStrAg), m_pTyf(pfAg), m_pThis(pTyAg){}
    virtual void Set(const std::string& crStrAg)
    {
        std::string strAt=crStrAg;
        if ( strAt[0] == _T('\"') ){
            strAt = strAt.substr(+1, -1 + strAt.rfind('\"'));
        }
        (m_pThis->*m_pTyf)(strAt);
    }
};


//--------------------- TcClRgstFnctnVd End -----------------------------------

//--------------------- tfRgst.... template funciton begin -------------------
// VC6.0 distingwish special template function polymorphism in a half-way manner
// in comparison with gcc2.95.2
bool RgstVerified(ClTestVct* pClTestVctAg, ClBaseVerified* pTAg );
bool RgstMonitored(ClTestVct* pClTestVctAg, ClBaseMonitored* pTcMonitoredAg );
bool RgstVfMt(ClTestVct* pClTestVctAg, ClBaseVerified* pTcVerifiedAg, ClBaseMonitored* pTcMonitoredAg );


//--------------------- tfRgst.... template funciton End -------------------

//--------------------- tfNew.... template funciton begin -------------------
template<class T> 
TcVerified<T>* tfNewVerified(T& rTAg, const std::string& crStrAg
        , long lgFlagAg = std::ios::hex)
{
    return new TcVerified<T>(rTAg, crStrAg/*, lgFlagAg*/);
}

template<class T> 
TcVrfyMkNm<T>* tfNewVerified(T& rTAg, int inBtSlctAg, const std::string& crStrAg
        , long lgFlagAg = std::ios::hex)
{
    return new TcVrfyMkNm<T>(rTAg, crStrAg, inBtSlctAg, lgFlagAg);
}

template<class T> 
TcVrfyFp<T>* tfNewVerified(T& rTAg, const std::string& crStrAg
        , double dbPrecisionRateAg)
{
    return new TcVrfyFp<T>(rTAg, crStrAg, dbPrecisionRateAg);
}

template<class T> 
TcVrfyCntnr<T>* tfNewVfCntnr(T& rTAg, const std::string& crStrAg)
{
    return new TcVrfyCntnr<T>(rTAg, crStrAg);
}

// floating point container verified template class
template<class T> 
TcVrfyCntnrFp<T>* tfNewVfCntnr(T& rTAg, const std::string& crStrAg
        , double dbPrecisionAg , long lgIosFlag=std::ios::scientific )
{
    return new TcVrfyCntnrFp<T>(rTAg, crStrAg, dbPrecisionAg, lgIosFlag);
}

template<class R, class T> 
TcRgstFnctn<R,T>* tfNewVfFnctn(R(*pfAg)(T), const std::string& crStrAg)
{
    return new TcRgstFnctn<R,T>(pfAg, crStrAg);
}

template<class R> 
TcRgstFnctnVd<R>* tfNewVfFnctnSpl(R(*pfAg)(void), const std::string& crStrAg)
{
    return new TcRgstFnctnVd<R>(pfAg, crStrAg);
}

template<class R> 
TcRgstFnctnStr<R>* tfNewVfFnctnSpl(R(*pfAg)(const std::string&)
        , const std::string& crStrAg)
{
    return new TcRgstFnctnStr<R>(pfAg, crStrAg);
}

template<class R> 
TcRgstFnctnStr<R>* tfNewVfFnctnSpl(R(*pfAg)(std::string&)
        , const std::string& crStrAg)
{
    return new TcRgstFnctnStr<R>(pfAg, crStrAg);
}


template<class Ty, class R, class T> 
TcClRgstFnctn<Ty, R,T>* tfNewVfClFnctn(Ty* pTy, R(Ty::*pfAg)(T)
        , const std::string& crStrAg)
{
    return new TcClRgstFnctn<Ty,R,T>(pTy, pfAg, crStrAg);
}

template<class Ty, class R> 
TcClRgstFnctnVd<Ty, R>* tfNewVfClFnctnSpl(Ty* pTyAg
    , R(Ty::*pfAg)(void), const std::string& crStrAg)
{
    return new TcClRgstFnctnVd<Ty,R>(pfAg, pTyAg , crStrAg);
}

template<class Ty, class R> 
TcClRgstFnctnStr<Ty, R>* tfNewVfClFnctnSpl(Ty* pTyAg
    , R(Ty::*pfAg)(const std::string&), const std::string& crStrAg)
{
    return new TcClRgstFnctnStr<Ty,R>(pfAg, pTyAg, crStrAg);
}


template<class T> 
TcMonitored<T>* tfNewMonitored(const T& rTAg, const std::string& crStrAg)
{
    return new TcMonitored<T>(rTAg, crStrAg);
}

template<class T> 
TcMonitored<T>* tfRgstMntrFp(const T& rTAg, const std::string& crStrAg
        , long lgFlagAg = std::ios::scientific)
{
    return new TcMonitored<T>(rTAg, crStrAg, true, lgFlagAg);
}

template<class T> 
TcMonitoredMkNm<T>* tfNewMonitoredX(const T& rTAg, int inBtSlctAg, const std::string& crStrAg
        , long lgFlagAg = std::ios::scientific)
{
    return new TcMonitoredMkNm<T>(rTAg, crStrAg, inBtSlctAg, lgFlagAg);
}

template<class T> 
TcMntrCntnr<T>* tfNewMtCntnr(const T& rTAg, const std::string& crStrAg)
{
    return new TcMntrCntnr<T>(rTAg, crStrAg);
}

//--------------------- tfNew.... template funciton End -------------------


}   //namespace kk
#endif //DfVrfyVar__

#endif  /* DfVrfy */
