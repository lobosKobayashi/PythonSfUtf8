#ifdef DfVrfy

#ifndef DfVrfyLibPrdc_H__
#define DfVrfyLibPrdc_H__

#include <CntxtVfBs.h>
#include<iostream>

//! If you use multi computer, then you have to define kk::ClVfIntfLibSgPrdc instance
//! because kk_pClVfIntfLibSgPrdcStt points only one default instance
namespace kk{
class ClVfIntfLibSgPrdc;
}

struct StLibPrdc{
    kk::ClVfIntfLibSgPrdc* m_pClVfIntfLibSgPrdc;
    double m_dbLoopingPeriod;
};

extern StLibPrdc stLibPrdcGlb;

namespace kk{

//ClCntxtIntfSgBasePrdc

class ClVfIntfLibSgPrdc : public ClVrfyIntfBasePrdc{
    //ClCntxtIntfSgBase* m_pClCntxtIntfSgBase;    // used by ClVfLibMthdPrdc
  public:
    ClVfIntfLibSgPrdc(ClCntxtIntfSgBasePrdc* pClAg, const std::string& crStrAg = "kk::VrfyLibPrdc")
        : ClVrfyIntfBasePrdc(pClAg, crStrAg){}
    ~ClVfIntfLibSgPrdc(void);

    static ClVfIntfLibSgPrdc* GetStt(StLibPrdc* pStAg = &stLibPrdcGlb
                        , const std::string& crStrNameAg = "kk::VrfyLibPrdc");// Used at ClVrfyIntfBase
    // ClCntxtIntfSgBasePrdc has the m_pTheVrfyIntf.
    static ClCntxtIntfSgBase* GetCntxtStt( StLibPrdc* pStAg = &stLibPrdcGlb
                        , const std::string& crStrNameAg = "kk::VrfyLibPrdc");
};



class ClVfLibActnPrdc : public ClTestVct{
  public:
    ClVfLibActnPrdc(const std::string crStrAg = "default"
                   , ClVfIntfLibSgPrdc* pClAg = ClVfIntfLibSgPrdc::GetStt());
};

//----------------------- Library timeup  ClVrfyTmup begin -----------------------
class ClVfLibMthdPrdc : public ClCntxtBase{
  protected:
    virtual void mainVl(void)
        { std::cout << "Warning::Use modified mainVl from ClVfLibMthdPrdc()" << std::endl; }
  public:
    ClVfLibMthdPrdc(kk::ClCntxtIntfSgBase* pClAg = ClVfIntfLibSgPrdc::GetCntxtStt());
    virtual void Start(TyTime tmDelayAg=TyTime(0));
            // 02.01.30 ����݂��Ȃ��^�X�N����� Start(.) �͏�� throw
            // --- ���ʂƂ��Ď��s�̔�΂����������邱�ƂɂȂ�
            // ���̓�̊֐��� systemC ���Ƃɂ������������߂ɒǉ����Ă���
            // �Č������K�v�ł��Bcodeing lefted
            void StartWithoutThrow(TyTime tmDelayAg=TyTime(0));
            void TerminateWithoutThrow(void);
    void DelayedStart( TyTime tmDelayAg=TyTime(0));
    virtual void Terminate(void);
    virtual EnmTaskState Wait(TyTime tmDelayAg = ctmMaxGlb);
};

//----------------------- Library timeup  ClVrfyTmup end -----------------------

}   //namespace kk
#endif  //DfVrfyLibPrdc_H__

#endif  /* DfVrfy */
