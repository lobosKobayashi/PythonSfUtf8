#ifdef DfVrfy

#ifndef DfVrfyLib_H__
#define DfVrfyLib_H__

#include <CntxtVfBs.h>
#include<iostream>

namespace kk{
class ClVfIntfLibSg;
class ClVfIntfLib;
extern ClVfIntfLibSg* kk_pClVfIntfLibSgStt; 
}


namespace kk{

class ClVfIntfLibSg : public ClVrfyIntfBasePrdc{
    ClCntxtIntfSgBase* m_pClCntxtIntfSgBase;    // used by ClVfLibMthd
  public:
    ClVfIntfLibSg(ClCntxtIntfSgBasePrdc* pClAg, const std::string& crStrAg = "kk::ClVfIntfLib")
        : ClVrfyIntfBasePrdc(pClAg, crStrAg){}
    ~ClVfIntfLibSg(void);

    static ClVfIntfLibSg* GetStt(ClVfIntfLibSg** ppClAg = &kk_pClVfIntfLibSgStt
                        , const std::string& crStrNameAg = "kk::ClVfIntfLib");// Used at ClVrfyIntfBase
    // ClCntxtIntfSgBase has the m_pTheVrfyIntf.
    static ClCntxtIntfSgBase* GetCntxtStt( ClVfIntfLibSg** ppClAg = &kk_pClVfIntfLibSgStt
                        , const std::string& crStrNameAg = "kk::ClVfIntfLib");
};



class ClVfLibActn : public ClTestVct{
  public:
    ClVfLibActn(const std::string& crStrAg = "default"
                   , ClVfIntfLibSg* pClAg = ClVfIntfLibSg::GetStt());
};

//----------------------- Library timeup  ClVrfyTmup begin -----------------------
class ClVfLibMthd : public ClCntxtBase{
  protected:
    virtual void mainVl(void)
        { std::cout << "Warning::Use modified mainVl from ClVfLibMthd()" << std::endl; }
  public:
    ClVfLibMthd(ClCntxtIntfSgBase* pClAg = ClVfIntfLibSg::GetCntxtStt());
    virtual void Start(TyTime tmDelayAg=TyTime(0));
            // 02.01.30 ����݂��Ȃ��^�X�N����� Start(.) �͏�� throw
            // --- ���ʂƂ��Ď��s�̔�΂����������邱�ƂɂȂ�
            // ���̓�̊֐��� systemC ���Ƃɂ������������߂ɒǉ����Ă���
            // �Č������K�v�ł��Bcodeing lefted
            void StartWithoutThrow(TyTime tmDelayAg=TyTime(0));
            void TerminateWithoutThrow(void);
    void DelayedStart( TyTime tmDelayAg=TyTime(0));
    virtual void Terminate(void);
    virtual EnmTaskState Wait(TyTime tmDelayAg = ctmMaxGlb);
};

//----------------------- Library timeup  ClVrfyTmup end -----------------------

}   //namespace kk
#endif  //DfVrfyLib_H__

#endif  /* DfVrfy */
