#ifndef DfContextBase_H__
#define DfContextBase_H__

#include <kcommon.h>
#include <list>
#include <setjmp.h>
#include<TestVct.h>

namespace kk{
#undef DfTickUnit_
#ifndef DfTickUnit_
    //STL task �ɂ��Ă� DfTickUnit �� 1 �ȊO�ɂ���Ӗ������Ȃ�
#   define DfTickUnit_ 1
#endif

//template<int inSizePrm = 2048>
#ifndef DfStackSize
#   define DfStackSize 2048
#endif

class ClCntxtIntfSgBase;
class ClCntxtIntfSgBasePrdc;
class ClVrfyIntfBase;
//class ClIntfSgBase;

class ClCntxtBase : public ClTime{
  protected:
    // to avoid affection of the ClCntxtBase::execute assembler code
    // by the code change, there must be innerStart() at this first position
    virtual void innerStart(void){ mainVl();}
    virtual void mainVl(void){assert(0);} // for fixed context switch
    
    ClCntxtIntfSgBase* m_pClCntxtIntfSgBase;
  public:
    ClCntxtBase(ClCntxtIntfSgBase* rpClAg):m_pClCntxtIntfSgBase(rpClAg){}
    enum EnmTaskState { // 
             EnDormant=0
            // wait() �̖߂�l�� m_enTaskState ���̂��̂̒l��Ԃ�
            //EnDefaulWait
            //EnWait indicates delay or infinite delay
            // If you wants know finite or infinite delay, you have to test
            //m_inDelay value
            ,EnWait // Time up �� Restart ����ʂ���
            ,EnLoopingWait
            ,EnTimeup=3
            ,EnStart =4
            // Wait or EnLoopingWait �ɑ΂��A���X�^�[�g�𔭍s����� EnRestart �ɂȂ�
            ,EnRestart
            , EnRun = 6
            , EnLoopRun
            //,EnDormant ��Ԃ� m_blReady == false, m_inDelay==0
            // �ɂȂ�B������ m_blReady,m_inDelay �̃N���A�͒x���\��������
            // Queue ����O�ꂽ�Ƃ��ɃN���A����邩��ł���B

            // context switched to terminate thread forcibly
            , EnTerminating  // k-uOS �ɂ͖����B�����ɋ����I���ł��邩��Bheap ���Ȃ�����
    };
    ClCntxtBase(void):m_enTaskState(EnDormant), m_blReady(false){}
            
    virtual ~ClCntxtBase(){}
  protected:
    enum EnmTaskState m_enTaskState;
    // if polling() return false then pop from m_pClPollingQueue
    virtual bool polling(void){assert(0); return true;} // must be modified by inheritance
    virtual void makeTerminatedState(void);
  public:
    virtual void Start(TyTime tmDelayAg = ClLongIn(0) );
    virtual void Restart(int enTaskStateAg = EnRestart);
    virtual EnmTaskState Wait(TyTime tmDelayAg = ctmMaxGlb);
    virtual void Terminate(void);

    virtual bool IsDefaultWait(void){ return m_enTaskState == EnWait;}
    virtual bool IsTerminated(void){ return m_enTaskState == EnDormant;}

  
    // user don't call polling(), only kVerifier call polling
  public:
    static void ExecuteStt(void);

    bool m_blReady;
  private:
    int inDamie;    // assembler code �ł� m_BP_SP offset �� 28==0x1c EnBtInterrupt�ɍ��킹��
//------------  Groupt ���� Beigin --------------
    //�p������ addToReadyQue() �����������Apush_front ���g���ėD����s�����邱�Ƃ�
    //�ł���BStl task �ŁA�����܂ł��邱�Ƃ͏��Ȃ��̂Ŏ������Ȃ��B
    //one chip k-uOS �ł͗D�悵�Ď��s����^�X�N������̂� push_front ����������
    // Only describing circuit, we d0n't need removeFromPollingQue
  protected:
    virtual void addToReadyQue(void);
    virtual void addToLoopingQue(void);
    virtual void AddToPollingQue(void);
//------------  Thread Groupt ���� End --------------
    //virtual void execute(void);
    virtual void execute(void);
    virtual void executeTaskLoop(void);
    virtual bool testAndSetReady(void);

    friend class ClCntxtIntfSgBase;
    friend class ClCntxtIntfSgBasePrdc;
};

// simple Thread group base class 
// Thread group base class which has m_pClTerminatedQueue, ..m_pClLoopingQueue
class ClCntxtIntfSgBase{
  protected:
    std::list<ClCntxtBase*>* m_pClPollingQueue;
    std::list<ClCntxtBase*>* m_pClDelayQueue;
    std::list<ClCntxtBase*>* m_pClReadyQueue;
    std::list<ClCntxtBase*>* m_pClLoopingQueue;

    ClCntxtBase* m_pLeastNextThread ;
    TyTime m_tmExecutingNextThread;
    //!< tickCntxt() at true:Spccification:: all time 
    //!<                 or false:Simulation: scheduling period
    int m_inIntfLoopCount;

    virtual void executeLoopingQue(void);
    void executeReadyQue(void);
    void endTerminatedQue(void);
    virtual bool IsEnded(void);
    // VrfyClTh may inherit SetNextExecutingTime().
    virtual void SetNextExecutingTime(void);
    virtual TyTime getLoopingPeriod(void){ return TyTime(1,k_S);/* defaullt 1 sec*/}
    void processAfterThread(ClCntxtBase* pClAg);
    void (*m_pfInterrupt)(void);
  public:
    //ClVrfyIntfBase* m_pTheVrfyIntf; //02.02.15 codeing lefted ��łȂ���
    //ClVrfyIntfBase* m_pClVrfyIntfBase;
    ClCntxtIntfSgBase(void)
        : m_pLeastNextThread(0), m_inIntfLoopCount(0)
        , m_pfInterrupt(0)
    {
        m_pClPollingQueue = new std::list<ClCntxtBase*>;
        m_pClDelayQueue = new std::list<ClCntxtBase*>;
        m_pClReadyQueue = new std::list<ClCntxtBase*>;
        m_pClLoopingQueue = new std::list<ClCntxtBase*>;
        m_tmExecutingNextThread = ClLongIn(999999999,999999999,999999999);
    }
    //static  ClCntxtIntfSgBase* Get(void); 
    virtual ~ClCntxtIntfSgBase(void)
    {
        delete m_pClPollingQueue;
        delete m_pClDelayQueue;
        delete m_pClReadyQueue;
        delete m_pClLoopingQueue;
    };    

    virtual TyTime whatNextCntxtTime(void) const;
    virtual bool tickCntxt(void);
    virtual void AddToPollingQue(ClCntxtBase* pClAg);
    virtual void EraseFromPollingQue(ClCntxtBase* pClAg);
    virtual void AddToDelayQue(ClCntxtBase* pClAg);
    virtual void EraseFromDelayQue(ClCntxtBase* pClAg);
    virtual void AddToReadyQue(ClCntxtBase* pClAg);
    virtual void EraseFromReadyQue(ClCntxtBase* pClAg);
    virtual void AddToLoopingQue(ClCntxtBase* pClAg);
    virtual void EraseFromLoopingQue(ClCntxtBase* pClAg);
    virtual int WhatNowCount(void){ return m_inIntfLoopCount;}
    //! call only from void ClVrfyIntfBase::Tick(void)
    virtual bool callInterrupt(void);
    virtual bool ExecuteLoopingThread(void);
    virtual void IncLoopingNext(void);

    virtual void terminatedAtEnd(void);

    virtual bool DifferedInterruptCall( void(*pfAg)(void) );
    //02.01.22 coding lefted
    //virtual DelayWithCpu(.)

    friend class ClVrfyIntfBase;
};

class ClTestVct;
class ClFileLine;
// thread verifier interface
class ClVrfyIntfBase {
  protected:
    // �o�̓t�@�C���Ƀ��[�v�E�J�E���g���o�͂���Ƃ��ɁAm_cStrInstnace �̖��O���g��
    const std::string m_cStrInstnace; // reffered by instruciton file
    int m_inActnNextLoopCount;
    int m_inLoopBreak;
    TyTime m_tmNextVctTick;
    TyTime m_tmBreak;
    TyTime m_tmAlive;
    std::list<ClTestVct*> m_lstpClTestVct;

    virtual void tickTestVctPolling(void);
    virtual void tickMonitor(void);
    virtual void tickSet(void);
    // get minimum time from task group or main loop delay

  public:
    ClVrfyIntfBase( ClCntxtIntfSgBase* pClSgAg, const std::string& crStrNameAg="");
    virtual ~ClVrfyIntfBase(void){}
    virtual void AddTestVct(ClTestVct*);
    virtual void Initialize(const std::string crStrAg);
    virtual void TickInitially(void);
    virtual bool IsEnded(void);
    virtual void SetAliveTime(TyTime tmAg);
    virtual bool IsRegistered(const std::string crStrAG);
    // ClVrfySglt::Tick() �̒��ŁAreuturn �����邩�A���� ClVrfyIntfBase ��
    // Tick() �𔭍s���邩�𔻒肷��

    virtual int WhatNowCount(void){ return m_pClCntxtIntfSgBase->WhatNowCount();}
    
    virtual void SetNextTickTimeCount(void);
    std::string WhatName(void){ return m_cStrInstnace;}
    void ParseInstrucitonFile( ClFileLine& rClFileLineAg);

    virtual void Restart(const std::string& crStrTestVctInstanceAg
            , const std::string& crStrWaitAg="");

    virtual TyTime GetTickTime(void) const;

  public:
    virtual void tickCntxt(void){assert(0);}
    virtual void terminatedAtEnd(void){}    // used at timeup

  protected:
    ClCntxtIntfSgBase* m_pClCntxtIntfSgBase; //!< m_pClCntxtIntfSgBase is set by GetStt() in ClCntxtIntfSgBase inheritance class
  public:

    //01.06.06 ������ breakCount ��ݒ�ł���悤�ɂ���
    void SetBreakCount(int inAg){/*m_inLoopBreak = m_inIntfLoopCount+ inAg;*/}

    virtual void Tick(void);
    
    //! needed to determine ClTestVect::m_enTime :: log time precition
    virtual TyTime GetLoopingPeriod(void)
    {
        return m_pClCntxtIntfSgBase->getLoopingPeriod();
    }
    virtual bool DifferedInterruptCall( void(*pfAg)(void) )
    {
        return m_pClCntxtIntfSgBase->DifferedInterruptCall(pfAg);
    }

};


class ClCntxtIntfSgBasePrdc : public ClCntxtIntfSgBase{
  protected:
    TyTime m_tmLoopingPeriod;
    //!j m_tmLoopingNext ���^�C���A�b�v����� m_tmLoopingPeriod �������炳�ꂽ���̎����ɐݒ肳��܂�
    //!e a time up of tmSchedulingNextt, m_tmLoopingPeriod is postponed by m_tmLoopingPeriod
    //!e First value of m_tmNextScheduling, which constructor sets, means first scheduling inhibit length
    //!j �R���X�g���N�^���ݒ肷�� m_tmNextScheduling �����l�́A�X�P�W���[�����O�֎~���Ԃ̈Ӗ��������܂�
    TyTime m_tmLoopingNext;

    bool tickCntxt(void);
    virtual TyTime getLoopingPeriod(void){ return m_tmLoopingPeriod;}
  public:
    ClCntxtIntfSgBasePrdc(TyTime tmSchedulingPeriodAg = TyTime(1, k_mS)
        , TyTime tmInitInhibitCountAg = TyTime(0) )
        :m_tmLoopingPeriod(tmSchedulingPeriodAg),  m_tmLoopingNext(tmInitInhibitCountAg){}

    virtual void executeLoopingQue(void);
    virtual bool ExecuteLoopingThread(void);
    virtual void IncLoopingNext(void);
    void SetLoopingPeriod(const TyTime& tmAg)
    {
        m_tmLoopingPeriod = tmAg;
    }
    virtual TyTime whatNextCntxtTime(void) const;

};

class ClVrfyIntfBasePrdc : public ClVrfyIntfBase{
  public:
    ClVrfyIntfBasePrdc( ClCntxtIntfSgBasePrdc* pClSgAg, const std::string& crStrNameAg="")
            :ClVrfyIntfBase(pClSgAg, crStrNameAg){}
    virtual ~ClVrfyIntfBasePrdc(void){}
    virtual void Tick(void);
};




}   // name space kk
#endif // DfContextBase_H__
