#ifdef DfVrfy
#ifndef DfTestVct__
#define DfTestVct__
#pragma warning(disable:4786)

#include <kcommon.h>
#include <Verifier.h>
#include <VrfyVar.h>
#include <CntxtVfBs.h>

//#include <iostream>
#include <list>
#include <set>
#include <string>
#include <fstream>
#include <sstream>

//#include <FileLine.h>

namespace kk{
//using namespace std;
 
class ClVrfyIntfBase;

class ClTestVct{
  private:
    const std::string m_cStrTestVctName;
    std::string m_strFirst;
    std::string m_strSecond;
  protected:
    bool   m_blEnd;
  public:
    ClTestVct(ClVrfyIntfBase* pClAg, const std::string& crStrAg="");
    virtual ~ClTestVct();
    bool IsEnded(void){return m_blEnd;}

    virtual void doAtInitialVl( const std::string& crStrAg);
    const std::string& WhatYourName(void){ return m_cStrTestVctName;}
  protected:
    TyTime m_tmNextTick;    // written at SystemC interface
    int m_inNextLoopCount;  // at wait mode, m_inNextLoopCount has offset value
    
    // regiss ClTestVct instances for *m_pClVrfyIntfBase
    ClVrfyIntfBase* m_pClVrfyIntfBase;
//del03.04    virtual bool isChanged(const std::string& crStrAg);
    virtual void tickTestVctPolling(void){} // use to describe complex synronization
    virtual void tickMonitor(void);
    virtual void tickSet(void);
    void parseLine(const std::string& crStrAg);
    std::string makeTimeCountString(void);
    virtual void setAliveTime(TyTime tmAg);
    //! Decide rough display time unit
    EnmTime m_enTime;
    //!J�FVrfyClTh, VrfySysC �ł� Test Vector instance ���̗ݐσN���b�N����Ԃ�
    //!E: At VrfyClTh andVrfySysC, whatNowCount() returns cumulative clock count
    virtual int whatNowCount(void);
    //! define default count time, rough time display unit 
    void setEnmTime( EnmTime enAg){ m_enTime = enAg; }
  public:
    //ClTestVct(void);
    virtual TyTime GetTickTime(void) const;
    void SetNextTickTime(TyTime tmAg){ m_tmNextTick = tmAg;}
    virtual int GetNextLoopCount(void){ return m_inNextLoopCount;}

    void SetBreakLine(int inLineNumAt ){ m_inLinBreakNum = inLineNumAt;}
    virtual bool IsBreakLine(void){ return m_inLinBreakNum == m_inLineNum;}
    bool IsWaiting(void);
    virtual void Restart(const std::string& crStrSourceIdAg="", const std::string& crStrWaitAg="");
   void OutError(const std::string& );
   void OutOK(const std::string& );

  //private:
  protected:    // 03.01.27 coding lefted to compile systemc test code
    std::string m_strFileName;
    int    m_inLineNum;
    int    m_inTempLineNum;
    std::list<std::string> m_lstStrComment;
    // print Time/Count indicator flag
    bool m_blTime_Count;
    //parallel test vector line buffer with time
    //std::auto_ptr<ClTmString>  m_apClTmString;
    ka<ClTmString>  m_apClTmString;
    ka<ClCountString>  m_apClCountString;
    
    // m_strWait indicates an waiting kind. If EnnWait(strAg)'s argment
    // and m_strWait are same then the waiting state is canceled.
    //
    int    m_inLinBreakNum;
    std::string m_strWait;
  protected:
    //parallel test vector line buffer with count
    virtual bool getTestVctCommand(void);   //03.01.26 coding lefted virtual �ɂ��Ȃ��Ă��ςނ�������Ȃ�><-- private �ɖ߂��邩������Ȃ�
    virtual void setTimeCountString(const std::string& crStrTimeCountAg );
    virtual std::string addTimeCountLineNum(    //03.01.26 coding lefted virtual �ɂ��Ȃ��Ă��ςނ�������Ȃ�<-- private �ɖ߂��邩������Ȃ�
            const std::string& crStrAg, bool blAddFileNameAg = true);

  //private:
  protected:    // 03.01.27 coding lefted to compile systemc test code
    //strint m_strBuffNow;    //char* pChBufNow;
    std::string m_strBuff;        // pChBufAll delete[] pCh �̂��߂ɕK�v�ł���
    std::ifstream m_ifstream;     //m_pFileIn;
    kk::ksci m_ksci;

    virtual void openTestVct(const std::string& crStrAg);
    void get1lineAndGetTime();
    bool isLastEscChar(const std::string&);

  public:
    bool IsOpend(void){ return m_strFileName != ""; }
#ifdef _DEBUG
    // simulation file ���J���Ȃ��Ƃ��A__end ���������Ƃ� m_pFileIn=NULL �Ƃ���B
    const char *m_pChInputFileName;   // �f�o�b�O�p�ɐ݂����ϐ��ł���
#endif // _DEBUG
  private:
    std::list<ClBaseVerified*> m_lstpClBaseVerified;
    std::list<ClBaseMonitored *> m_lstpClBaseMonitored;
    class kk::ClGarbageEraser* m_pClGarbageEraser;
  public:
    void AddClBaseVerified(ClBaseVerified* pClAg){ m_lstpClBaseVerified.push_back(pClAg);}
    void AddClBaseMonitored (ClBaseMonitored* pClAg)
            { m_lstpClBaseMonitored.push_back(pClAg);}
    kk::ClGarbageEraser* GetGarbageEraser(void){ return  m_pClGarbageEraser;}
  
    ClBaseMonitored* whereIsMonitored(const std::string& crStrAg);
    //! False value is returned if double launch of interrupt function is detected.
    virtual bool DifferedInterruptCall( void(*pfAg)(void) );
  protected:
  public:
    // WhereIsVerified() search m_lstpClBaseVerified verified variable name
    // If it find out that the argment name is registered then return 0 pointer.
    ClBaseVerified* WhereIsVerified(const std::string& crStrAg);
    bool IsRegisteredVar(const std::string& crStrAg)
    {
        if ( WhereIsVerified(crStrAg) || whereIsMonitored(crStrAg) ){
            ClVrfySglt::GetStt()->OutWarning(
                crStrAg 
                  + " is registered already. We ignore this registering"
            );
            return true;
        }else{
            return false;
        }
    }

#ifdef debugX
#endif //debugX
};

inline bool lessTimeClTestVct(const ClTestVct* cpClAgA, const ClTestVct* cpClAgB)
{
    return cpClAgA->GetTickTime() < cpClAgB->GetTickTime();
}

}   //namespace kk
#endif // DfTestVct__

#endif //DfVrfy
