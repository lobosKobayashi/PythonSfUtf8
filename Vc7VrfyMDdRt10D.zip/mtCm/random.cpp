/*   ���̃v���O�����̒��쌠�� kVerifeir Lab ���ь������ۗL���܂��B ���̃v���O������
 * ����Ă����Ȃ��Q�E�������������Ă��A��҂͈�ؐӔC�𕉂��܂���B���̃v���O����
 * ��񎟔z�z���邽�߂ɂ� kVerifeir Lab ���ь����̕����ɂ�鏳����K�v�Ƃ��܂��B
 *   ���̃v���O�������z�z���ꂽ zip �t�@�C�����̂��̂�F�l�ɃR�s�[���ēn�����Ƃ͔F
 * �߂܂����A�l�b�g��ŕs���葽���ɔz�z���邱�Ƃ͂��~�߂��������B
 *
 *    �]�����Ԉꃖ���𒴂��Ă��̃v���O�������g�p����ɂ̓\�t�g�g�p���̎x�������K�v��
 *  ���B�ڍׂ� http://www.nasuinfo.or.jp/FreeSpace/kenji/���Q�Ƃ��邩�A
 *      kenji@nasuinfo.or.jp ���� kverifierlab@yahoo.co.jp\n
 *  �ɂ��q�˂��������B"
 */

//���� http://www.nims.go.jp/cmsc/pst/koyama/docs/mathmatics/random_number.pdf
//random.cpp �� 0x7fffffff �͈̔͂Ōv�Z�����Ă���<== random.cpp �� TyUi �𓱓�����K�R���͂Ȃ�
//�ł��A2^32-1 �͈̔͂Ōv�Z���\�� m(a,r,q) �p�����[�^��������ꂽ�Ƃ��A�����ɏC���ł��܂�
//random 
//������ [0,...Range) �̃����_���ϐ��𐶐�����B
//�����ł� 0 �̐��l�� 0 �ɂȂ��Ă��܂��̂ŁA+1 �������l�ɕϊ����Čv�Z����
#ifndef DfRandom_H_
#define DfRandom_H_
#endif  //DfRandom_H_
//random(int size, int seed=0, int range=0x7fff) �Ǝg��

#include<kcommon.h>
#include<kAssert.h>
#include<assert.h>
#include<algorithm>
#include<iostream>
#include<valarray>
#include<complex>
#include<cmath>

using namespace std;

#include <sfMtrx.h>
using namespace kk;
namespace kk{
extern void GetRightSideVal(const string& crStrResidualAg, ClTerm& rClResultAg);
}   //namespace kk

typedef unsigned int TyUi ;
//#define dfMax 4294967295    //0xffffffff
#define dfMax 2147483647    //0x7fffffff
const TyUi cUiAStt=16807;        //7^5;
const TyUi cUiMStt = 2147483647; //2^31-1
const TyUi cUiRStt=2836;
const TyUi cUiQStt=127773;



static inline TyUi getIntegerQuotinent(TyUi uiLeftAg, TyUi uiRightAg)
{
    TyUi uiAt =  (uiLeftAg - uiLeftAg % uiRightAg) / uiRightAg;
    return uiAt;
}

static TyUi getRandomIndex(TyUi uiRandomAg, TyUi uiSizeAg)
{
    return getIntegerQuotinent(uiRandomAg
                            , 1 + getIntegerQuotinent( (cUiMStt-1), uiSizeAg)
                              );
}

//random('size, seed, range )
static TyUi random(TyUi uiSeedAg)
{
    kAssert("Internal Error: seed is 0.", uiSeedAg != 0);

    TyUi uiA_modZQAt = cUiAStt*(uiSeedAg%cUiQStt);
    TyUi uiR_QtntZQAt = cUiRStt*getIntegerQuotinent(uiSeedAg, cUiQStt);

    if ( uiA_modZQAt > uiR_QtntZQAt){
        return uiA_modZQAt - uiR_QtntZQAt;
    }else if ( uiA_modZQAt < uiR_QtntZQAt){
        return uiA_modZQAt - uiR_QtntZQAt + cUiMStt;
    }else{
        kAssert("Internal Error: detect  random value", false);
        return 0;
    }
}

static TyUi convert(const string& crStrAg)
{
    TyUi uiAt;

    istringstream istrmAt(crStrAg);
    istrmAt.unsetf(ios::basefield);

    if( (crStrAg.size() >= 3) 
     && (crStrAg[0]=='0') 
     && (crStrAg[1]=='x') 
    ){
        // Hex value
        kAssert("Too long hex number string: " + crStrAg, crStrAg.size() <= (8+2) );
        kAssert("There is a wrong character in hex number string: "+crStrAg 
                , crStrAg.find_first_not_of("0123456789abcdef",2)==string::npos);
        istrmAt >> uiAt;
        kAssert(crStrAg+ " is a too large number. please input a number less than 2^32-1==4294967295 "
                , uiAt < dfMax );
    }else{
        // decimal value
        kAssert("There is a wrong character in dec number string: "+crStrAg 
                , crStrAg.find_first_not_of("0123456789",2)==string::npos);
        double dbAt;
        istringstream istrmDbAt(crStrAg);
        istrmDbAt >> dbAt;
        //cout << "debug:" <<dbAt << endl; //to debug
        
        kAssert(crStrAg+ " is a too large number. please input a number less than 2^32-1==4294967295 "
                , dbAt < dfMax );
        istrmAt >> uiAt;
    }
    return uiAt;
}

int main(int argc, char** argv)
{
    TyUi uiSizeAt=10;
    TyUi uiSeedAt = 0;
    TyUi uiRangeAt= dfMax;
    
    if ( (argc > 4)
        || (argc < 2)
       ){
        cout << "Please input random \"unsigned int size\" \"unsigned int seed=0\" \"unsigned int range=0x7fffffff\" "  << endl;
        return 5;
    }

    if ( argc >= 2){
        if ( (argv[1][0] == '-')
           ||(argv[1][0] == '/')
        ){
            cout << "Please input random \"unsigned int size\" \"unsigned int seed=0\" \"unsigned int range=0x7fffffff\" "  << endl;
            return 5;
        }
    }

    if (*argv[1] == '_'){
        ClTerm clTermAt;

        // Convert data from argv sf variable
        GetRightSideVal(argv[1], kr clTermAt);
        kAssert("random.exe detect abnormal argment at _argv[1]."
                ,  (clTermAt.m_blCmplx == false )
                && (clTermAt.m_vlrDb.size() == 1)
               );
        uiSizeAt = static_cast<int>(clTermAt.m_vlrDb[0]);

        kAssert("random.exe detect 0 value argment at _argv[1]."
                ,  uiSizeAt > 0
               );

        if ( argc >=3 ){
            GetRightSideVal(argv[2], kr clTermAt);
            kAssert("random.exe detect abnormal argment at _argv[2]."
                    ,  (clTermAt.m_blCmplx == false )
                    && (clTermAt.m_vlrDb.size() == 1)
                   );
            uiSeedAt = static_cast<int>(clTermAt.m_vlrDb[0]);

            kAssert("random.exe detect 0 value argment at _argv[2]."
                ,  uiSeedAt >= 0
               );

            kAssert(string(argv[2])+ ":seed is a too large number. please input a number less than 2^32-2==4294967294 "
                    , uiSeedAt < dfMax );
        }

        if ( argc ==4 ){
            GetRightSideVal(argv[3], kr clTermAt);
            kAssert("random.exe detect abnormal argment at _argv[3]."
                    ,  (clTermAt.m_blCmplx == false )
                    && (clTermAt.m_vlrDb.size() == 1)
                   );
            //uiSeedAt = clTermAt.m_vlrDb[0];

            uiRangeAt = static_cast<int>(clTermAt.m_vlrDb[0]);
            kAssert("random.exe detect 0 value argment at _argv[3]."
                ,  uiRangeAt > 0
               );

            
            kAssert(string(argv[2])+ ":seed is a too large number. please input a number less than 2^32-2==4294967294 "
                    , uiSeedAt < dfMax );
        }
        ++uiSeedAt;
    }else{
        uiSizeAt = convert(argv[1]);
        kAssert(string("You set bad size parameter: ")+argv[1], uiSizeAt >0);
        if ( argc >= 4){
            uiRangeAt = convert(argv[3]);
        }
    
        if ( argc >= 3){
            uiSeedAt = convert(argv[2]);
    
            kAssert(string(argv[2])+ ":seed is a too large number. please input a number less than 2^32-2==4294967294 "
                    , uiSeedAt < dfMax );
        }
        ++uiSeedAt;
    
    }

    if ( uiSizeAt >= 0x00ffffff ){
        //���̒l�𒴂����T�C�Y���������Ƃ���� valarray<double> �� allocator �� slashing �𔭐�������
        return 6;
    }
    // make initial value random 
    uiSeedAt = random( uiSeedAt);
    uiSeedAt = random( uiSeedAt);
    uiSeedAt = random( uiSeedAt);
    uiSeedAt = random( uiSeedAt);
    uiSeedAt = random( uiSeedAt);
    uiSeedAt = random( uiSeedAt);
    uiSeedAt = random( uiSeedAt);
                      
    valarray<TyUi> vlrUiAt(TyUi(0), size_t(uiSizeAt) );
    for( TyUi i=0; i<uiSizeAt; ++i){
        uiSeedAt =  random( uiSeedAt);
        vlrUiAt[i] = uiSeedAt;
    }


    //�؂荬��
    TyUi uiIndexAt=0;
    TyUi uiValueAt = vlrUiAt[uiIndexAt];
    for( TyUi i=0; i< 2*uiSizeAt; ++i){
        uiIndexAt = getRandomIndex(uiValueAt, uiSizeAt);
        uiValueAt = vlrUiAt[uiIndexAt];
        uiSeedAt =  random( uiSeedAt);
        vlrUiAt[uiIndexAt] = uiSeedAt;
    }
    //cout << "vlrUiAt2:" << tfGetStrVal(vlrUiAt) << endl; //debug


    ClTerm clTermAt;
    clTermAt.m_vlrDb.resize(uiSizeAt);
    // make less than uiRangAt
    for( TyUi i=0; i<uiSizeAt; ++i){
        clTermAt.m_vlrDb[i] =  vlrUiAt[i] % uiRangeAt;
    }

    cout << tfGetStrVal(clTermAt.m_vlrDb) << endl;

    clTermAt.m_strVarName = "_rs.val";
    clTermAt.PrintTerm();
    return 0;
}

//@@@
//cl random.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\  sfMtrxML.obj vrfyNpML.lib

//cl random.cpp /MDd /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\  sfMtrxMDd.lib vrfyMDd.lib

//cl random.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\  sfMtrx.obj vrfyML.lib child.obj kernel32.lib user32.lib netapi32.lib

//gcc random.cpp -g -I.\ -Ivrf\ -D"DfGcc_" libstdc++.a

//cl random.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\


//cl random.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\  sfMtrx.obj vrfyML.lib



