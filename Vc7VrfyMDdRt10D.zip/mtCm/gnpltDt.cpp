// ren a.exe gnpltDt.exe
//03.11.29 convert data to gnuplot <-- 
//gnuplot �f�[�^�[�E�u���b�N�͉��s�����K�v�ł�
#include "kreg.h"
using namespace std;
using namespace kk;

static krgstr krgScientificNumericTermStt("([+-]?[0-9]+(`.[0-9]*|(`.[0-9]+)?e[+-]?[0-9]+)?)?(i?)", krgstr::EnIgnoreSmall);

// <3i,4+i,0, 3> �̂悤�Ȑ��l�̂Ƃ�������
static void getAndCheckNumeric(string& rStrResidualAg)
{
    ostringstream  oStrStrmAt("");
    oStrStrmAt.precision(16);

    //cout << "debug 1:" << rStrResidualAg << endl;
    if ( rStrResidualAg/ krgScientificNumericTermStt == ""){
        kAssert( "Abnomal data format:"+rStrResidualAg, false);
    }else{
        istringstream istrmAt(krgScientificNumericTermStt % 1);
        //Below code affects krgScientificNumericTermStt % 3 because it reffered to rStrResidualAg
        //rStrResidualAg = krgScientificNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
        double dbAt;
        istrmAt >> dbAt;
        if ( krgScientificNumericTermStt % 4 == "i"){
            rStrResidualAg = krgScientificNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
            kAssert( "Abnomal data format:"+rStrResidualAg, rStrResidualAg == "");
            oStrStrmAt << "0    " << dbAt;
            cout << oStrStrmAt.str();
            return;
        }else{
            rStrResidualAg = krgScientificNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
            oStrStrmAt << dbAt;
        }
    }

    //cout << "debug 2:" << rStrResidualAg << endl;
    if ( rStrResidualAg == ""){
        // If there is no complex number then print 0;
        oStrStrmAt << "    0";
    }else if ( rStrResidualAg/ krgScientificNumericTermStt != ""){
        // there is complex number after real number
        kAssert("Abnomal complex number data format:"+rStrResidualAg
                , krgScientificNumericTermStt % 4 == "i");

        istringstream istrmAt(krgScientificNumericTermStt % 1);

        rStrResidualAg = krgScientificNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
        kAssert("Abnomal string after complex number data:"+rStrResidualAg
                , rStrResidualAg == "");

        double dbAt;
        istrmAt >> dbAt;
        oStrStrmAt << "    " << dbAt;
    }else{
        kAssert( "Abnomal data format:"+rStrResidualAg, rStrResidualAg == "");
    }

    cout << oStrStrmAt.str();
    return;
}

int main(int argc, char** argv)
{
    //cout << endl;
    kDfEachLineFromArg1File(){
        if ( (strLineAt_.size()>=2) && ( strLineAt_.find("#g") == 0) ){
            cout << strLineAt_.substr(2) << endl;
            continue;
        }
        if ( strLineAt_[0]=='<' ){
            int inAt = 0;
            istringstream istrmAt(string( ++strLineAt_.begin(), strLineAt_.end()-2));
            while (!istrmAt.eof()){
                cout << inAt++ << "    ";
                string strAt;
                getline(kr istrmAt,kr strAt, ',');
                //cout << "debug 3:" << strAt << endl;
                getAndCheckNumeric(kr strAt );
                cout << endl;
            }
            cout << endl;
            cout << endl;
        }else{
            continue;
        }
    }
    return 0;
}
//cl gnpltDt.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\  sfMtrxML.obj vrfyNpML.lib

//cl gnpltDt.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Za /Zm200 vrfyML.lib
