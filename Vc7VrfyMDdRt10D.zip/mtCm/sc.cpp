/*   ���̃v���O�����̒��쌠�� kVerifeir Lab ���ь������ۗL���܂��B ���̃v���O������
 * ����Ă����Ȃ��Q�E�������������Ă��A��҂͈�ؐӔC�𕉂��܂���B���̃v���O����
 * ��񎟔z�z���邽�߂ɂ� kVerifeir Lab ���ь����̕����ɂ�鏳����K�v�Ƃ��܂��B
 *   ���̃v���O�������z�z���ꂽ zip �t�@�C�����̂��̂�F�l�ɃR�s�[���ēn�����Ƃ͔F
 * �߂܂����A�l�b�g��ŕs���葽���ɔz�z���邱�Ƃ͂��~�߂��������B
 *
 *    �]�����Ԉꃖ���𒴂��Ă��̃v���O�������g�p����ɂ̓\�t�g�g�p���̎x�������K�v��
 *  ���B�ڍׂ� http://www.nasuinfo.or.jp/FreeSpace/kenji/���Q�Ƃ��邩�A
 *      kenji@nasuinfo.or.jp ���� kverifierlab@yahoo.co.jp\n
 *  �ɂ��q�˂��������B"
 */
#include <cmath>
#include<fstream>
#include<sstream>
#include<iostream>
#include<complex>
#include "kcommon.h"
#include "kAssert.h"
#include "kreg.h"
#include "sfMtrx.h"
using namespace std;
//using namespace kk;
namespace kk{

static void cutFrontRearWhiteSpace( string& rStrAg);
static int convertBinStr2Int(const string& crStrAg);
       void GetRightSideVal(const string& crStrResidualAg, ClTerm& rClResultAg);
static void getVectorVal( const string& crStrAg, ClTerm& rClTermAg);
static void makeCplxInvs( ClTerm&  rClTermAg);
static void makeInverse( ClTerm&  rClTermAg);
static void mtrxCommand(const string& crStrAg, ClTerm& rClTermResultAg);

// ================= may be changed for other tield  begin ========================
const int inDigitSizeStt = 10;

//! (char*, char*) list for priority table
//! Priority table. You must put in ascending order of "left < righ string pare"
const struct{
    char* m_pChLeft;
    char* m_pChRight;
} stArPchPriorityStt [] = 
{
    {"+", "*"}, {"+", "/"}, {"+", "$"},
    {"-", "*"}, {"-", "/"}, {"-", "$"},
    {"+", "$"}, {"-", "$"}, {"*", "$"}, {"/", "$"},
    {"+", "^"}, {"-", "^"}, {"*", "^"}, {"/", "^"},
    {"$", "^"},
    {0,0}   // end mark
};

string strBinaryOperatorStt("+-*/^%$");

static krgstr krgBinaryNumericTermStt("^0b[01_]+", krgstr::EnIgnoreSmall);
static krgstr krgHexNumericTermStt("^0x[0-9A-F]+",  krgstr::EnIgnoreSmall);
//static krgstr krgFloatNumericTermStt("([+-]?([0-9]+|[0-9]+(\\.?[0-9]+)?|[.]?[0-9]+))");
//static krgstr krgFloatNumericTermStt("[0-9]+|[0-9]+(\\.?[0-9]+)?|[.]?[0-9]+");
static krgstr krgFloatNumericTermStt("^[+-]?[0-9]+(`.?[0-9]*)?|[`.]?[0-9]+");
//static krgstr krgScientificNumericTermStt("([+-]?([0-9]+`.[0-9]*|[.][0-9]+)e[+-]?[0-9]+)", krgstr::EnIgnoreSmall);
//static krgstr krgScientificNumericTermStt("^([0-9]+(`.[0-9]*)?|[`.][0-9]+)e[+-]?[0-9]+", krgstr::EnIgnoreSmall);
//! 1e23 ���l�\�������艺�̂悤�ɏC������
//static krgstr krgScientificNumericTermStt("^([0-9]+(`.[0-9]*)?|(`.[0-9]+)?)e[+-]?[0-9]+", krgstr::EnIgnoreSmall);
//! 13e23 �� 13 e23 �̂悤�� 13 �� e23 �ϐ��Ƃ̐ςƂ݂Ȃ��B exp �\���̌�ɂ� +/- �L����K�{�Ƃ���
static krgstr krgScientificNumericTermStt("^([0-9]+(`.[0-9]*)?|(`.[0-9]+)?)e[+-]([0-9]+)", krgstr::EnIgnoreSmall);


static void convertRealToComplex( ClTerm& rClAg)
{
    if (rClAg.m_blCmplx == false){
        rClAg.m_vlrCplxDb.resize( rClAg.m_vlrDb.size() );
        for ( size_t i=0; i< rClAg.m_vlrDb.size(); ++i){
            rClAg.m_vlrCplxDb[i] = complex<double>(rClAg.m_vlrDb[i],0);
        }
        rClAg.m_blCmplx = true;
        rClAg.m_vlrDb.resize(0);
        if ( rClAg.m_pTcSfMtrxDb != 0){
            // rClRightAg has real matrix. Generate compelx matrix and delete real matrix
            delete rClAg.m_pTcSfMtrxCplxDb;
            rClAg.m_pTcSfMtrxCplxDb = new TcSfMtrx<complex<double> >(kr rClAg.m_vlrCplxDb
                    , rClAg.m_pTcSfMtrxDb->m_sztColumn, rClAg.m_pTcSfMtrxDb->m_sztRow);
            delete rClAg.m_pTcSfMtrxDb;
            rClAg.m_pTcSfMtrxDb = 0;
        }
        if ( rClAg.m_pTcSfMtrxInvs != 0){
            size_t sztAt = rClAg.m_pTcSfMtrxInvs->m_vlrT.size();
            delete rClAg.m_pTcSfMtrxInvsCplx;
            rClAg.m_pTcSfMtrxInvsCplx = new TcSfMtrxInvs<complex<double> >(sztAt);
            rClAg.m_pTcSfMtrxInvsCplx->m_determinantT
                    = complex<double>(rClAg.m_pTcSfMtrxInvs->m_determinantT,0);
            
            for ( size_t i=0; i<sztAt; ++i){
                rClAg.m_pTcSfMtrxInvsCplx->m_vlrT[i] = complex<double>(rClAg.m_pTcSfMtrxInvs->m_vlrT[i],0);
            }
        }
    }
}

//-------------- FFT code begin ------------------------------
#define DfFloat double
typedef valarray<complex<DfFloat> > TyVlr;
class ClFFT{
    static double m_dbPi;

    static void ConvertByFFT(
          const TyVlr& crVlrDataAg
        , TyVlr& rVlrResAg
        , int inPosAg = 0
        , int inBitShift=1
    ){
        if (crVlrDataAg.size() <= 1){
            rVlrResAg[inPosAg] = crVlrDataAg[0];
            return;
        }

        TyVlr& rVlrBffPlusAt = *new TyVlr(crVlrDataAg[slice(0,crVlrDataAg.size()/2,1)]);
        rVlrBffPlusAt += TyVlr(crVlrDataAg[slice(crVlrDataAg.size()/2, crVlrDataAg.size()/2,1)]);

        TyVlr& rVlrBffMinusAt = *new TyVlr(crVlrDataAg[slice(0,crVlrDataAg.size()/2,1)]);
        rVlrBffMinusAt -= TyVlr(crVlrDataAg[slice(crVlrDataAg.size()/2, crVlrDataAg.size()/2,1)]);
        for (unsigned int i=0; i<crVlrDataAg.size()/2; ++i){
            rVlrBffMinusAt[i] *= exp(complex<DfFloat>(0,-2*i*m_dbPi/crVlrDataAg.size()));
        }
        ConvertByFFT(rVlrBffPlusAt, kr rVlrResAg, inPosAg, inBitShift<<1);
        ConvertByFFT(rVlrBffMinusAt,kr rVlrResAg, inPosAg | inBitShift, inBitShift<<1);
    
        delete &rVlrBffPlusAt;
        delete &rVlrBffMinusAt;
    }

    static void buffer(const TyVlr& crVlrDataAg , TyVlr& rVlrResAg)
    {
        kAssert( "ConvertByFFT() needs same data and result vector size."
                , crVlrDataAg.size() == rVlrResAg.size() );
        size_t sztAt;
        for(sztAt=1;sztAt<crVlrDataAg.size(); sztAt*=2){
#if 0
        //04.10.05 for loop sztAt<crVlrDataAg.size() �����ŏ\���ł��B
        //coverage �� 100% �ɂ��邽�߂Ɏ��܂��B
            if ( sztAt >= crVlrDataAg.size() ){
                break;
            }
#endif
        }

        TyVlr vlrAt(complex<DfFloat>(0,0),sztAt);
        vlrAt[slice(0,crVlrDataAg.size(),1)] = crVlrDataAg;
        rVlrResAg.resize(vlrAt.size() );

        ConvertByFFT(vlrAt, rVlrResAg);
        //rVlrResAg /= pow(sztAt, 0.5); // Vc&.0 �ŃG���[�ɂȂ�̂ŉ��ɕύX����
        rVlrResAg /= complex<double>(pow(sztAt, 0.5),0);
        //rVlrResAg.resize(crVlrDataAg.size());
    }
  
  public:
    //! Fourier transformation
    static void FFT(const TyVlr& crVlrDataAg , TyVlr& rVlrResAg)
    {
        m_dbPi = 3.141592653589793;
        buffer( crVlrDataAg, rVlrResAg);
    }
    //! reverse Fourier transformation
    static void RFT(const TyVlr& crVlrDataAg , TyVlr& rVlrResAg)
    {
        m_dbPi = -3.141592653589793;
        buffer( crVlrDataAg, rVlrResAg);
    }
};

double ClFFT::m_dbPi = 3.141592653589793;

//-------------- FFT code end ------------------------------

//< Be cation makeCmplxRealSame(.) may return static instance. Don's don nesting call of makeCmplxRealSame()
// Left argment may be changed. makeCmplxRealSame(.) return Righ argment that may be modified to complex
static void makeCmplxRealSame( ClTerm& rClLeftAg, ClTerm& rClRightAg)
{
    if ( rClLeftAg.m_blCmplx ^ rClRightAg.m_blCmplx ){
        // complex/real  properties are not same.
        if ( rClLeftAg.m_blCmplx ){
            if ( rClLeftAg.m_strVarName != ""){
                kAssert("Left and Righ term size are unmatching."
                    , ( rClLeftAg.m_vlrCplxDb.size() == rClRightAg.m_vlrDb.size() )
                   || ( rClLeftAg.m_vlrCplxDb.size() == 1)
                   || ( rClLeftAg.m_inSize == rClRightAg.m_vlrDb.size() )
                   || ( rClRightAg.m_vlrDb.size() == 1)
                   || (  ( rClLeftAg.m_pTcSfMtrxCplxDb != 0)
                       &&( rClLeftAg.m_pTcSfMtrxCplxDb->m_sztRow == rClRightAg.m_vlrDb.size() )
                      )
                );
            }
            // Left term is complex and rigt term is real. We make the right complex
            convertRealToComplex(kr rClRightAg);
        }else{
            // Right term is complex and left term is real. We make the left complex
            if ( rClLeftAg.m_strVarName != ""){
                kAssert("Left and Righ term size are unmatching."  
                    , ( rClLeftAg.m_vlrDb.size() == rClRightAg.m_vlrCplxDb.size() )
                   || ( rClLeftAg.m_vlrDb.size() == 1)
                   || ( rClLeftAg.m_inSize == rClRightAg.m_vlrCplxDb.size() )
                   || ( rClRightAg.m_vlrCplxDb.size() == 1)
                   || (  ( rClLeftAg.m_pTcSfMtrxDb != 0)
                       &&( rClLeftAg.m_pTcSfMtrxDb->m_sztRow == rClRightAg.m_vlrCplxDb.size() )
                      )
                );
            }
            convertRealToComplex(kr rClLeftAg);
        }
    }
}

static void applyRealFunction( const string& crStrFunctionAg, valarray<double>& rVlrAg)
{
    if ( crStrFunctionAg == "sin"){
        rVlrAg = rVlrAg.apply(sin);
    }else if ( crStrFunctionAg == "cos"){
        rVlrAg = rVlrAg.apply(cos);
    }else if ( crStrFunctionAg == "tan"){
        rVlrAg = rVlrAg.apply(tan);
    }else if ( crStrFunctionAg == "asin"){
        rVlrAg = rVlrAg.apply(asin);
    }else if ( crStrFunctionAg == "acos"){
        rVlrAg = rVlrAg.apply(acos);
    }else if ( crStrFunctionAg == "atan"){
        rVlrAg = rVlrAg.apply(atan);
    }else if ( crStrFunctionAg == "sinh"){
        rVlrAg = rVlrAg.apply(sinh);
    }else if ( crStrFunctionAg == "cosh"){
        rVlrAg = rVlrAg.apply(cosh);
    }else if ( crStrFunctionAg == "tanh"){
        rVlrAg = rVlrAg.apply(tanh);
    }else if ( crStrFunctionAg == "exp"){
        rVlrAg = rVlrAg.apply(exp);
    }else if ( crStrFunctionAg == "log"){
        rVlrAg = rVlrAg.apply(log);
    }else if ( crStrFunctionAg == "log10"){
        rVlrAg = rVlrAg.apply(log10);
    }else if ( crStrFunctionAg == "sqrt"){
        rVlrAg = rVlrAg.apply(sqrt);
    }else if ( crStrFunctionAg == "floor"){
        rVlrAg = rVlrAg.apply(floor);
    }else{
        kAssert( "We don't support real mathematic unitary function: !" + crStrFunctionAg, 0);
    }
}

static void applyCplxFunction( const string& crStrFunctionAg, valarray<complex<double> >& rVlrAg)
{
    for ( size_t i=0; i<rVlrAg.size(); ++i){
        if ( crStrFunctionAg == "sin"){
            //rVlrAg = rVlrAg.apply(sin);
            rVlrAg[i] = sin(rVlrAg[i]);
        }else if ( crStrFunctionAg == "cos"){
            //rVlrAg = rVlrAg.apply(cos);
            rVlrAg[i] = cos(rVlrAg[i]);
        }else if ( crStrFunctionAg == "tan"){
#ifdef DfGcc_
            //kAssert("gcc2.95.2 can't compile tan(complex<double> >)", 0);
            rVlrAg[i] = tan(rVlrAg[i]); // gcc3.3 can compile tan(complex<double>)
//#endif

#elif defined(DfVC_)
            //rVlrAg = rVlrAg.apply(tan);
#   ifdef DfVC6_
            kAssert("Vc6 can't compile tan(complex<double> >)", 0);
#   else
            rVlrAg[i] = tan(rVlrAg[i]);
#   endif
#endif
        }else if ( crStrFunctionAg == "sinh"){
            //rVlrAg = rVlrAg.apply(sinh);
            rVlrAg[i] = sinh(rVlrAg[i]);
        }else if ( crStrFunctionAg == "cosh"){
            //rVlrAg = rVlrAg.apply(cosh);
            rVlrAg[i] = cosh(rVlrAg[i]);
        }else if ( crStrFunctionAg == "tanh"){
#ifdef DfGcc_
            //kAssert("gcc2.95.2 can't compile tanh(complex<double> >)", 0);
            rVlrAg[i] = tanh(rVlrAg[i]);    //gcc3.3 can comple tanh(complex<double>)
#elif defined(DfVC_)
#   ifdef DfVC6_
            kAssert("Vc6 can't compile tanh(complex<double> >)", 0);
#   else
            //rVlrAg = rVlrAg.apply(tan);
            rVlrAg[i] = tanh(rVlrAg[i]);
#   endif
#endif
        }else if ( crStrFunctionAg == "exp"){
            //rVlrAg = rVlrAg.apply(exp);
            rVlrAg[i] = exp(rVlrAg[i]);
        }else if ( crStrFunctionAg == "log"){
            //rVlrAg = rVlrAg.apply(log);
            rVlrAg[i] = log(rVlrAg[i]);
        }else if ( crStrFunctionAg == "sqrt"){
            //rVlrAg = rVlrAg.apply(log);
            rVlrAg[i] = sqrt(rVlrAg[i]);
        }else if ( crStrFunctionAg == "floor"){
            //rVlrAg = rVlrAg.apply(log);
            rVlrAg[i] = complex<double>( floor(rVlrAg[i].real()), floor(rVlrAg[i].imag()) );
        }else{
            // Vc7 dosen't support complex acos, asin, atan
            // Vc7 responds INTERNAL COMPILER ERROR at complex cosh, sinh, tanh, exp, log, log10
             kAssert( "We don't support complex mathematic unitary function: !" + crStrFunctionAg, 0);
        }
    }
}

//Cation vrfy ���ʂ�����ɁA�� user modifiable area ����ڂ�
void ClTerm::CalculateUnitaryMathFnctn( const string& crStrFunctionAg, ClTerm& rClTermAg)
{
    if ( (crStrFunctionAg == "fft")
      || (crStrFunctionAg == "rft")
    ){
        convertRealToComplex(kr rClTermAg);
        convertRealToComplex(kr *this);
    }else{
        makeCmplxRealSame( kr *this, kr rClTermAg);
    }
    if ( m_blCmplx == false){
        // real number unitary function operation
        struct StP{ static double abs(const valarray<double>& crVlrAg)
        {
            double dbAt = 0;
            for( size_t i=0; i<crVlrAg.size(); ++i){
                dbAt += crVlrAg[i]* crVlrAg[i];
            }
            return pow(dbAt,0.5);
        }};

        struct StP2{ static double product(const valarray<double>& crVlrAg)
        {
            double dbAt=1;
            for( size_t i=0; i<crVlrAg.size(); ++i){
                dbAt *= crVlrAg[i];
            }
            return dbAt;
        }};

        // real unitary function operation
        if ( rClTermAg.m_inSize == 0){
            // don't use [..] slice array
            if ( crStrFunctionAg == "det"){
                kAssert( "!det(.) is used only for matrix.", rClTermAg.m_pTcSfMtrxDb != 0);
                kAssert( "!det(.) is used only for square matrix."
                        , rClTermAg.m_pTcSfMtrxDb->m_sztColumn == rClTermAg.m_pTcSfMtrxDb->m_sztRow);
                double dbAt;
                if ( rClTermAg.m_pTcSfMtrxInvs != 0){
                    dbAt = rClTermAg.m_pTcSfMtrxInvs->m_determinantT;
                }else{
                    dbAt = tfDeterminant(rClTermAg.m_vlrDb);
                }
                m_vlrDb.resize(1);
                m_vlrDb[0] = dbAt;
                delete m_pTcSfMtrxDb;
                m_pTcSfMtrxDb = 0;
                delete m_pTcSfMtrxInvs;
                m_pTcSfMtrxInvs = 0;
            }else if ( (crStrFunctionAg == "abs")
                   ||  (crStrFunctionAg == "sign")
            ){
                Initialize();
                if ( rClTermAg.m_pTcSfMtrxDb != 0){
                    makeMatrix(false/*real*/, rClTermAg.m_pTcSfMtrxDb->m_sztColumn
                                            , rClTermAg.m_pTcSfMtrxDb->m_sztRow);
                }else{
                    m_vlrDb.resize(rClTermAg.m_vlrDb.size() );
                }
                for( size_t i=0; i<m_vlrDb.size(); ++i){
                    if ( crStrFunctionAg == "abs"){
                        m_vlrDb[i] = zaAbs(rClTermAg.m_vlrDb[i]);
                    }else{
                        if (rClTermAg.m_vlrDb[i] > 0 ){
                            m_vlrDb[i] = 1;
                        }else if (rClTermAg.m_vlrDb[i] == 0 ){
                            m_vlrDb[i] = 0;
                        }else{
                            m_vlrDb[i] = -1;
                        }
                    }
                }
            }else if ( crStrFunctionAg == "size"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = rClTermAg.m_vlrDb.size();
            }else if ( (crStrFunctionAg == "image")
                    || ( crStrFunctionAg == "real")
            ){
                Initialize();
                if ( rClTermAg.m_pTcSfMtrxDb != 0){
                    makeMatrix(false/*real*/, rClTermAg.m_pTcSfMtrxDb->m_sztColumn
                                            , rClTermAg.m_pTcSfMtrxDb->m_sztRow);
                }else{
                    m_vlrDb.resize(rClTermAg.m_vlrDb.size() );
                }

                if ( crStrFunctionAg == "image") {
                    m_vlrDb = valarray<double>(0.0,rClTermAg.m_vlrDb.size());
                }else{
                    m_vlrDb = rClTermAg.m_vlrDb;
                }
            }else if ( crStrFunctionAg == "norm"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = StP::abs(rClTermAg.m_vlrDb);
            }else if ( crStrFunctionAg == "prdct"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = StP2::product(rClTermAg.m_vlrDb);
            }else if ( crStrFunctionAg == "sum"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = rClTermAg.m_vlrDb.sum();
#if 0
   !shift �͎~�߂�B���[�U�[�֐� shift.exe �ɔC����B������ł͎g�����肪��������
            }else if ( crStrFunctionAg == "shift"){
                if (m_pTcSfMtrxDb == 0){
                    Initialize();
                    m_vlrDb.resize(rClTermAg.m_vlrDb.size());
                    m_vlrDb = rClTermAg.m_vlrDb.shift(-1);
                }else{
                    //�s��ɑ΂��Ă͉��x�N�g�����Ƃ� shift ���{��
                    size_t sztColumnAt = rClTermAg.m_pTcSfMtrxDb->m_sztColumn;
                    size_t sztRowAt = rClTermAg.m_pTcSfMtrxDb->m_sztRow;

                    Initialize();
                    m_vlrDb.resize(rClTermAg.m_vlrDb.size());
                    makeMatrix(false/*real*/,sztColumnAt, sztRowAt);

                    for( size_t sztAt=0; sztAt<sztColumnAt; ++sztAt){
                        valarray<double>vlrDbAt(0.0,sztRowAt);
                        vlrDbAt[slice(0,sztRowAt,1)] = 
                                valarray<double>(
                                        rClTermAg.m_vlrDb[
                                                slice(sztAt*sztRowAt, sztRowAt,1)
                                        ]
                                );
                        m_vlrDb[slice(sztAt*sztRowAt, sztRowAt,1)] = vlrDbAt.shift(-1);
                    }
                }
#endif
            }else if ( crStrFunctionAg == "dggr"){
                if (rClTermAg.m_pTcSfMtrxDb != 0){
                    valarray<double> vlrAt = rClTermAg.m_vlrDb;
                    *this = rClTermAg;
                    //transpose matrix
                    size_t sztNewRowAt = m_pTcSfMtrxDb->m_sztColumn;
                    size_t sztOldRowAt = m_pTcSfMtrxDb->m_sztColumn = m_pTcSfMtrxDb->m_sztRow;
                    m_pTcSfMtrxDb->m_sztRow = sztNewRowAt;
                    for( size_t i=0; i<sztOldRowAt/*Column*/; ++i){
                        for( size_t j=0; j<sztNewRowAt; ++j){
                            m_vlrDb[i*sztNewRowAt+j] = vlrAt[j*sztOldRowAt+i];
                        }
                    }
                }else{
                    *this = rClTermAg;
                }
            }else{
                // (crStrFunctionAg �֐���K�p����
                double dbMinAt = rClTermAg.m_vlrDb.min();
                if ( (dbMinAt < 0)
                  && ( (crStrFunctionAg == "log")
                    || (crStrFunctionAg == "log10")     //gcc.2.59.2 �ł͕��f���̓R���p�C���E�G���[�ɂȂ�
                    || (crStrFunctionAg == "sqrt")
                     )
                ){
                    // log �֐��͌��ʂ����f���ɂȂ肦��̂ŁA���f���Ƃ��Ĉ���
                    convertRealToComplex(kr rClTermAg);
                    convertRealToComplex(kr *this);
                    m_vlrCplxDb.resize(rClTermAg.m_vlrCplxDb.size() );
                    m_vlrCplxDb = rClTermAg.m_vlrCplxDb;
                    applyCplxFunction(crStrFunctionAg, kr m_vlrCplxDb);
                    return;
                }else{
                    applyRealFunction(crStrFunctionAg, kr rClTermAg.m_vlrDb);
                    //m_vlrDb = rClTermAg.m_vlrDb;
                    *this = rClTermAg;
                }
            }
            return;
        }else{
            // slice array operation <-- 03.11.08 ���ۂɂ͓����Ă��܂���B�R�[�h������Ă��镔������������܂�
            // !function(..)[..] �� (varLeft operator varRight)[..] �̋L�q��F�߂��Ƃ��ɕK�v�ƂȂ�܂�
            kAssert("Internal Error. We don't support !function(var)[..].", false); // �����ɗ��邱�Ǝ��̂����肦�Ȃ��͂�
#if 0
            // 04.10.07 �������������Ŏg����������Ȃ��̂Ŏc���Ă���
            valarray<double> vlrAt( 
                    rClTermAg.m_vlrDb[slice(rClTermAg.m_inStart
                                 ,rClTermAg.m_inSize
                                 ,rClTermAg.m_inStride
                            )
                    ]
            );

            if ( ( crStrFunctionAg == "abs")
              && (crStrFunctionAg == "sign")
            ){
                Initialize();
                m_vlrDb.resize(rClTermAg.m_inSize);
                for( size_t i=0; i<m_vlrDb.size(); ++i){
                    if ( crStrFunctionAg == "abs"){
                        m_vlrDb[i] = zaAbs(vlrAt[i]);
                    }else{
                        if (vlrAt[i] > 0 ){
                            m_vlrDb[i] = 1;
                        }else if (vlrAt[i] == 0 ){
                            m_vlrDb[i] = 0;
                        }else{
                            m_vlrDb[i] = -1;
                        }
                    }
                }
            }else if ( crStrFunctionAg == "size"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = rClTermAg.m_inSize;
            }else if ( (crStrFunctionAg == "image")
                   ||  (crStrFunctionAg == "real")
            ){
                kAssert("Internal Error. We don't support !image(var)[..] or !real(var)[..].", false);
            }else if ( crStrFunctionAg == "norm"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = StP::abs(vlrAt);
            }else if ( crStrFunctionAg == "prdct"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = StP2::product(rClTermAg.m_vlrDb);
            }else if ( crStrFunctionAg == "sum"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = rClTermAg.m_vlrDb.sum();
            }else if ( crStrFunctionAg == "shift"){
                Initialize();
                m_vlrDb.resize(rClTermAg.m_inSize);
                m_vlrDb = vlrAt.shift(-1);
            }else if ( crStrFunctionAg == "dggr"){
                // no operation for real vector
            }else{
                applyRealFunction(crStrFunctionAg, kr vlrAt);
                m_vlrDb.resize(rClTermAg.m_inSize);
                m_vlrDb = vlrAt;
            }
#endif //0
        }
    }else{
        // complex unitary function operation
        struct StP{ static double abs(const valarray<complex<double> >& crVlrAg)
        {
            double dbAt = 0;
            for( size_t i=0; i<crVlrAg.size(); ++i){
                dbAt += (conj(crVlrAg[i])* crVlrAg[i]).real();
            }
            return pow(dbAt,0.5);
        }};

        struct StP2{ static complex<double> product(const valarray<complex<double> >& crVlrAg)
        {
            complex<double> cplxDbAt(1,0);
            for( size_t i=0; i<crVlrAg.size(); ++i){
                cplxDbAt *= crVlrAg[i];
            }
            return cplxDbAt;
        }};

        if ( rClTermAg.m_inSize == 0){
            // don't use [..] slice array
            if ( crStrFunctionAg == "det"){
                kAssert( "!det(.) is used only for matrix.", rClTermAg.m_pTcSfMtrxCplxDb != 0);
                kAssert( "!det(.) is used only for square matrix."
                        , rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn == rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow);

                complex<double> cplxdbAt;
                if ( rClTermAg.m_pTcSfMtrxInvsCplx != 0){
                    cplxdbAt = rClTermAg.m_pTcSfMtrxInvsCplx->m_determinantT;
                }else{
                    cplxdbAt = tfDeterminant(rClTermAg.m_vlrCplxDb);
                }
                m_vlrCplxDb.resize(1);
                m_vlrCplxDb[0] = cplxdbAt;
                delete m_pTcSfMtrxCplxDb;
                m_pTcSfMtrxCplxDb = 0;
                delete m_pTcSfMtrxInvsCplx;
                m_pTcSfMtrxInvsCplx = 0;
            }else if ( (crStrFunctionAg == "abs")
                   ||  (crStrFunctionAg == "sign")
            ){
                Initialize();
                if ( rClTermAg.m_pTcSfMtrxCplxDb != 0){
                    makeMatrix(false/*real*/, rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn
                                            , rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow);
                }else{
                    m_vlrDb.resize(rClTermAg.m_vlrCplxDb.size() );
                }
                for( size_t i=0; i<m_vlrDb.size(); ++i){
                    if ( crStrFunctionAg == "abs"){
                        m_vlrDb[i] = abs(rClTermAg.m_vlrCplxDb[i]);
                    }else{
                        if ( rClTermAg.m_vlrCplxDb[i].real() > 0 ){
                            m_vlrDb[i] = 1;
                        }else if (rClTermAg.m_vlrCplxDb[i].real() == 0 ){
                            m_vlrDb[i] = 0;
                        }else{
                            m_vlrDb[i] = -1;
                        }
                    
                    }
                }
            }else if ( crStrFunctionAg == "size"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = rClTermAg.m_vlrCplxDb.size();
            }else if ( (crStrFunctionAg == "image")
                    || (crStrFunctionAg == "real")
            ){
                Initialize();
                if ( rClTermAg.m_pTcSfMtrxCplxDb != 0){
                    makeMatrix(false/*real*/, rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn
                                            , rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow);
                }else{
                    m_vlrDb.resize(rClTermAg.m_vlrCplxDb.size() );
                }
                
                for( size_t i=0; i<m_vlrDb.size(); ++i){
                    if ( crStrFunctionAg == "image") {
                        m_vlrDb[i] = rClTermAg.m_vlrCplxDb[i].imag();
                    }else{
                        m_vlrDb[i] = rClTermAg.m_vlrCplxDb[i].real();
                    }
                }
            }else if ( crStrFunctionAg == "norm"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = StP::abs(rClTermAg.m_vlrCplxDb);
            }else if ( crStrFunctionAg == "prdct"){
                Initialize();
                m_blCmplx = true;
                m_vlrCplxDb.resize(1);
                m_vlrCplxDb[0] = StP2::product(rClTermAg.m_vlrCplxDb);
            }else if ( crStrFunctionAg == "sum"){
                Initialize();
                m_blCmplx = true;
                m_vlrCplxDb.resize(1);
                m_vlrCplxDb[0] = rClTermAg.m_vlrCplxDb.sum();
#if 0
   !shift �͎~�߂�B���[�U�[�֐� shift.exe �ɔC����B������ł͎g�����肪��������
            }else if ( crStrFunctionAg == "shift"){
                if (m_pTcSfMtrxDb == 0){
                    Initialize();
                    m_vlrCplxDb.resize(rClTermAg.m_vlrCplxDb.size());
                    m_vlrCplxDb = rClTermAg.m_vlrCplxDb.shift(-1);
                }else{
                    //�s��ɑ΂��Ă͉��x�N�g�����Ƃ� shift ���{��
                    size_t sztColumnAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn;
                    size_t sztRowAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow;

                    Initialize();
                    m_vlrCplxDb.resize(rClTermAg.m_vlrCplxDb.size());
                    makeMatrix(true/*complex*/,sztColumnAt, sztRowAt);

                    for( size_t sztAt=0; sztAt<sztColumnAt; ++sztAt){
                        valarray<complex<double> >vlrCplxDbAt(0,sztRowAt);
                        vlrCplxDbAt[slice(0,sztRowAt,1)] = 
                                valarray<complex<double> >(
                                        rClTermAg.m_vlrCplxDb[
                                                slice(sztAt*sztRowAt, sztRowAt,1)
                                        ]
                                );
                        m_vlrCplxDb[slice(sztAt*sztRowAt, sztRowAt,1)] = vlrCplxDbAt.shift(-1);
                    }
                }
#endif
            }else if ( crStrFunctionAg == "dggr"){
                if (rClTermAg.m_pTcSfMtrxCplxDb != 0){
                    valarray<complex<double> > vlrCplxAt = rClTermAg.m_vlrCplxDb;
                    
                    *this = rClTermAg;
                    //transpose matrix
                    size_t sztNewRowAt = m_pTcSfMtrxCplxDb->m_sztColumn;
                    size_t sztOldRowAt = m_pTcSfMtrxCplxDb->m_sztColumn = m_pTcSfMtrxCplxDb->m_sztRow;
                    m_pTcSfMtrxCplxDb->m_sztRow = sztNewRowAt;
                    for( size_t i=0; i<sztOldRowAt; ++i){
                        for( size_t j=0; j<sztNewRowAt/*column*/; ++j){
                            m_vlrCplxDb[i*sztNewRowAt+j] = conj(vlrCplxAt[j*sztOldRowAt+i]);
                        }
                    }
                }else{
                    *this = rClTermAg;
                    for( size_t i=0; i<m_vlrCplxDb.size(); ++i){
                        m_vlrCplxDb[i] = conj(m_vlrCplxDb[i]);
                    }
                }
            }else if ( crStrFunctionAg == "fft"){
                if ( rClTermAg.m_pTcSfMtrxCplxDb == 0){
                    *this = rClTermAg;
                    ClFFT::FFT(m_vlrCplxDb, kr m_vlrCplxDb);
                }else{
                    kAssert("We don't support fft for Matrix.",0);
#if 0
                    //04.10.06 �s��� fft �𓭂������Ă��A���������Ƃ͏��Ȃ��̂Ŏ~�߂�
                    size_t sztColumnAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn;
                    size_t sztRowAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow;

                    size_t sztExtendedRowAt;
                    for(sztExtendedRowAt=1;sztExtendedRowAt<sztRowAt; sztExtendedRowAt*=2){
                        if ( sztExtendedRowAt >= sztRowAt ){
                            break;
                        }
                    }
                    Initialize();
                    m_vlrCplxDb.resize(sztExtendedRowAt*sztColumnAt);
                    makeMatrix(true/*complex*/,sztColumnAt, sztExtendedRowAt);

                    for( size_t sztAt=0; sztAt<sztColumnAt; ++sztAt){
                        valarray<complex<double> >vlrCplxDbAt(0,sztExtendedRowAt);
                        vlrCplxDbAt[slice(0,sztRowAt,1)] = 
                                valarray<complex<double> >(
                                        rClTermAg.m_vlrCplxDb[
                                                slice(sztAt*sztRowAt, sztRowAt,1)
                                        ]
                                );
                        ClFFT::FFT(vlrCplxDbAt, kr vlrCplxDbAt);
                        m_vlrCplxDb[slice(sztAt*sztExtendedRowAt, sztExtendedRowAt,1)] = vlrCplxDbAt;
                    }
#endif  //0
                }
            }else if ( crStrFunctionAg == "rft"){
                if ( rClTermAg.m_pTcSfMtrxCplxDb == 0){
                    *this = rClTermAg;
                    ClFFT::RFT(m_vlrCplxDb, kr m_vlrCplxDb);
                }else{
                    kAssert("We don't support rft for Matrix.",0);
#if 0
                    //04.10.06 �s��� fft �𓭂������Ă��A���������Ƃ͏��Ȃ��̂Ŏ~�߂�
                    size_t sztColumnAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn;
                    size_t sztRowAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow;

                    size_t sztExtendedRowAt;
                    for(sztExtendedRowAt=1;sztExtendedRowAt<sztRowAt; sztExtendedRowAt*=2){
                        if ( sztExtendedRowAt >= sztRowAt ){
                            break;
                        }
                    }
                    Initialize();
                    m_vlrCplxDb.resize(sztExtendedRowAt*sztColumnAt);
                    makeMatrix(true/*complex*/,sztColumnAt, sztExtendedRowAt);

                    for( size_t sztAt=0; sztAt<sztColumnAt; ++sztAt){
                        valarray<complex<double> >vlrCplxDbAt(0,sztExtendedRowAt);
                        vlrCplxDbAt[slice(0,sztRowAt,1)] = 
                                valarray<complex<double> >(
                                        rClTermAg.m_vlrCplxDb[
                                                slice(sztAt*sztRowAt, sztRowAt,1)
                                        ]
                                );
                        ClFFT::RFT(vlrCplxDbAt, kr vlrCplxDbAt);
                        m_vlrCplxDb[slice(sztAt*sztExtendedRowAt, sztExtendedRowAt,1)] = vlrCplxDbAt;
                    }
#endif  //0
                }
            }else{
                applyCplxFunction(crStrFunctionAg, kr rClTermAg.m_vlrCplxDb);
                //m_vlrCplxDb = rClTermAg.m_vlrCplxDb;
                *this = rClTermAg;
            }
            return;
        }else{
            // slice array operation <-- 03.11.08 ���ۂɂ͓����Ă��܂���B�R�[�h������Ă��镔������������܂�
            // !function(..)[..] �� (varLeft operator varRight)[..] �̋L�q��F�߂��Ƃ��ɕK�v�ƂȂ�܂�

            kAssert("Internal Error. We don't support !function(var)[..].", false); // �����ɗ��邱�Ǝ��̂����肦�Ȃ��͂�
#if 0
            // 04.10.07 �������������Ŏg����������Ȃ��̂Ŏc���Ă���
            // slice array operation
            valarray<complex<double> > vlrAt( 
                    rClTermAg.m_vlrCplxDb[slice( rClTermAg.m_inStart
                                     , rClTermAg.m_inSize
                                     , rClTermAg.m_inStride
                                )
                    ]
            );

            if ( (crStrFunctionAg == "abs")
              || (crStrFunctionAg == "sign")
            ){
                Initialize();
                m_vlrCplxDb.resize(rClTermAg.m_inSize);
                for( size_t i=0; i<m_vlrCplxDb.size(); ++i){
                    if ( crStrFunctionAg == "abs"){
                        m_vlrCplxDb[i] = abs(vlrAt[i]);
                    }else{
                        m_vlrCplxDb[i] = abs(vlrAt[i]) >= 1? 1:0;
                        if ( vlrAt[i].real() > 0 ){
                            m_vlrDb[i] = 1;
                        }else if (vlrAt[i].real() == 0 ){
                            m_vlrDb[i] = 0;
                        }else{
                            m_vlrDb[i] = -1;
                        }
                    }
                }
            }else if ( crStrFunctionAg == "size"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = rClTermAg.m_inSize;
            }else if ( (crStrFunctionAg == "image")
                    || (crStrFunctionAg == "real")
            ){
                kAssert("Internal Error. We don't support !image(var)[..] or !real(var)[..].", false);
            }else if ( crStrFunctionAg == "norm"){
                Initialize();
                m_vlrDb.resize(1);
                m_vlrDb[0] = StP::abs(vlrAt);
            }else if ( crStrFunctionAg == "prdct"){
                Initialize();
                m_blCmplx = true;
                m_vlrCplxDb.resize(1);
                m_vlrCplxDb[0] = StP2::product(rClTermAg.m_vlrCplxDb);
            }else if ( crStrFunctionAg == "sum"){
                Initialize();
                m_blCmplx = true;
                m_vlrCplxDb.resize(1);
                m_vlrCplxDb[0] = rClTermAg.m_vlrCplxDb.sum();
            }else if ( crStrFunctionAg == "shift"){
                Initialize();
                m_vlrCplxDb.resize(rClTermAg.m_inSize);
                m_vlrCplxDb = vlrAt.shift(-1);
            }else if ( crStrFunctionAg == "dggr"){
                // no operation for real vector
                Initialize();
                m_vlrCplxDb.resize(rClTermAg.m_inSize);
                for( size_t i=0; i<vlrAt.size(); ++i){
                    m_vlrCplxDb[i] = conj(vlrAt[i]);
                }
            }else{
                applyCplxFunction(crStrFunctionAg, kr vlrAt);
                m_vlrCplxDb.resize(rClTermAg.m_inSize);
                m_vlrCplxDb = vlrAt;
            }
#endif // 0
        }

    }
}

static void cutRearCR(kr string& rStrAg)
{
    // gcc �� .... \r \a �̈�s�����o�����Ƃ��A�Ō�� \r ���c��
    if (rStrAg[rStrAg.size()-1] == '\r'){
        rStrAg = rStrAg.substr(0,rStrAg.size()-1);
    }
}

//! get kreg("<('d)+(,(`d*))?>" ) string -- a help: <:Lt,  >:Gt
//! if read strings ares <...> format then rStrWordAt holds inside strings without '<' and '>' character.
//! Conversely, if read streans are not <...> then rStrWordAt contain first and end characters.
//! bool return value is true if rStrWordAt holds the inside strings.
static void getStrFromGtToLt(string& rStrWordAt, ifstream& rIfrmAg)
{
    rStrWordAt = "";
    string strAt;       // strAt is needed to process last '\' character connection
    while ( !rIfrmAg.eof() ){
        getline(kr rIfrmAg, kr strAt);
        cutRearCR(kr strAt);

        size_t sztAt = strAt.find('#');
        if ( sztAt != string::npos ){
            // there is comment
            strAt = strAt.substr(0,sztAt);
        }
        cutFrontRearWhiteSpace( kr strAt);
        if ( strAt.size() == 0 ){
            continue;
        }

        rStrWordAt += strAt;
        
        if ( rStrWordAt[0] == '%' ){
            return;
            //return false;
        }else if ( rStrWordAt[0] == '<' ){
            kAssert( "getStrFromGtToLt(.) detect not '>' last character."
                    , rStrWordAt[rStrWordAt.size()-1] == '>' );
            rStrWordAt = rStrWordAt.substr(1, rStrWordAt.size()-2);
            return;
            //return true;
        }else{
            kAssert( "getStrFromGtToLt(.) abonomal line " + rStrWordAt, 0); // �����ɗ��邱�Ǝ��̂��A�������������Ӗ����܂�
            // return false;   // damie return -- �����ɂ͗���Ȃ�
            //03.11.12 BaseVarDouble, BaseVarDoubleMatrix �̃x�N�^�v�f�� '<', '>' ���܂܂Ȃ��ϐ��������������
            //���̂悤�ȕϐ����܂ޕϐ��x�N�^�L�q�̂Ƃ��� size2vectorVariable �����̂܂ܕԂ�
            //      %  BaseVarDouble 2
            //      size2vectorVariable
            //04.10.07 ��� 4 �s���~�߂܂��BBaseVarDouble 2 �� 2 == size2vectorVariable.size() ��
            //�ۏ؂�����܂���B   
            //      %  BaseVarDouble 2
            //      <variable1, variable2>
            //�̂悤�ɕϐ��t�@�C�����R���\�[���Ƀ^�C�v���邾���Ő����������ƔF���ł���L�q�Ɍ��肵�܂�
        }
    }
    //return true;
    //return false;
    //03.04.13 TcCrout �̒ǉ��ɔ����A�}�g���b�N�X val �t�@�C���� TcCrout �f�[�^��ǂނƂ��A TcCrout �f�[�^���Ȃ���
    //�����ɗ���悤�ɂȂ����B
    //kAssert( "getStrFromGtToLt(.) doesn't detect data line.", 0);
}

void ClTerm::makeMatrix(bool blComcplex_RealAg, size_t columnAg, size_t rowAg)
{
    delete m_pTcSfMtrxDb;      //!< if m_pTcSfMtrxDb = 0, m_vlrDb is vector not matrix
    delete m_pTcSfMtrxCplxDb;    //!< if m_pTcSfMtrxCplxDb = 0, m_vlrCmplxDb is vector not matrix

    kAssert("Internal Error at makeMatrix(.)", (m_vlrDb.size()==0) && (m_vlrCplxDb.size()==0) );
    if ( blComcplex_RealAg == true ){
        m_vlrCplxDb.resize(columnAg * rowAg, (0,0) );
        m_vlrCplxDb = complex<double>(0,0);
        delete m_pTcSfMtrxCplxDb;
        m_pTcSfMtrxCplxDb = new TcSfMtrx<complex<double> >(m_vlrCplxDb, columnAg, rowAg);
    }else{
        m_vlrDb.resize(columnAg * rowAg, 0);
        m_vlrDb = 0;
        delete m_pTcSfMtrxDb;
        m_pTcSfMtrxDb = new TcSfMtrx<double>(m_vlrDb, columnAg, rowAg);
    }
}

void ClTerm::readInverted(ifstream& rIfrmAg, size_t sztRowAg)
{
    string strAt;
    // This matrix may contain TcCrout matrix because matrix is square.
    getStrFromGtToLt(kr strAt, kr rIfrmAg);
    if ( strAt.size() != 0 ){
        kAssert("Matrix property line doesn't start with %. character.", strAt[0] == '%');
        size_t sztRowAt = m_pTcSfMtrxDb->m_sztRow;
        delete m_pTcSfMtrxInvs;
        m_pTcSfMtrxInvs = new TcSfMtrxInvs<double>(sztRowAg);

        istringstream istrmInvertedAt(strAt);
        string strWordAt;
        istrmInvertedAt >> strWordAt;   // "%"
        istrmInvertedAt >> strWordAt;   // second string at % property line
         kAssert("", strAt[0] == '%');
        if ( strWordAt == "BaseDoubleInverted"){
            //% BaseDoubleInverted determinanantNumber
            //<...,  ..., ..>
            double dbAt;
            istrmInvertedAt >> dbAt;
            this->m_pTcSfMtrxInvs->m_determinantT = dbAt;
            this->m_pTcSfMtrxInvs->m_vlrT.resize( sztRowAt * sztRowAt);

            this->m_pTcSfMtrxInvs->m_enState = TcSfMtrxInvs<double>::EnLessThanMinPivot;
            if ( dbAt != 0){
                for (size_t i=0; i<sztRowAt; ++i){
                    ClTerm clTermAt;
                    clTermAt.Initialize();
                    getStrFromGtToLt(kr strWordAt, kr rIfrmAg);
                    getVectorVal( strWordAt, kr clTermAt);
                    kAssert("Real inverse matrix "+m_strVarName+" TcCrout::m_vlrT row " + strWordAt + " must be real."
                            , clTermAt.m_blCmplx == false);
                    kAssert("Real inverse matrix "+m_strVarName+" TcCrout::m_vlrT row " + strWordAt + " is not defined size."
                            , clTermAt.m_vlrDb.size() == sztRowAt);
                    for ( size_t j=0; j<sztRowAt; ++j){
                        this->m_pTcSfMtrxInvs->m_vlrT[i*sztRowAt + j] = clTermAt.m_vlrDb[j];
                    }
                }
            }
            this->m_pTcSfMtrxInvs->m_enState = TcSfMtrxInvs<double>::EnInverted;
            return;
        }
    }
}
void ClTerm::readCplxInverted(ifstream& rIfrmAg, size_t sztRowAg)
{
    string strAt;
    // this matrix may be TcCrout matrix
    getStrFromGtToLt(kr strAt, kr rIfrmAg);
    if ( strAt.size() != 0 ){
        kAssert("Matrix property line doesn't start with %. character.", strAt[0] == '%');
        size_t sztRowAt = m_pTcSfMtrxCplxDb->m_sztRow;
        delete m_pTcSfMtrxInvsCplx;
        m_pTcSfMtrxInvsCplx = new TcSfMtrxInvs<complex<double> >(sztRowAg);

        istringstream istrmInverted(strAt);
        string strWordAt;
        istrmInverted >> strWordAt;   // "%"
        istrmInverted >> strWordAt;   // second string at first line
        if ( strWordAt == "BaseComplexDoubleInverted"){
            //% BaseDoubleInverted complexDeterminanantNumber
            //<...,  ..., ..>
            complex<double> cplxDbAt;
            istrmInverted >> cplxDbAt;
            this->m_pTcSfMtrxInvsCplx->m_determinantT = cplxDbAt;
            this->m_pTcSfMtrxInvsCplx->m_vlrT.resize( sztRowAt * sztRowAt);

            this->m_pTcSfMtrxInvsCplx->m_enState = TcSfMtrxInvs<complex<double> >::EnLessThanMinPivot;
            for (size_t i=0; i<sztRowAt; ++i){
                ClTerm clTermAt;
                clTermAt.Initialize();
                getStrFromGtToLt(kr strWordAt, kr rIfrmAg);
                getVectorVal( strWordAt, kr clTermAt);
                convertRealToComplex( kr clTermAt);
                kAssert("complex matrix "+m_strVarName+" TcCrout row " + strWordAt + " is not defined size."
                        , clTermAt.m_vlrCplxDb.size() == sztRowAt);
                for ( size_t j=0; j<sztRowAt; ++j){
                    this->m_pTcSfMtrxInvsCplx->m_vlrT[i*sztRowAt + j] = clTermAt.m_vlrCplxDb[j];
                }
            }
            this->m_pTcSfMtrxInvsCplx->m_enState = TcSfMtrxInvs<complex<double> >::EnInverted;
            return;
        }
    }
}

static size_t incrementSzt(const string& crStrAg, size_t sztStrAg);
static string getCommand(string& rStrAg);
#if 0
//04.10.07 �g�킸�ɍςނ̂ŃR�����g�E�A�E�g����B��Ŏg���Ƃ����L�邩������Ȃ��B

//! rCrStrAg �� comment mark '#' ��T���A# ����������B
//! \\\# �̂悤�� # �̒��O�ɘA�������� '\' ������Ƃ��� comment mark �ł͂Ȃ�
static void cutComment(string& rStrAg)
{
    int inCountEscapeAt = 0;
    for (size_t i=0; i < rStrAg.size(); i=incrementSzt(rStrAg, i) ){
        if ( (inCountEscapeAt %2 == 0) && (rStrAg[i] == '#') ){
            rStrAg = rStrAg.substr(0, i);
            cutFrontRearWhiteSpace(rStrAg);
            return;
        }else if ( rStrAg[i] == '\\' ){
            ++inCountEscapeAt;
        }else{
            inCountEscapeAt = 0;
        }
    }
}
#endif //0

//! ConvertFileToValue uses crFileNameAg as only kAssert file name
void ClTerm::ConvertFileToValue(const string& crStrFileNameAg)
{
    ifstream ifrmAt( crStrFileNameAg.c_str() );
    if ( ifrmAt.fail()  ){
        // open val array or value file
        kAssert("We can't find file: " + crStrFileNameAg + " at ConvertFileToValue(.).", false);
    }
    

    string strAt;
    getStrFromGtToLt(kr strAt, kr ifrmAt);
    cutFrontRearWhiteSpace(strAt);
    //cutComment(strAt); �R�����g�� getStrFromGtToLt(.) �̒i�K�Ŏ��Ă���
    if ( strAt[0] == '%' ){
        size_t sztFixedTypeAt=string::npos;
        size_t sztVariedTypeAt=string::npos;
        if ( ( (sztFixedTypeAt = strAt.find("BaseDoubleMatrix")) != string::npos )
          || ( (sztVariedTypeAt = strAt.find("BaseVarDoubleMatrix")) != string::npos)
        ){
            if ( sztFixedTypeAt != string::npos){
                strAt = strAt.substr(sztFixedTypeAt + 16/*BaseDoubleMatrix size*/);
            }else{
                strAt = strAt.substr(sztVariedTypeAt + 19/*BaseVarDoubleMatrix size*/);
            }
            cutFrontRearWhiteSpace(strAt);

            m_blCmplx = false;

            string strColumnAt = getCommand(kr strAt);
            kAssert( "Matrix File has no column argment", strColumnAt != "");  
            string strRowAt = getCommand(kr strAt);
            kAssert( "Matrix File has no row argment", strRowAt != "");  
            
            ClTerm clTermAt;
            GetRightSideVal( kr strColumnAt, kr clTermAt);
            kAssert( "At ConvertFileToValue(...), colummn variable value of matrix file is not scalar:" + strAt
                    , (clTermAt.m_vlrDb.size()==1)
                   && (clTermAt.m_vlrDb[0] >=1)
            );
            size_t sztColumnAt = static_cast<size_t>(clTermAt.m_vlrDb[0]);

            clTermAt.Initialize();
            GetRightSideVal( kr strRowAt, kr clTermAt);
            kAssert( "At ConvertFileToValue(...), row variable value of matrix file is not scalar:" + strAt
                    , (clTermAt.m_vlrDb.size()==1)
                   && (clTermAt.m_vlrDb[0] >=1)
            );
            size_t sztRowAt = static_cast<size_t>(clTermAt.m_vlrDb[0]);

            this->makeMatrix( false/* real matrix*/,sztColumnAt, sztRowAt);

            for(size_t i=0; i<sztColumnAt; ++ i){
                ClTerm clTermAt;
                clTermAt.Initialize();
                string strWordAt;
                getStrFromGtToLt(kr strWordAt, kr ifrmAt);
                if ( strWordAt[0] == '<' ){
                    // << ... >> �`���ł̋L�q�ł�
                    kAssert("At ConvertFileToValue(...), vector elemet expression is unexpected format:" + strWordAt
                            , strWordAt[strWordAt.size()-1] == '>');
                    //file vector string is <<...>> or singleVectorVariable
                    if ( strWordAt[0] == '<'){
                        strWordAt = "<" + strWordAt + ">"; 
                    }
                    GetRightSideVal(strWordAt, kr clTermAt);
                }else{
                    getVectorVal( strWordAt, kr clTermAt);
                }
                if ( m_blCmplx == false){
                    if (clTermAt.m_blCmplx == true ){
                        //BaseVarDoubleMatrix �ł���A�f�[�^��ǂݍ��񂾌�� Complex �ɕς�邱�Ƃ�����
                        convertRealToComplex(kr *this);
                        kAssert("matrix "+m_strVarName+" row " + strWordAt + " is not defined size."
                            , clTermAt.m_vlrCplxDb.size() == sztRowAt);
                        this->m_vlrCplxDb[slice(i*sztRowAt, sztRowAt, 1)] = clTermAt.m_vlrCplxDb;
                    }else{
                        kAssert("matrix "+m_strVarName+" row " + strWordAt + " is not defined size."
                            , clTermAt.m_vlrDb.size() == sztRowAt);
                        this->m_vlrDb[slice(i*sztRowAt, sztRowAt, 1)] = clTermAt.m_vlrDb;
                    }
                }else{
                    convertRealToComplex(kr clTermAt);
                    kAssert("matrix "+m_strVarName+" row " + strWordAt + " is not defined size."
                        , clTermAt.m_vlrCplxDb.size() == sztRowAt);
                    this->m_vlrCplxDb[slice(i*sztRowAt, sztRowAt, 1)] = clTermAt.m_vlrCplxDb;
                }
            }
            if ( sztColumnAt == sztRowAt ){
                readInverted(kr ifrmAt, sztRowAt);
            }
            return;
        }else if ( ( (sztFixedTypeAt = strAt.find("BaseDouble")) != string::npos )
          || ( (sztVariedTypeAt = strAt.find("BaseVarDouble")) != string::npos)
        ){
            // variable must be scalar or vector
            m_blCmplx = false;
            int inSizeAt;
            if ( sztFixedTypeAt != string::npos){
                strAt = strAt.substr(sztFixedTypeAt + 10/*BaseDouble size*/);
            }else{
                strAt = strAt.substr(sztVariedTypeAt + 13/*BaseVarDouble size*/);
            }
            cutFrontRearWhiteSpace(strAt);

            ClTerm clTermAt;
            GetRightSideVal( strAt, kr clTermAt);
            kAssert( "At ConvertFileToValue(...), vector size variable value of vector file is not scalar:" + strAt
                    , (clTermAt.m_vlrDb.size()==1)
                   && (clTermAt.m_vlrDb[0] >=1)
            );
            inSizeAt = static_cast<int>(clTermAt.m_vlrDb[0]);
            string strWordAt;
            getStrFromGtToLt(kr strWordAt, kr ifrmAt);
            if (  strWordAt[0] == '<' ){
                // << ... >> �`���ł̋L�q�ł�
                kAssert("At ConvertFileToValue(...), vector elemet expression is unexpected format:" + strWordAt
                        , strWordAt[strWordAt.size()-1] == '>');
                if ( strWordAt[0] == '<'){
                    strWordAt = "<" + strWordAt + ">"; 
                }
                GetRightSideVal(strWordAt, kr *this);
            }else{
                getVectorVal( strWordAt, kr *this);
            }
            kAssert(m_strVarName + " double vector size is not consistent."
                    , ((m_blCmplx == false) && (m_vlrDb.size() == inSizeAt))
                   || ((m_blCmplx == true ) && (m_vlrCplxDb.size() == inSizeAt))
            );
            return;
        }else if ( (sztFixedTypeAt = strAt.find("BaseComplexDoubleMatrix")) != string::npos  ){
            strAt = strAt.substr(sztFixedTypeAt + 23/*BaseComplexDoubleMatrix size*/);
            cutFrontRearWhiteSpace(strAt);

            string strColumnAt = getCommand(kr strAt);
            kAssert( "Matrix File has no column argment", strColumnAt != "");  
            string strRowAt = getCommand(kr strAt);
            kAssert( "Matrix File has no row argment", strRowAt != "");  
            
            ClTerm clTermAt;
            GetRightSideVal( kr strColumnAt, kr clTermAt);
            kAssert( "At ConvertFileToValue(...), colummn variable value of matrix file is not scalar:" + strAt
                    , (clTermAt.m_vlrDb.size()==1)
                   && (clTermAt.m_vlrDb[0] >=1)
            );
            size_t sztColumnAt = static_cast<size_t>(clTermAt.m_vlrDb[0]);

            clTermAt.Initialize();
            GetRightSideVal( kr strRowAt, kr clTermAt);
            kAssert( "At ConvertFileToValue(...), row variable value of matrix file is not scalar:" + strAt
                    , (clTermAt.m_vlrDb.size()==1)
                   && (clTermAt.m_vlrDb[0] >=1)
            );
            size_t sztRowAt = static_cast<size_t>(clTermAt.m_vlrDb[0]);

            m_blCmplx = false;
            this->makeMatrix( true/* complex */,sztColumnAt, sztRowAt);

            for(size_t i=0; i<sztColumnAt; ++ i){
                ClTerm clTermAt;
                clTermAt.Initialize();
                string strWordAt;
                getStrFromGtToLt(kr strWordAt, kr ifrmAt);
                getVectorVal( strWordAt, kr clTermAt);
                convertRealToComplex( kr clTermAt);
                kAssert("matrix "+m_strVarName+" row " + strWordAt + " is defined size."
                        , clTermAt.m_vlrCplxDb.size() == sztRowAt);
                this->m_vlrCplxDb[slice(i*sztRowAt, sztRowAt, 1)] = clTermAt.m_vlrCplxDb;
            }
            m_blCmplx = true;

            if ( sztColumnAt == sztRowAt ){
                readCplxInverted(ifrmAt,sztRowAt);
                return;
            }

        }else if ( (sztFixedTypeAt = strAt.find("BaseComplexDouble")) != string::npos  ){
            int inSizeAt;
            strAt = strAt.substr(sztFixedTypeAt + 17/*BaseComplexDouble size*/);
            cutFrontRearWhiteSpace(strAt);

            ClTerm clTermAt;
            GetRightSideVal( strAt, kr clTermAt);
            kAssert( "At ConvertFileToValue(...), vector size variable value of vector file is not scalar:" + strAt
                    , (clTermAt.m_vlrDb.size()==1)
                   && (clTermAt.m_vlrDb[0] >=1)
            );
            inSizeAt = static_cast<int>(clTermAt.m_vlrDb[0]);

            string strWordAt;
            getStrFromGtToLt(kr strWordAt, kr ifrmAt);
            m_blCmplx = true;
            getVectorVal( strWordAt, kr *this);
            //convertRealToComplex( kr *this);
            kAssert(m_strVarName + " double vector size is not consistent."
                    , m_vlrCplxDb.size() == inSizeAt);
        }else{
            // If % file property property line extention is used, then becom here.
            kAssert("We now dont implement User ConvertFile interface now.",0);
        }
        return;
    }
    //kAssert("We don't detect first % line at file:" + m_strVarName, 0);
    //<== 04.10.07 getStrFromGtToLt(.) abonomal line �ŃG���[�ɂȂ�悤�ɂ���
}


static void makeCplxInvs( ClTerm&  rClTermAg)
{
    if ( rClTermAg.m_pTcSfMtrxInvsCplx == 0 ){
        size_t sztRow = static_cast<size_t>(pow(rClTermAg.m_vlrCplxDb.size(), 0.5) );
        kAssert( "makeCplxInvs(.) needs squared m_vlrCplxDb size", rClTermAg.m_vlrCplxDb.size() == sztRow * sztRow);

        rClTermAg.m_pTcSfMtrxInvsCplx = new TcSfMtrxInvs<complex<double> >(sztRow);
        rClTermAg.m_pTcSfMtrxInvsCplx->m_determinantT = tfDeterminant(rClTermAg.m_vlrCplxDb);

        TcCrout<complex<double> >* pTcCroutCplxDbAt
                = new TcCrout<complex<double> >(rClTermAg.m_vlrCplxDb);

        if ( pTcCroutCplxDbAt->m_enState == TcCrout<complex<double> >::EnDecomposed) {
            pTcCroutCplxDbAt->MakeInverse();
            rClTermAg.m_pTcSfMtrxInvsCplx->m_vlrT = pTcCroutCplxDbAt->m_vlrT;
        }
        rClTermAg.m_pTcSfMtrxInvsCplx->m_enState 
                = static_cast<TcSfMtrxInvs< complex<double> >::EnmState >( pTcCroutCplxDbAt->m_enState );
        delete pTcCroutCplxDbAt;
    }
    
    if(rClTermAg.m_pTcSfMtrxInvsCplx->m_enState != TcSfMtrxInvs<complex<double> >::EnInverted){
        kAssert("sf can't invert Matrix.", false);
    }
}

static void makeInverse( ClTerm&  rClTermAg)
{
    if ( rClTermAg.m_pTcSfMtrxInvs == 0 ){
        size_t sztRow = static_cast<size_t>(pow(rClTermAg.m_vlrDb.size(), 0.5) );
        kAssert( "makeInvs(.) needs squared m_vlrDb size", rClTermAg.m_vlrDb.size() == sztRow * sztRow);

        rClTermAg.m_pTcSfMtrxInvs = new TcSfMtrxInvs<double>(sztRow);
        rClTermAg.m_pTcSfMtrxInvs->m_determinantT = tfDeterminant(rClTermAg.m_vlrDb);

        TcCrout<double>* pTcCroutDbAt
                = new TcCrout<double>(rClTermAg.m_vlrDb);

        if ( pTcCroutDbAt->m_enState == TcCrout<double>::EnDecomposed){
            pTcCroutDbAt->MakeInverse();
            rClTermAg.m_pTcSfMtrxInvs->m_vlrT = pTcCroutDbAt->m_vlrT;
        }
        rClTermAg.m_pTcSfMtrxInvs->m_enState 
                = static_cast<TcSfMtrxInvs<double>::EnmState >(pTcCroutDbAt->m_enState);
        delete pTcCroutDbAt;
    }

    if(rClTermAg.m_pTcSfMtrxInvs->m_enState != TcSfMtrxInvs<double>::EnInverted){
        kAssert("sf can't invert Matrix.", false);
    }
};

//! = operator ruins rClTermAg.m_pTcSfMtrxDb,m_pTcSfMtrxInvs
ClTerm& ClTerm::operator = ( ClTerm& rClTermAg)
{
    delete m_pTcSfMtrxDb;
    delete m_pTcSfMtrxCplxDb;
    delete m_pTcSfMtrxInvs;
    delete m_pTcSfMtrxInvsCplx;

    m_pTcSfMtrxDb = 0;
    m_pTcSfMtrxCplxDb = 0;
    m_pTcSfMtrxInvs = 0;
    m_pTcSfMtrxInvsCplx = 0;

    m_inStart = rClTermAg.m_inStart;
    m_inSize = rClTermAg.m_inSize;
    m_inStride = rClTermAg.m_inStride;
    m_blCmplx = rClTermAg.m_blCmplx;
    //m_strVarName = "";  //rClTermAg.m_strVarName;

    //m_pTcSfMtrxDb = rClTermAg.m_pTcSfMtrxDb;
    
    if ( m_blCmplx == true){
        m_vlrDb.resize(0);  // make other side size 0
        m_vlrCplxDb.resize( rClTermAg.m_vlrCplxDb.size() );
        m_vlrCplxDb = rClTermAg.m_vlrCplxDb;
        if ( rClTermAg.m_pTcSfMtrxCplxDb == 0){
            m_pTcSfMtrxCplxDb = 0;
        }else{
            m_pTcSfMtrxCplxDb = new TcSfMtrx<complex<double> >( m_vlrCplxDb
                    , rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn, rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow);
        }
        if ( rClTermAg.m_pTcSfMtrxInvsCplx == 0){
            m_pTcSfMtrxInvsCplx = 0;
        }else{
            m_pTcSfMtrxInvsCplx = new TcSfMtrxInvs<complex<double> >(*rClTermAg.m_pTcSfMtrxInvsCplx);
        }
    }else{
        m_vlrCplxDb.resize(0);  // make other side size 0
        m_vlrDb.resize( rClTermAg.m_vlrDb.size() );
        m_vlrDb = rClTermAg.m_vlrDb;
        if ( rClTermAg.m_pTcSfMtrxDb == 0){
            m_pTcSfMtrxDb = 0;
        }else{
            m_pTcSfMtrxDb = new TcSfMtrx<double>( m_vlrDb
                    , rClTermAg.m_pTcSfMtrxDb->m_sztColumn, rClTermAg.m_pTcSfMtrxDb->m_sztRow);
        }
        if ( rClTermAg.m_pTcSfMtrxInvs == 0){
            m_pTcSfMtrxInvs = 0;
        }else{
            m_pTcSfMtrxInvs = new TcSfMtrxInvs<double >(*rClTermAg.m_pTcSfMtrxInvs);
        }
    }
    return *this;
}

//! Calculation result is saved this in m_vlrDb or m_vlrCplxDb
//! rClTermArgmentAg argment is not const because makeCmplxRealSame(.) may change it
void ClTerm::CalculateFourOperations( const string& crStrOperatorAg, ClTerm& rClTermArgmentAg)
{
    //!! ���ӁA���̊֐��̓r���ł� return ���߂��g���Ȃ��B�֐��̍Ō�Ōv�Z���� rClTermArgmentAg �� NaN ���m�F���邽�߁B
    makeCmplxRealSame( kr *this, kr rClTermArgmentAg);

    if ( m_blCmplx == true ){

        complex<double> cplxAt = rClTermArgmentAg.m_vlrCplxDb[0];
        if (( m_pTcSfMtrxCplxDb == 0) && (m_vlrCplxDb.size() == 1)
          && (rClTermArgmentAg.m_pTcSfMtrxCplxDb == 0 )
          && (rClTermArgmentAg.m_vlrCplxDb.size() == 1)
        ){
            if ( crStrOperatorAg == "+"){
                m_vlrCplxDb[0] += cplxAt;
            }else if ( crStrOperatorAg == "-"){
                m_vlrCplxDb[0] -= cplxAt;
            }else if ( crStrOperatorAg == "*"){
                m_vlrCplxDb[0] *= cplxAt;
            }else if ( crStrOperatorAg == "^"){
                m_vlrCplxDb[0] = pow(m_vlrCplxDb[0],cplxAt);
            }else if ( crStrOperatorAg == "/"){
                kAssert("Devide by 0 at ClTerm::CalculateFourOperations(..)!"
                        , (cplxAt.imag() != 0)
                       || (cplxAt.real() != 0)
                );
                m_vlrCplxDb[0] /= cplxAt;
            }else{
                kAssert("Abonormal operator: " + crStrOperatorAg + " at scalar and scalar operation.", 0);
            }
        }else if ( (rClTermArgmentAg.m_pTcSfMtrxCplxDb==0) && (rClTermArgmentAg.m_vlrCplxDb.size() == 1) ){
            // complex vector operatro scalar
            if ( crStrOperatorAg == "*"){
                m_vlrCplxDb *= cplxAt;
            }else if ( crStrOperatorAg == "/"){
                kAssert("Devide by 0 at ClTerm::CalculateFourOperations(..)!"
                        , (cplxAt.imag() != 0)
                       || (cplxAt.real() != 0)
                );
                m_vlrCplxDb /= cplxAt;
            }else if ( crStrOperatorAg == "^"){
                //complex vector or matrix ^ scalar
                kAssert("Complex Vector ^ scalar operation is not supported.", m_pTcSfMtrxCplxDb != 0);
                kAssert("Complex Rectangular Matrix ^ scalar operation is not supported."
                        , m_pTcSfMtrxCplxDb->m_sztColumn == m_pTcSfMtrxCplxDb->m_sztRow);
                kAssert("Complex Matrix ^ complex scalar operation is not supported."
                        , rClTermArgmentAg.m_vlrCplxDb[0].imag() == 0);
                int inPowerAt = static_cast<int>(rClTermArgmentAg.m_vlrCplxDb[0].real() );
                kAssert("Complex Matrix ^ float scalar operation is not supported."
                        , inPowerAt == rClTermArgmentAg.m_vlrCplxDb[0].real() );

                size_t sztRowAt = m_pTcSfMtrxCplxDb->m_sztRow;
                if ( inPowerAt < 0){
                    //make invert matrix
                    makeCplxInvs( kr *this);
                    //cout << "debug:" << tfGetStrVal(m_vlrCplxDb) << endl;
                    //set I matrix
#if 0
                    // 04.10.13 �t�s�� tiny pivot �Ɉ������������Ƃ��AmakeCplxInvs(.) ���� kAssert(.) �������Ă��܂��B
                    // ���̃`�F�b�N���������Ƃ͂Ȃ�
                    if(m_pTcSfMtrxInvs->m_enState != TcSfMtrxInvs<double>::EnInverted){
                        kAssert("Variable:"+ m_strVarName + " has too small determinant.We can't calculate negative power:^-.", 0);
                    }
#endif
                    m_vlrCplxDb = m_pTcSfMtrxInvsCplx->m_vlrT;
                    TcSfMtrx<complex<double> > tcSfMtrxCplxDbAt(m_pTcSfMtrxInvsCplx->m_vlrT,sztRowAt, sztRowAt);
                    inPowerAt = -inPowerAt;
                    for (int i=0; i<inPowerAt-1;++i){
                        m_pTcSfMtrxCplxDb->Multiply( tcSfMtrxCplxDbAt );
                    }
                }else if ( inPowerAt == 0){
                    m_vlrCplxDb = 0;
                    m_vlrCplxDb[slice(0,m_pTcSfMtrxCplxDb->m_sztRow, m_pTcSfMtrxCplxDb->m_sztRow+1)]
                            = complex<double>(1);
                }else{
                    valarray<complex<double> > vlrCplxDbAt(m_vlrCplxDb);
                    TcSfMtrx<complex<double> > tcSfMtrxCplxDbAt(vlrCplxDbAt
                            , m_pTcSfMtrxCplxDb->m_sztColumn, m_pTcSfMtrxCplxDb->m_sztRow);
                    for (int i=0; i<inPowerAt-1;++i){
                        m_pTcSfMtrxCplxDb->Multiply( tcSfMtrxCplxDbAt );
                    }
                }
                delete m_pTcSfMtrxInvsCplx;
                m_pTcSfMtrxInvsCplx = 0;
            }else {
                // ( crStrOperatorAg == "+") || ( crStrOperatorAg == "-")
                kAssert("We dont support vector " + crStrOperatorAg + " scalar operation", false);
            }
        }else if ( (m_pTcSfMtrxCplxDb==0) && (m_vlrCplxDb.size() == 1) ){
            // complex scalar operator vector
            complex<double> cplxAt = m_vlrCplxDb[0];
            *this = rClTermArgmentAg;
            if ( crStrOperatorAg == "*"){
                m_vlrCplxDb *= cplxAt;
            }else if ( (crStrOperatorAg == "/")
                   &&  (m_pTcSfMtrxCplxDb != 0) // *this = rClTermArgmetAg �̌�ł�
            ){
                // scalar / maxtorx ����
                makeCplxInvs( kr *this);
                m_vlrCplxDb = m_pTcSfMtrxInvsCplx->m_vlrT;
                m_vlrCplxDb *= cplxAt;
            }else {
                // (crStrOperatorAg == "^") || ( crStrOperatorAg == "+") || ( crStrOperatorAg == "-")
                kAssert("We dont support scalar " + crStrOperatorAg + " vector operation", false);
            }
            delete m_pTcSfMtrxInvsCplx;
            m_pTcSfMtrxInvsCplx = 0;
        }else{
            //Matrix operator Vector   or Matrix operator Matrix   or vector and vector
            if ( crStrOperatorAg == "+"){
                kAssert( "Not equal size valarry matrix + operatin."
                        , m_vlrCplxDb.size() == rClTermArgmentAg.m_vlrCplxDb.size() );
                if ( (m_pTcSfMtrxCplxDb != 0) || (rClTermArgmentAg.m_pTcSfMtrxCplxDb != 0) ){
                    kAssert( "Matrix + operatio with vector."
                            ,  ( m_pTcSfMtrxCplxDb != 0)
                            && ( rClTermArgmentAg.m_pTcSfMtrxCplxDb != 0)
                    );
                    kAssert( "Matrix + operatio with differenct column/row size."
                            ,  (m_pTcSfMtrxCplxDb->m_sztColumn ==  rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztColumn )
                            && (m_pTcSfMtrxCplxDb->m_sztRow ==  rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztRow )
                    );
                }
                m_vlrCplxDb += rClTermArgmentAg.m_vlrCplxDb;
            }else if ( crStrOperatorAg == "-"){
                kAssert( "Not equal size valarry matrix - operatin.", m_vlrCplxDb.size() == rClTermArgmentAg.m_vlrCplxDb.size() );
                if ( (m_pTcSfMtrxCplxDb != 0) || (rClTermArgmentAg.m_pTcSfMtrxCplxDb != 0) ){
                    kAssert( "Matrix - operatio with different vector/matrix size."
                            , (m_pTcSfMtrxCplxDb != 0) && (rClTermArgmentAg.m_pTcSfMtrxCplxDb != 0) );
                    
                    kAssert( "Matrix - operatio with different matrix size."
                            , (m_pTcSfMtrxCplxDb->m_sztColumn == rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztColumn)
                           && (m_pTcSfMtrxCplxDb->m_sztRow == rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztRow)
                    );
                }
                m_vlrCplxDb -= rClTermArgmentAg.m_vlrCplxDb;
            }else if ( crStrOperatorAg == "*"){
                if ( rClTermArgmentAg.m_pTcSfMtrxCplxDb == 0 ){
                    // rClTermArgmentAg is vector
                    //kAssert( "Vector and Vector * operation.", m_pTcSfMtrxCplxDb != 0);
                    if ( m_pTcSfMtrxCplxDb == 0){
                        // vector * vector
                        kAssert( "Vector * Vector operation with different size."
                                , m_vlrCplxDb.size() == rClTermArgmentAg.m_vlrCplxDb.size() );
                        m_vlrCplxDb *= rClTermArgmentAg.m_vlrCplxDb;
                    }else{
                        // matrix * vector
                        kAssert( "Matrix * Vector operation with different size."
                                , m_pTcSfMtrxCplxDb->m_sztRow == rClTermArgmentAg.m_vlrCplxDb.size() );
                        m_pTcSfMtrxCplxDb->Multiply(rClTermArgmentAg.m_vlrCplxDb);
                        delete m_pTcSfMtrxCplxDb;
                        m_pTcSfMtrxCplxDb = 0;
                    }
                }else{
                    // rClTermArgmentAg is matrix
                    kAssert( "Vector * Matrix operation. Should be Matrix * vector.", m_pTcSfMtrxCplxDb != 0);
                    kAssert( "Matrix * Matrix operation with different size."
                            , m_pTcSfMtrxCplxDb->m_sztRow == rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztColumn );
                    m_pTcSfMtrxCplxDb->Multiply(*rClTermArgmentAg.m_pTcSfMtrxCplxDb);
                }
            }else if ( crStrOperatorAg == "/"){
                if ( (m_pTcSfMtrxCplxDb != 0) && (rClTermArgmentAg.m_pTcSfMtrxCplxDb != 0) ){
                    kAssert("Not equal matrix row/column size at / operation."
                            , m_pTcSfMtrxCplxDb->m_sztRow == rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztColumn);
                    makeCplxInvs( kr rClTermArgmentAg);
                    TcSfMtrx<complex<double> > tcSfMtrxCplxDbAt(rClTermArgmentAg.m_pTcSfMtrxInvsCplx->m_vlrT
                            , rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztColumn, rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztRow);
                    m_pTcSfMtrxCplxDb->Multiply( tcSfMtrxCplxDbAt );
                }else{
                    kAssert( "We inhibit vector/vector, vector/Matrix or Matrix/vector operation",false);
                }
#if 0   //04.10 13 $ �͏����̊g�������� operator �ɂ���
            }else if ( crStrOperatorAg == "$"){
                kAssert( m_strVarName + " is not matrix at $ operation.", m_pTcSfMtrxCplxDb != 0);
                kAssert( m_strVarName + " is not square matrix at $ operation."
                        , m_pTcSfMtrxCplxDb->m_sztColumn == m_pTcSfMtrxCplxDb->m_sztRow );


                if ( m_pTcSfMtrxInvsCplx == 0 ){
                    TcCrout<complex<double> >* pTcCroutCplxDbAt
                            = new TcCrout<complex<double> >(rClTermArgmentAg.m_vlrCplxDb);
                    if ( rClTermArgmentAg.m_pTcSfMtrxCplxDb == 0 ){
                        // rClTermArgmentAg is vector
                        pTcCroutCplxDbAt->MulCrout( kr rClTermArgmentAg.m_vlrCplxDb);
                        m_vlrCplxDb.resize(rClTermArgmentAg.m_vlrCplxDb.size());
                        delete m_pTcSfMtrxCplxDb;
                        m_pTcSfMtrxCplxDb = 0;
                        m_vlrCplxDb = rClTermArgmentAg.m_vlrCplxDb;
                    }else{
                        // rClTermArgmentAg is matrix
                        pTcCroutCplxDbAt->MulCrout( kr rClTermArgmentAg.m_vlrCplxDb
                                , rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztRow);
                        m_vlrCplxDb.resize(0);
                        this->makeMatrix( true/* complex */,m_pTcSfMtrxCplxDb->m_sztColumn
                                , rClTermArgmentAg.m_pTcSfMtrxCplxDb->m_sztRow);
                        m_vlrCplxDb = rClTermArgmentAg.m_vlrCplxDb;
                    }
                    delete pTcCroutCplxDbAt;
                }else{
                    if ( rClTermArgmentAg.m_pTcSfMtrxCplxDb == 0 ){
                        // rClTermArgmentAg is vector
                        m_pTcSfMtrxInvsCplx->m_pTcSfMtrx->Multiply( rClTermArgmentAg.m_vlrCplxDb);
                        m_vlrCplxDb.resize(rClTermArgmentAg.m_vlrCplxDb.size());
                        m_vlrCplxDb = m_pTcSfMtrxInvsCplx->m_vlrT;

                        delete m_pTcSfMtrxCplxDb;
                        m_pTcSfMtrxCplxDb = 0;
                    }else{
                        // rClTermArgmentAg is matrix
                        m_pTcSfMtrxInvsCplx->m_pTcSfMtrx->Multiply( *rClTermArgmentAg.m_pTcSfMtrxCplxDb);
                        m_vlrDb.resize(0);
                        this->makeMatrix( false/* real */,m_pTcSfMtrxDb->m_sztColumn
                                , rClTermArgmentAg.m_pTcSfMtrxDb->m_sztRow);
                        m_vlrCplxDb = m_pTcSfMtrxInvsCplx->m_pTcSfMtrx->m_rVlrT;
                    }
                    delete m_pTcSfMtrxInvsCplx;
                    m_pTcSfMtrxInvsCplx = 0;
                }
#endif //0  04.10 13 $ �͏����̊g�������� operator �ɂ���

            }else {
                // (crStrOperatorAg == "^") || ( crStrOperatorAg == "/")
                kAssert("Now we dont support vectorOrmatrix " + crStrOperatorAg + " vectorOrMatrix", false);
            }
            delete m_pTcSfMtrxInvsCplx;
            m_pTcSfMtrxInvsCplx = 0;
            m_strVarName = "";
        }
    }else{
        // real value operation

        double dbAt = rClTermArgmentAg.m_vlrDb[0];
        if ( (m_pTcSfMtrxDb == 0) && (m_vlrDb.size() == 1)
          && (rClTermArgmentAg.m_pTcSfMtrxDb == 0)
          && (rClTermArgmentAg.m_vlrDb.size() == 1)
        ){
            if ( crStrOperatorAg == "+"){
                m_vlrDb[0] += dbAt;
            }else if ( crStrOperatorAg == "-"){
                m_vlrDb[0] -= dbAt;
            }else if ( crStrOperatorAg == "*"){
                m_vlrDb[0] *= dbAt;
            }else if ( crStrOperatorAg == "^"){
                //double dbMinAt = rClTermArgmentAg.m_vlrDb.min();
                //if ( dbMinAt < 0)
                if ( m_vlrDb[0] < 0){
                    convertRealToComplex(kr rClTermArgmentAg);
                    convertRealToComplex(kr *this);
                    m_vlrCplxDb[0] = pow(m_vlrCplxDb[0], rClTermArgmentAg.m_vlrCplxDb[0]);
                    //return;
                }else{
                    m_vlrDb[0] = pow(m_vlrDb[0],dbAt);
                }
            }else if ( crStrOperatorAg == "/"){
                kAssert("Devide by 0 at ClTerm::CalculateFourOperations(..)!"
                        , dbAt != 0
                );
                m_vlrDb[0] /= dbAt;
            }else{
                kAssert("Abonormal operator: " + crStrOperatorAg + " at scalar and scalar operation.", 0);
            }
        }else if ( (rClTermArgmentAg.m_pTcSfMtrxDb==0) && (rClTermArgmentAg.m_vlrDb.size() == 1) ){
            if ( crStrOperatorAg == "*"){
                m_vlrDb *= dbAt;
            }else if ( crStrOperatorAg == "/"){
                kAssert("Devide by 0 at ClTerm::CalculateFourOperations(..)!"
                        , dbAt != 0
                );
                m_vlrDb /= dbAt;
            }else if ( crStrOperatorAg == "^"){
                //real vector or matrix ^ scalar
                kAssert("Real Vector ^ scalar operation is not supported.", m_pTcSfMtrxDb != 0);
                kAssert("Real Rectangular Matrix ^ scalar operation is not supported."
                        , m_pTcSfMtrxDb->m_sztColumn == m_pTcSfMtrxDb->m_sztRow);
                int inPowerAt = static_cast<int>(rClTermArgmentAg.m_vlrDb[0] );
                kAssert("Real Matrix ^ float scalar operation is not supported."
                        , inPowerAt == rClTermArgmentAg.m_vlrDb[0] );

                size_t sztRowAt = m_pTcSfMtrxDb->m_sztRow;
                if ( inPowerAt < 0){
                    //make invert matrix
                    makeInverse( kr *this);
                    //cout << "debug:" << tfGetStrVal(m_vlrDb) << endl;
                    //set I matrix
#if 0
                    // 04.10.13 �t�s�� tiny pivot �Ɉ������������Ƃ��AmakeInverse(.) ���� kAssert(.) �������Ă��܂��B
                    // ���̃`�F�b�N���������Ƃ͂Ȃ�
                    ifm_pTcSfMtrxInvs->m_enState != TcSfMtrxInvs<double>::EnInverted){
                        kAssert("Variable:"+ m_strVarName + " has too small determinant.We can't calculate negative power:^-.", 0);
                    }
#endif //0
                    m_vlrDb = m_pTcSfMtrxInvs->m_vlrT;
                    TcSfMtrx<double> tcSfMtrxDbAt(m_pTcSfMtrxInvs->m_vlrT,sztRowAt, sztRowAt);
                    inPowerAt = -inPowerAt;
                    for (int i=0; i<inPowerAt-1;++i){
                        m_pTcSfMtrxDb->Multiply( tcSfMtrxDbAt );
                    }
                }else if ( inPowerAt == 0){
                    m_vlrDb = 0;
                    m_vlrDb[slice(0,m_pTcSfMtrxDb->m_sztRow, m_pTcSfMtrxDb->m_sztRow+1)]
                            = 1;
                }else{
                    valarray<double> vlrDbAt(m_vlrDb);
                    TcSfMtrx<double> tcSfMtrxAt(vlrDbAt, m_pTcSfMtrxDb->m_sztColumn, m_pTcSfMtrxDb->m_sztRow);
                    for (int i=0; i<inPowerAt-1;++i){
                        this->m_pTcSfMtrxDb->Multiply( tcSfMtrxAt );
                    }
                }
                //delete m_pTcSfMtrxInvs;
                //m_pTcSfMtrxInvs = 0;
            }else {
                // ( crStrOperatorAg == "+") || ( crStrOperatorAg == "-")
                kAssert("We dont support vector " + crStrOperatorAg + " scalar operation", 0);
            }
        }else if ( (m_pTcSfMtrxDb==0) && (m_vlrDb.size() == 1) ){
            // real scalar operator vector
            dbAt = m_vlrDb[0];
            *this = rClTermArgmentAg;
            if ( crStrOperatorAg == "*"){
                m_vlrDb *= dbAt;
            }else if ( (crStrOperatorAg == "/")
                   &&  (m_pTcSfMtrxDb != 0) // *this = rClTermArgmentAg; �̌�ł�
            ){
                // scalar / maxtorx ���ł�
                makeInverse( kr *this);
                m_vlrDb = m_pTcSfMtrxInvs->m_vlrT;
                m_vlrDb *= dbAt;
            }else {
                // (crStrOperatorAg == "^") || ( crStrOperatorAg == "+") || ( crStrOperatorAg == "-")
                kAssert("We dont support scalar " + crStrOperatorAg + " vector operation", false);
            }
            delete m_pTcSfMtrxInvs;
            m_pTcSfMtrxInvs = 0;
        }else{
            //Operation of Vector operator Vector or Matrix operator Vector   or Matrix operator Matrix
            if ( crStrOperatorAg == "+"){
                kAssert( "Not equal size valarry matrix + operatin."
                        , m_vlrDb.size() == rClTermArgmentAg.m_vlrDb.size() );
                if ( (m_pTcSfMtrxDb != 0) || (rClTermArgmentAg.m_pTcSfMtrxDb != 0) ){
                    kAssert( "Matrix + operatio with vector."
                            ,  ( m_pTcSfMtrxDb != 0)
                            && ( rClTermArgmentAg.m_pTcSfMtrxDb != 0)
                    );
                    kAssert( "Matrix + operatio with differenct column/row size."
                            ,  (m_pTcSfMtrxDb->m_sztColumn ==  rClTermArgmentAg.m_pTcSfMtrxDb->m_sztColumn )
                            && (m_pTcSfMtrxDb->m_sztRow ==  rClTermArgmentAg.m_pTcSfMtrxDb->m_sztRow )
                    );
                }
                m_vlrDb += rClTermArgmentAg.m_vlrDb;
            }else if ( crStrOperatorAg == "-"){
                kAssert( "Not equal size valarry matrix - operatin.", m_vlrDb.size() == rClTermArgmentAg.m_vlrDb.size() );
                if ( (m_pTcSfMtrxDb != 0) || (rClTermArgmentAg.m_pTcSfMtrxDb != 0) ){
                    kAssert( "Matrix - operatio with different vector/matrix."
                            ,  ( m_pTcSfMtrxDb != 0) && ( rClTermArgmentAg.m_pTcSfMtrxDb != 0)
                    );
                    kAssert( "Matrix - operatio with differenct column/row size."
                            ,  (m_pTcSfMtrxDb->m_sztColumn ==  rClTermArgmentAg.m_pTcSfMtrxDb->m_sztColumn )
                            && (m_pTcSfMtrxDb->m_sztRow ==  rClTermArgmentAg.m_pTcSfMtrxDb->m_sztRow )
                    );
                }
                m_vlrDb -= rClTermArgmentAg.m_vlrDb;
            }else if ( crStrOperatorAg == "*"){
                if ( rClTermArgmentAg.m_pTcSfMtrxDb == 0 ){
                    // rClTermArgmentAg is vector
                    //kAssert( "Vector and Vector * operation.", m_pTcSfMtrxDb != 0);
                    if ( m_pTcSfMtrxDb == 0){
                        // vector * vector
                        kAssert( "Vector * Vector operation with different size."
                                , m_vlrDb.size() == rClTermArgmentAg.m_vlrDb.size() );
                        m_vlrDb *= rClTermArgmentAg.m_vlrDb;
                    }else{
                        kAssert( "Matrix * Vector operation with different size."
                                , m_pTcSfMtrxDb->m_sztRow == rClTermArgmentAg.m_vlrDb.size() );
                        m_pTcSfMtrxDb->Multiply(rClTermArgmentAg.m_vlrDb);
                        delete m_pTcSfMtrxDb;
                        m_pTcSfMtrxDb = 0;
                    }
                }else{
                    // rClTermArgmentAg is matrix
                    kAssert( "Vector * Matrix operation. Should be Matrix * vector.", m_pTcSfMtrxDb != 0);
                    kAssert( "Matrix * Matrix operation with different size."
                            , m_pTcSfMtrxDb->m_sztRow == rClTermArgmentAg.m_pTcSfMtrxDb->m_sztColumn );
                    m_pTcSfMtrxDb->Multiply(*rClTermArgmentAg.m_pTcSfMtrxDb);
                }
            }else if ( crStrOperatorAg == "/"){
                if ( (m_pTcSfMtrxDb != 0) && (rClTermArgmentAg.m_pTcSfMtrxDb != 0) ){
                    kAssert("Not equal matrix row/column size at / operation."
                            , m_pTcSfMtrxDb->m_sztRow == rClTermArgmentAg.m_pTcSfMtrxDb->m_sztColumn);
                    makeInverse( kr rClTermArgmentAg);
                    TcSfMtrx<double > tcSfMtrxDbAt(rClTermArgmentAg.m_pTcSfMtrxInvs->m_vlrT
                            , rClTermArgmentAg.m_pTcSfMtrxDb->m_sztColumn, rClTermArgmentAg.m_pTcSfMtrxDb->m_sztRow);
                    m_pTcSfMtrxDb->Multiply(tcSfMtrxDbAt);
                }else{
                    kAssert( "We inhibit vector/vector, vector/Matrix or Matrix/vector operation",false);
                }
#if 0   //04.10 13 $ �͏����̊g�������� operator �ɂ���
            }else if ( crStrOperatorAg == "$"){
                kAssert( m_strVarName + " is not matrix at $ operation.", m_pTcSfMtrxDb != 0);
                kAssert( m_strVarName + " is not square matrix at $ operation."
                        , m_pTcSfMtrxDb->m_sztColumn == m_pTcSfMtrxDb->m_sztRow );


                if ( m_pTcSfMtrxInvs == 0 ){
                    TcCrout<double>* pTcCroutDbAt = new TcCrout<double>(rClTermArgmentAg.m_vlrDb);
                    if ( rClTermArgmentAg.m_pTcSfMtrxDb == 0 ){
                        // rClTermArgmentAg is vector
                        pTcCroutDbAt->MulCrout( kr rClTermArgmentAg.m_vlrDb);
                        m_vlrDb.resize(rClTermArgmentAg.m_vlrDb.size());
                        delete m_pTcSfMtrxDb;
                        m_pTcSfMtrxDb = 0;
                        m_vlrDb = rClTermArgmentAg.m_vlrDb;
                    }else{
                        // rClTermArgmentAg is matrix
                        pTcCroutDbAt->MulCrout( kr rClTermArgmentAg.m_vlrDb
                                , rClTermArgmentAg.m_pTcSfMtrxDb->m_sztRow);
                        m_vlrDb.resize(0);
                        this->makeMatrix( false/* real */,m_pTcSfMtrxDb->m_sztColumn
                                , rClTermArgmentAg.m_pTcSfMtrxDb->m_sztRow);
                        m_vlrDb = rClTermArgmentAg.m_vlrDb;
                    }

                    delete pTcCroutDbAt;
                }else{
                    if ( rClTermArgmentAg.m_pTcSfMtrxDb == 0 ){
                        // rClTermArgmentAg is vector
                        m_pTcSfMtrxInvs->m_pTcSfMtrx->Multiply( rClTermArgmentAg.m_vlrDb);
                        m_vlrDb.resize(rClTermArgmentAg.m_vlrDb.size());
                        m_vlrDb = m_pTcSfMtrxInvs->m_pTcSfMtrx->m_rVlrT;

                        delete m_pTcSfMtrxDb;
                        m_pTcSfMtrxDb = 0;
                    }else{
                        // rClTermArgmentAg is matrix
                        m_pTcSfMtrxInvs->m_pTcSfMtrx->Multiply( *rClTermArgmentAg.m_pTcSfMtrxDb);
                        m_vlrDb.resize(0);
                        this->makeMatrix( false/* real */,m_pTcSfMtrxDb->m_sztColumn
                                , rClTermArgmentAg.m_pTcSfMtrxDb->m_sztRow);
                        m_vlrDb = m_pTcSfMtrxInvs->m_pTcSfMtrx->m_rVlrT;
                    }
                    delete m_pTcSfMtrxInvs;
                    m_pTcSfMtrxInvs = 0;
                }
#endif //0  04.10 13 $ �͏����̊g�������� operator �ɂ���
            }else {
                // (crStrOperatorAg == "^") || ( crStrOperatorAg == "/")
                kAssert("Now we dont support vectorOrmatrix " + crStrOperatorAg + " vectorOrMatrix", false);
            }
            delete m_pTcSfMtrxInvs;
            m_pTcSfMtrxInvs = 0;
            m_strVarName = "";
        }
    }
}

static const string cStrWhiteSpaceOperatorFuntionAt(" \x09!~+-*/^$"); // space and tab(code:0x09) and operator
static const string cStrNumberAt("01234565789");
static const string cStrSignAt("+-.");
static const string cStrSymbolAt("@<(");
static const string cStrGreepAt("�������������������������������������������������������ÃăŃƃǃȃɃʃ˃̃̓΃σЃу҃ӃԃՃ�");

static bool IsNextCharacterImage_i(string& rStrAg)
{
    static const string cStrWhiteSpaceOperatorFuntionAt(" \x09!~+-*/^$"); // space and tab number and operator
    static const string cStrNumberAt("01234565789");
    static const string cStrSignAt("+-.");
    static const string cStrSymbolAt("@<(");
    static const string cStrGreepAt("�������������������������������������������������������ÃăŃƃǃȃɃʃ˃̃̓΃σЃу҃ӃԃՃ�");

    if ( rStrAg[0] == 'i'){
        if ( (rStrAg.size() == 1)   // "i"
           ||(cStrWhiteSpaceOperatorFuntionAt.find(rStrAg[1]) != string::npos)  // i^...
           ||(cStrSymbolAt.find(rStrAg[1]) != string::npos)                     // i@subroutine..
           ||(cStrSignAt.find(rStrAg[1]) != string::npos)                       // i+..
           ||(cStrSymbolAt.find(rStrAg[1]) != string::npos)                     // i<1,2>..
           ||(cStrGreepAt.find(rStrAg[1]) != string::npos)                      // i��..
        
        ){
            rStrAg = rStrAg.substr(1, rStrAg.size()-1);
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
}
static bool getAndCheckNumericTerm(string& rStrResidualAg, ClTerm& rClTermAg)
{

    cutFrontRearWhiteSpace(rStrResidualAg);

    if ( (cStrNumberAt.find(rStrResidualAg[0]) != string::npos)     // 123variable..  or 0b101i
      || ( (cStrSignAt.find(rStrResidualAg[0]) != string::npos)     // +123variable.. or .12ivariable...
         &&(cStrNumberAt.find(rStrResidualAg[1]) != string::npos)
         )
      || ( (rStrResidualAg[0] == 'i')                               
         &&(rStrResidualAg.size() >= 2)
         &&( (cStrWhiteSpaceOperatorFuntionAt.find(rStrResidualAg[1]) != string::npos)  // i*..
           ||(cStrSymbolAt.find(rStrResidualAg[1]) != string::npos)                     // i@subroutine
           )
         )
      || ( (rStrResidualAg[0] == 'i')           //  "i" 
         &&(rStrResidualAg.size() == 1)
         )
      || ( (rStrResidualAg[0] == 'i')   //2004.06.24 i�΂ȂǁA���f�� i �ƃM���V�������̘A���Ō듮�삵�Ă����΍�ł�
         &&(rStrResidualAg.size() >= 3)         // i��..
         &&(cStrGreepAt.find( rStrResidualAg.substr(1,2) ) != string::npos)
         )
    ){
        // rStrResidualAg first character is number started with 0b, 0B
        if ( rStrResidualAg/ krgBinaryNumericTermStt != ""){
            int inAt = convertBinStr2Int(krgBinaryNumericTermStt);
            rStrResidualAg = krgBinaryNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
            if ( IsNextCharacterImage_i(kr rStrResidualAg) ){
                //binary complex number e.g. 0b1010i 
                rClTermAg.m_blCmplx = true;
                //rStrResidualAg = rStrResidualAg.substr(1, rStrResidualAg.size()-1);
                rClTermAg.m_vlrCplxDb.resize(1);
                rClTermAg.m_vlrCplxDb[0] = complex<double>(0,inAt);
            }else{
                rClTermAg.m_vlrDb.resize(1);
                rClTermAg.m_vlrDb[0] = inAt;
            }
        }else if ( rStrResidualAg/ krgHexNumericTermStt != ""){
            kAssert("Too long hex number string: " + krgHexNumericTermStt, krgHexNumericTermStt.size() <= (8+2) );
            istringstream istrmAt(krgHexNumericTermStt % krg::EnMatched);
            istrmAt.unsetf(std::ios::basefield);
            int inAt;
            istrmAt >> inAt;
            rStrResidualAg = krgHexNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
            if ( IsNextCharacterImage_i(kr rStrResidualAg) ){
                //hex complex number e.g. 0x1010i 
                rClTermAg.m_blCmplx = true;
                //rStrResidualAg = rStrResidualAg.substr(1, rStrResidualAg.size()-1);
                rClTermAg.m_vlrCplxDb.resize(1);
                rClTermAg.m_vlrCplxDb[0] = complex<double>(0,inAt);
            }else{
                rClTermAg.m_vlrDb.resize(1);
                rClTermAg.m_vlrDb[0] = inAt;
            }
        }else if ( rStrResidualAg/ krgScientificNumericTermStt != ""){
            istringstream istrmMantissaAt(krgScientificNumericTermStt%4);
            int inAt;
            istrmMantissaAt >> inAt;
            kAssert("Too big/small float number at " + rStrResidualAg, inAt <= 300);
            
            istringstream istrmAt(krgScientificNumericTermStt);
            
            double dbAt;
            istrmAt >> dbAt;
            rStrResidualAg = krgScientificNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
            if ( IsNextCharacterImage_i(kr rStrResidualAg) ){
                rClTermAg.m_blCmplx = true;
                rClTermAg.m_vlrCplxDb.resize(1);
                rClTermAg.m_vlrCplxDb[0] = complex<double>(0,dbAt);
            }else{
                rClTermAg.m_vlrDb.resize(1);
                rClTermAg.m_vlrDb[0] = dbAt;
            }
        }else if ( rStrResidualAg[0] == 'i'){
            rStrResidualAg = rStrResidualAg.substr(1, rStrResidualAg.size()-1);
            rClTermAg.m_blCmplx = true;
            rClTermAg.m_vlrCplxDb.resize(1);
            rClTermAg.m_vlrCplxDb[0] = complex<double>(0,1);
        }else if ( rStrResidualAg/ krgFloatNumericTermStt != ""){
            istringstream istrmAt(krgFloatNumericTermStt);
            double dbAt;
            istrmAt >> dbAt;
            rStrResidualAg = krgFloatNumericTermStt % krgstr::EnPostMatched;  //m_strPostMatched
            if ( IsNextCharacterImage_i(kr rStrResidualAg) ){
                rClTermAg.m_blCmplx = true;
                rClTermAg.m_vlrCplxDb.resize(1);
                rClTermAg.m_vlrCplxDb[0] = complex<double>(0,dbAt);
            }else{
                rClTermAg.m_vlrDb.resize(1);
                rClTermAg.m_vlrDb[0] = dbAt;
            }
        }else{
            // �����֗��Ȃ��͂��B�����ɗ��鐔�l��������v�����Ȃ�
            kAssert("Internal Error;sf falls on unexpected numeric format at "+ rStrResidualAg, 0);
        }
        cutFrontRearWhiteSpace(rStrResidualAg);
        return true;
    }else{
        // This rStrResidualAg may begin with variable(not number) term.
        //assert( rClTermAg.m_vlrDb.size() !=0 &&  rClTermAg.m_vlrDb.size() !=0); 03.04.06 ���̂Ƃ� m_vlrDb.size() == 0
        // or [[n]], <<i,j,k>>
        return false;
    }
}

#if 0 //04.10.15 ���ʂ������Ȃ��̂Ŏ~�߂�B��ŕ��������邩��
// sf ���������񂾃t�@�C���ϐ��̐��l������ł��邱�Ƃ𔻒肷��
// " +-0123456789e," �̕����݂̂̂Ƃ� true ��Ԃ�
//e �̎�O�͐����Ae �̌��+- �̂݁Bvoid getVectorVal(.) ����x�N�^�v�f�̒l�`�F�b�N�ŌĂяo�����
static bool checkSimpleNumbers(const string& crStrAg)
{
    const string cStrNumStt("0123456789");
    const string cStrPlumMinusStt("+-");

    if ( crStrAg.find_first_not_of(" \t+-0123456789eE.") != string::npos){
        // e.g. "��, 3.5"
        return false;
    }
    size_t sztAt=0;
    while(sztAt < crStrAg.size() ){
        if ( (sztAt = crStrAg.find_first_of("eE",sztAt+1)) == string::npos){
            // only number and ','
            return true;
        }
        if ( cStrNumStt.find(crStrAg[sztAt-1]) == string::npos){
            return false;
        }
        if ( (sztAt == crStrAg.size()) 
          || (cStrPlumMinusStt.find(crStrAg[sztAt+1]) == string::npos)
        ){
            return false;
        }
    } 
    return true;
}
#endif // //04.10.15 ���ʂ������Ȃ��̂Ŏ~�߂�B��ŕ��������邩��

//< Don't adopt strict format check to describe codes simply
//< example1 crStrAg == " 1, 3,  4,  10
//< example2 crStrAg == " 1, 3+ 4.8i,  4,  10
//< example3 crStrAg == " 1, 3- 4.8i,  4,  10  --- don't use (3,-4.8) paren bracket
//< if file content is consistent then return ""
static void getVectorVal( const string& crStrAg, ClTerm& rClTermAg)
{
    kAssert("Vector data string length is 0.", crStrAg.size() != 0);
    // '<' and '>' are taked out
    string strVectorAt = crStrAg;
    cutFrontRearWhiteSpace(strVectorAt);


    std::list<string> lstStrAt;
    while ( strVectorAt.size() > 0 ){
        string strAt = getCommand(kr strVectorAt);
        cutFrontRearWhiteSpace(strAt);
        kAssert("Analizing vector string:"+crStrAg+", wee found empty element.", strAt.size() >0);
        lstStrAt.push_back(strAt);
    }

    rClTermAg.m_vlrDb.resize(lstStrAt.size());
    rClTermAg.m_vlrCplxDb.resize(0);
    list<string>::iterator itrAt = lstStrAt.begin();
#if 0
    //04.10.15 ���ʂ������Ȃ��̂Ŏ~�߂�B
    //�T�C�Y�̑傫�ȕϐ��̂Ƃ��A�������l�����񂩂琔�l�ւ̕ϊ��𑁂����邽�߂ɒǉ������B
    //�ڂɌ�������ʂ͌v���ł��Ȃ����A�c���Ă����Bprofiler �ɂ�錟�����K�v�ł�
    if (checkSimpleNumbers(crStrAg) ){
        for (size_t i = 0; i< lstStrAt.size(); ++i){
            std::istringstream isAt(*itrAt);
            double dbAt;
            isAt >> dbAt;
            rClTermAg.m_vlrDb[i]=dbAt;
            ++itrAt;
        }
        return;
    }
#endif

    itrAt = lstStrAt.begin();
    if ( rClTermAg.m_blCmplx == true ){
        rClTermAg.m_vlrDb.resize(0);
        rClTermAg.m_vlrCplxDb.resize(lstStrAt.size() );
    }else{
        rClTermAg.m_vlrCplxDb.resize(0);
        rClTermAg.m_vlrDb.resize(lstStrAt.size() );
    }
    for (size_t i = 0; i< lstStrAt.size(); ++i){
        ClTerm clTermAt;
        clTermAt.Initialize();
        GetRightSideVal( kr *itrAt, kr clTermAt);
        //kAssert("getVaectorVal(.) argment \" "+ vctStrAt[i]
        //         + " \" real complex type are not same."
        //        ,   clTermAt.m_blCmplx == rClTermAg.m_blCmplx );
        kAssert("getVaectorVal(.) argment \" "+ *itrAt + " \" is not scalar."
                , (clTermAt.m_vlrDb.size()+clTermAt.m_vlrCplxDb.size() == 1)
        );
        kAssert("At getVaectorVal(.) elemnt: "+ *itrAt + " \" is matrix."
                , (clTermAt.m_pTcSfMtrxDb == 0)
        );
        ++itrAt;
        
        if ( clTermAt.m_blCmplx == true){
            // save result in complex m_vlrCplxDb
            if ( rClTermAg.m_blCmplx == false ){
                //*itrAt �����񂪕��f���l�������̂ŁA����܂œǂ񂾎����𕡑f�����Ɉڂ�
                rClTermAg.m_vlrCplxDb.resize(rClTermAg.m_vlrDb.size() );
                for (size_t j=0; j<i;++j){
                    rClTermAg.m_vlrCplxDb[j] = complex<double>(rClTermAg.m_vlrDb[j],0);
                }
                rClTermAg.m_vlrDb.resize(0);
                rClTermAg.m_blCmplx = true;
                rClTermAg.m_vlrCplxDb[i] = clTermAt.m_vlrCplxDb[0];
            }else{
                rClTermAg.m_vlrCplxDb[i] = clTermAt.m_vlrCplxDb[0];
            }
        }else{
            // save result in real m_vlrDb
            if (  rClTermAg.m_blCmplx == true ){
                rClTermAg.m_vlrCplxDb[i] = complex<double>(clTermAt.m_vlrDb[0],0);
            }else{
                rClTermAg.m_vlrDb[i] = clTermAt.m_vlrDb[0];
            }
        }
    }
}

struct StPairOld {
    char m_chBegin;
    char m_chEnd;
    int m_inCount;

    int m_inCountBackslash;
  public:
    StPairOld( char chBeginAg, char chEndAg) : m_chBegin(chBeginAg)
        , m_chEnd(chEndAg), m_inCount(0), m_inCountBackslash(0){}
    bool operator()(char chAg )
    {
        if ( chAg == m_chBegin ){
            if ( m_inCountBackslash % 2 == 0){
                m_inCount++;
            }
            m_inCountBackslash=0;
            DfContinue;
        }else if ( chAg == m_chEnd ){
            if ( m_inCountBackslash %2 == 1 ){
                // m_chEnd �����̒��O�Ɋ�� \ �������L��B
                DfContinue;
            }if (m_inCount < 1 ){
                //04.10.15 (..)..) �̂悤�ȕ�����ŁA�^���� ')' �ŏI���Ȃ��悤�� operator() �̌Ăяo�����������Ƃ���
                //�����ɂ���B�v���O�����E�~�X�ł̂ݓ�������Ƃ���ł��B
                kAssert("Internal Error at StPairOld(.)", false);
                DfContinue;     // ����𖳂����� "not all control paths return a value" warning ���o��
            }else if ( m_inCount == 1){
                DfBreak;
            }else{
                m_inCount--;
                DfContinue;
            }
        }else{
            if ( (chAg == _T('\\') )
//              || ( chAg == _T('`') )  <-- !exp(h`) �� ')' �����o�ł��Ȃ��Ȃ��Ă��܂�
            ){
                m_inCountBackslash++;
            }else{
                m_inCountBackslash=0;
            }
            DfContinue;
        }
    }
};

static ksci findIfStPaired(ksci ksciFirstAg, ksci ksciLastAg, StPairOld& rStParedAg);
static krgstr krgSubroutineFunctionStt("([A-Za-z][A-Za-z_0-9`.]*)`(");
static void executeTildaExtention( string& rStrResidualAg)
{
    // sn.exe has only one unitary operation ~: invert
    if (rStrResidualAg / krgSubroutineFunctionStt == ""){
        kAssert("Abnormal mathematical fucntion: ~" + rStrResidualAg, 0);
    }else{
        cutFrontRearWhiteSpace(rStrResidualAg);
        string strFuncAt = krgSubroutineFunctionStt % 1;
        string strOldAgAt = rStrResidualAg; // use at kAssert(.)
        rStrResidualAg = rStrResidualAg.substr(strFuncAt.size() );
        
        StPairOld stPairedAt( '(',')');
        string::const_iterator csiRightAt;
        csiRightAt = findIfStPaired(rStrResidualAg.begin(), rStrResidualAg.end() , kr stPairedAt );
        string strEntityAt((string::const_iterator)(1+rStrResidualAg.begin()),csiRightAt);
        cutFrontRearWhiteSpace(strEntityAt);
        rStrResidualAg = string( ++csiRightAt, (string::const_iterator)rStrResidualAg.end() );

#if 1
        string strCommandAt = strFuncAt;
        // User '....' string. Becase "....." string colide DOS command argments
        if ( strEntityAt[0] == '\'' ){
            kAssert("Now we support only \'.....\' argment in tilda user function argment"
                    , (*strEntityAt.rbegin() == '\'')
                   && ( strEntityAt.size() > 2)
            );

            strEntityAt = strEntityAt.substr(1, strEntityAt.size()-2 );
            cutFrontRearWhiteSpace(strEntityAt);

            strCommandAt += " " + strEntityAt;
            //strCommandAt ���r���� 0x00 ������̂ŁAchiled Process ���G���[�̂Ƃ��� kAssert(.) ���������񂪓r���Ő؂�Ă��܂��΍�ł�
            string strCommandBackAt = strCommandAt; 
            strCommandAt += string("x"); // make ASCIIZ string. Add x:damie position to set 0
            strCommandAt[strCommandAt.size()-1] = 0;

            //bool kk::ExecuteChildProcess(const char* cpChCommandAg, int inSizeAg);
            if (ExecuteChildProcess(strCommandAt.c_str(), strCommandAt.size()) == false){
                //kAssert("ExecuteChildProcess( " + strCommandAt + " error. There may by no executable file.", 0);
                kAssert("ExecuteChildProcess( " + strCommandBackAt + " ) error. Child process may return not 0 code.", 0);
            }
        }else{
            //cout << "size:" << strEntityAt.size() << "  " << strEntityAt << endl; // to debug
            //kAssert("Now we support only \'....\' argment in tilda user function argment:"+strEntityAt,false);
            ClTerm clDammieAt;
            string strCommandBackAt = strFuncAt + "( " + strEntityAt + " )";
            
            int inCountAt=0;
            while (strEntityAt.size() > 0 ){
                string strAt = getCommand(kr strEntityAt);
                cutFrontRearWhiteSpace(kr strAt);
                if ( strAt.size() == 0){
                    kAssert("sf detect blank argment at executeTileExtention(.) for "+ strOldAgAt, false);
                }

                ostringstream ostrmAt;
                ++inCountAt;
                ostrmAt << inCountAt;
                string strArgAt = "_arg"+ostrmAt.str();

                //! 2004.04.18 ������ @subFile ���g����
                //if ( strAt[0] == '@'){
                    //kAssert("@subVar can be used at user function argment", false);
                //}else{
                    //cout << "debug:Mat.m_vlrDb:" << tfGetStrVal(ClTmpVar::GetTmpVarStt("Mat")->m_vlrDb ) << endl;
                    mtrxCommand(strArgAt +"="+ strAt, kr clDammieAt); //!< _argN = command �ɕύX���Ă���
                    if ( ClTerm::IsAbleToPrintStt() == true ){
                        cout << endl;
                    }
                    delete clDammieAt.m_pTcSfMtrxDb;
                    delete clDammieAt.m_pTcSfMtrxCplxDb;
                    delete clDammieAt.m_pTcSfMtrxInvs;
                    delete clDammieAt.m_pTcSfMtrxInvsCplx;
                    clDammieAt.m_pTcSfMtrxDb = 0;
                    clDammieAt.m_pTcSfMtrxCplxDb = 0;
                    clDammieAt.m_pTcSfMtrxInvs = 0;
                    clDammieAt.m_pTcSfMtrxInvsCplx = 0;
                //}

                strCommandAt = strCommandAt + " " + strArgAt;
            }
            //bool kk::ExecuteChildProcess(const char* cpChCommandAg, int inSizeAg);
            if (ExecuteChildProcess(strCommandAt.c_str(), strCommandAt.size() + 1) == false){
                kAssert("ExecuteChildProcess " + strCommandBackAt + " error. Child process may return not 0 code.", 0);
            }
        }
#else
        std::istringstream istrmAt(strEntityAt);
        std::vector<string> vctStrAt;
        while (!istrmAt.eof()){
            string strAt;
            getline(kr istrmAt,kr strAt, ',');
            cutFrontRearWhiteSpace(strAt);

            if ( strAt[0] == '\''){
                kAssert( "Abnormal user function argment:"+ strAt + " at:" + strEntityAt
                        , (strAt[strAt.size()-1] == '\'') );
                strAt = strAt.substr(1, strAt.size()-2);
                cutFrontRearWhiteSpace(strAt);
                vctStrAt.push_back(strAt);
            }else{
                kAssert( "Now we dont support expression argment in user function now:2003.08", false);
                //calculate expression and make Mamory Mapped file
            }
        }   

        string strCommandAt = strFuncAt;
        for(size_t i=0; i< vctStrAt.size(); ++i){
            strCommandAt += " \"" + vctStrAt[i] + "\"";
        }
        strCommandAt += string("x"); // make ASCIIZ string
        strCommandAt[strCommandAt.size()-1] = 0;

        //bool kk::ExecuteChildProcess(const char* cpChCommandAg, int inSizeAg);
        if (ExecuteChildProcess(strCommandAt.c_str(), strCommandAt.size()) == false){
            kAssert("ExecuteChildProcess( "+strCommandAt + " ) error. There may by no executable file.", 0);
        }
#endif
    }
}


// ================= may be changed for other tield  end ========================
//bool ClTerm::m_blNumberStt = true;

void ClTerm::Initialize(void)
{ 
    m_vlrDb.resize(0);
    m_vlrCplxDb.resize(0);
    delete m_pTcSfMtrxDb;
    m_pTcSfMtrxDb = 0;

    delete m_pTcSfMtrxCplxDb;
    m_pTcSfMtrxCplxDb = 0;

    m_inStart = 0;
    m_inSize = 0;
    m_inStride = 0;

    m_blCmplx = false;
    delete m_pTcSfMtrxInvs;
    m_pTcSfMtrxInvs = 0;
    delete m_pTcSfMtrxInvsCplx;
    m_pTcSfMtrxInvsCplx = 0;
}

#if 0
//03.04.04 �s��A�x�N�g���̉��Z�̎����͂܂��s�\��

std::valarray<double> operator *( const TcSfMtrx<double> crTcMtrxAg, const std::valarray<double>& crVlrAg)
{
    kAssert("m_inColumn <= 0 at matrix*vector operation.", crTcMtrxAg.m_inColumn > 0);
    kAssert("m_inRow != vector size at matrix*vector.", crTcMtrxAg.m_inRow == crVlrAg.size() );
    std::valarray<double> vlrAt( 0, crTcMtrxAg.m_inColumn);

    for (size_t i=0; i< crTcMtrxAg.m_inColumn;i++ ){
        for (size_t j=0; j<crTcMtrxAg.m_inRow; j++){
            vlrAt[i] += m_rVlrT[i*m_inRow + j] * crVlrAg[j];
        }
    }       
    return vlrAt;
}

TcSfMtrx<double> operator *( const TcSfMtrx<double> crTcMtrxAg, double& dbAg)
{
    TcSfMtrx<double> mtrxAt(crTcMtrxAg);

    for (size_t i=0; i< crTcMtrxAg.m_inColumn;i++ ){
        for (size_t j=0; j<crTcMtrxAg.m_inRow; j++){
            mtrxAt[i] += crTcMtrxAg[i*m_inRow + j] * dbAg;
        }
    }       
    return mtrxAt;
}

TcSfMtrx<double> operator *(double& dbAg,  const TcSfMtrx<double> crTcMtrxAg)
{
    TcSfMtrx<double> mtrxAt(crTcMtrxAg);

    for (size_t i=0; i< crTcMtrxAg.m_inColumn;i++ ){
        for (size_t j=0; j<crTcMtrxAg.m_inRow; j++){
            mtrxAt[i] += crTcMtrxAg[i*m_inRow + j] * dbAg;
        }
    }       
    return mtrxAt;
}

#endif

static ksci findIfStPaired(ksci ksciFirstAg, ksci ksciLastAg, StPairOld& rStParedAg)
{
    ksci cStrItrRightParenticAt = ksciFirstAg;
    while(cStrItrRightParenticAt != ksciLastAg ){
        if ( rStParedAg(getChar(cStrItrRightParenticAt) )
        ){
            break;
        }
        cStrItrRightParenticAt = incrementKsci(cStrItrRightParenticAt);
    }
    return cStrItrRightParenticAt;
}

#define DfSjisString_
static size_t incrementSzt(const string& crStrAg, size_t sztStrAg)
{
#ifdef DfSjisString_
    // Shift JIs
    // 
    ku char byAt = crStrAg[sztStrAg];   // �����g�������Ȃ�����
    if(  (( 0x81 <= byAt) && ( byAt <= 0x9f) )
       ||(( 0xe0 <= byAt) && ( byAt <= 0xef) )
    ){
        sztStrAg += 2;
    }else{
        sztStrAg++;
    }
    return sztStrAg;
#else
    return ++sztStrAg;
#endif

}

static size_t findSztStPaired(const string& crStrAg, size_t sztFirstAg, size_t sztLastAg, StPairOld& rStParedAg )
{
    size_t sztStrItrRightParenticAt = sztFirstAg;
    while( (sztStrItrRightParenticAt < sztLastAg)
//        && (sztStrItrRightParenticAt < crStrAg.size() ) //�O�̓��ꂷ���Ǝv���A�~�߂�
     ){
        if ( rStParedAg( crStrAg[sztStrItrRightParenticAt] )
        ){
            return sztStrItrRightParenticAt;
        }
        sztStrItrRightParenticAt = incrementSzt(crStrAg, sztStrItrRightParenticAt);
    }
    return string::npos;
}

const char* cpChWhiteSpaceStt = " \t\n";

static void cutFrontRearWhiteSpace( string& rStrAg)
{
    if ( rStrAg.size() == 0){
        return;
    }
    size_t sztFrontAt = rStrAg.find_first_not_of(cpChWhiteSpaceStt);
    size_t sztRearAt = rStrAg.find_last_not_of(cpChWhiteSpaceStt);
    
    if ( sztFrontAt == string::npos ){
        rStrAg = "";
    }else{
        rStrAg = rStrAg.substr(sztFrontAt, sztRearAt+1 - sztFrontAt);
        //rStrAg = rStrAg.substr(sztFrontAt, sztRearAt+1);
    }
}


static const string cStrLeftBracketStt = "{[(<";
static const string cStrRightBracketStt = "}])>";

static int convertBinStr2Int(const string& crStrAg)
{
    //crStrAg[0]= '0', crStrAg[1] = 'b' �ł��邱�Ƃ͌Ăяo�������m�F����
    //1,0,H,L,h,l,_ �ȊO�̕������܂܂�Ă�����A������ int �ւ̕ϊ��𒆎~����
    int inAt=0;
    for ( ku int inPosAt = 2; inPosAt < crStrAg.size(); inPosAt++){
        if ( crStrAg[inPosAt] == '_' ){
            continue;
        }
        
        if (  (crStrAg[inPosAt] == '1')
                 || (crStrAg[inPosAt] == 'H')
                 || (crStrAg[inPosAt] == 'h')
        ){
            inAt <<= 1;
            inAt |= 1;
        }else if (  (crStrAg[inPosAt] == '0')
                 || (crStrAg[inPosAt] == 'L')
                 || (crStrAg[inPosAt] == 'l')
        ){
            inAt <<= 1;
            continue;
        }else{
            break;
        }
    }
    return inAt;
}


bool doesTakePriority(const string& crStrLeftOprtrAg, const string& crStrRightOprtrAg)
{
    if ( crStrLeftOprtrAg == crStrRightOprtrAg){
        return false;
    }else{
        for( int i=0; stArPchPriorityStt[i].m_pChLeft != 0; i++){
            if ( (crStrLeftOprtrAg == string(stArPchPriorityStt[i].m_pChLeft) )
              && (crStrRightOprtrAg == string(stArPchPriorityStt[i].m_pChRight) ) 
            ){
                return true;
            }else{
                continue;
            }
        }
        return false;
    }
}

//static void getSubarrayByeSquareBr(const string& crStrSqInner, ClTerm& rClTermAg)
static void getSubarrayByeSquareBr(const string& strSquareBrAg, const string& strNameAg, ClTerm& rClTermAg)
{
    ClTerm clTermVectorAt;
    if ( strSquareBrAg[0] == '<'){
        getVectorVal( strSquareBrAg.substr(1,strSquareBrAg.size()-2), kr clTermVectorAt );
        kAssert( strSquareBrAg + " must be real integer vector.",  clTermVectorAt.m_blCmplx == false);
        kAssert("[<...>] is not slice array.", clTermVectorAt.m_vlrDb.size() == 3);
         clTermVectorAt.m_inStart = static_cast<int>(clTermVectorAt.m_vlrDb[0]);
        clTermVectorAt.m_inSize = static_cast<int>(clTermVectorAt.m_vlrDb[1]);
        clTermVectorAt.m_inStride = static_cast<int>(clTermVectorAt.m_vlrDb[2]);
        kAssert("Vector or Matrix [<n,m,l>]:"+ strSquareBrAg + " is abnormal."
                , (clTermVectorAt.m_inStart >= 0)
               && (clTermVectorAt.m_inSize > 0)
               && ( (clTermVectorAt.m_inStride != 0)
                 || (clTermVectorAt.m_inSize == 1)
                  )
        );
    }else if ( strSquareBrAg.find(',') != string::npos){
        //Variable muast be mat[strLeft, strRigh]
        //istringstream istrmAt(strSquareBrAg);
        string strLeftAt, strRightAt, strOtherAt;
        ClTerm clTermLeftAt;
        clTermLeftAt.Initialize();
        ClTerm clTermRightAt;
        clTermRightAt.Initialize();
        
        //getline(kr istrmAt,kr strLeftAt, ',');
        //getline(kr istrmAt,kr strRightAt, ',');
        //getline(kr istrmAt,kr strOtherAt);
        //cutFrontRearWhiteSpace(kr strLeftAt);
        //cutFrontRearWhiteSpace(kr strRightAt);
        string strArgAt = strSquareBrAg;
        strLeftAt = getCommand(kr strArgAt);
        strRightAt = getCommand(kr strArgAt);
        strOtherAt = getCommand(kr strArgAt);
        kAssert("Abnormal matrix variable index forrmat:"+strSquareBrAg
                , (strOtherAt.size() == 0)
                ||(strLeftAt.size() != 0)
                ||(strRightAt.size() != 0)
        );
        kAssert("Variable is not matrix:"+strNameAg
                , (rClTermAg.m_pTcSfMtrxDb != 0) || (rClTermAg.m_pTcSfMtrxCplxDb!=0) );
         size_t sztRowAt, sztColumnAt;
        if (rClTermAg.m_pTcSfMtrxDb != 0){
            sztRowAt = rClTermAg.m_pTcSfMtrxDb->m_sztRow;
            sztColumnAt = rClTermAg.m_pTcSfMtrxDb->m_sztColumn;
        }else{
            sztRowAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztRow;
            sztColumnAt = rClTermAg.m_pTcSfMtrxCplxDb->m_sztColumn;
        }
         if ( strLeftAt != "*"){
            GetRightSideVal(strLeftAt, kr clTermLeftAt);
            kAssert("Matrix:"+ strNameAg + " has wrong left side index:"+strLeftAt
                    , (clTermLeftAt.m_vlrDb.size() == 1)
                    &&(clTermLeftAt.m_vlrDb[0] >= 0)
                    &&(clTermLeftAt.m_vlrDb[0] < sztColumnAt)
            );
        }
        if ( strRightAt != "*"){
            GetRightSideVal( strRightAt, kr clTermRightAt);
            kAssert("Matrix:"+ strNameAg + " has wrong left side index:"+strRightAt
                    , (clTermRightAt.m_vlrDb.size() == 1)
                    &&(clTermRightAt.m_vlrDb[0] >= 0)
                    &&(clTermRightAt.m_vlrDb[0] < sztRowAt)
            );
        }
         if ( (strLeftAt == "*") && (strRightAt == "*") ){
            // Matrix[*,*]
            clTermVectorAt.m_inStart = 0;
            clTermVectorAt.m_inSize = sztRowAt;
            clTermVectorAt.m_inStride = sztRowAt+1;
        }else{
            if ( strLeftAt == "*"){
                // Matrix[*,n]
                clTermVectorAt.m_inStart = static_cast<size_t>(clTermRightAt.m_vlrDb[0]);
                clTermVectorAt.m_inSize = sztColumnAt;
                clTermVectorAt.m_inStride = sztRowAt;
            }else if ( strRightAt == "*"){
                // Matrix[n,*]
                clTermVectorAt.m_inStart = static_cast<size_t>(clTermLeftAt.m_vlrDb[0])*sztRowAt;
                clTermVectorAt.m_inSize = sztRowAt;
                clTermVectorAt.m_inStride = 1;
            }else{
                // Matrix[m,n]
                clTermVectorAt.m_inStart = static_cast<size_t>(clTermLeftAt.m_vlrDb[0]) * sztRowAt
                         + static_cast<size_t>(clTermRightAt.m_vlrDb[0]);
                clTermVectorAt.m_inSize = 1;
                clTermVectorAt.m_inStride = 1;
            }
        }
    }else{
        //vector[n]
        kAssert( strNameAg + " is not vector."
                , (clTermVectorAt.m_pTcSfMtrxDb == 0)
               && (clTermVectorAt.m_pTcSfMtrxCplxDb == 0)
        );
         GetRightSideVal(strSquareBrAg, kr clTermVectorAt);
        kAssert(strNameAg + "[strSquareBrAg] needs real number parameter:"
                + strSquareBrAg, (clTermVectorAt.m_blCmplx == false)  && (clTermVectorAt.m_vlrDb.size() == 1) );
        size_t sztAt = static_cast<size_t>(clTermVectorAt.m_vlrDb[0]);
         clTermVectorAt.m_inStart = sztAt;
        clTermVectorAt.m_inSize = 1;
        clTermVectorAt.m_inStride = 1;
    }

    if ( rClTermAg.m_blCmplx == true ){
        kAssert( rClTermAg.m_strVarName+ " index goes beyond the valarray size."
            , static_cast<int>(rClTermAg.m_vlrCplxDb.size() )
            > (clTermVectorAt.m_inStart + (clTermVectorAt.m_inSize-1) * clTermVectorAt.m_inStride)
        );
         valarray<complex<double> > vlrCplxAt(rClTermAg.m_vlrCplxDb);
        rClTermAg.m_vlrCplxDb.resize( clTermVectorAt.m_inSize );
        rClTermAg.m_vlrCplxDb = valarray<complex<double> > (
                    vlrCplxAt[slice( 
                                     clTermVectorAt.m_inStart
                                    ,clTermVectorAt.m_inSize
                                    ,clTermVectorAt.m_inStride
                              )
                    ]
        );
    }else{
        kAssert( rClTermAg.m_strVarName+ " index goes beyond the valarray size."
            , static_cast<int>(rClTermAg.m_vlrDb.size() )
            > (clTermVectorAt.m_inStart + (clTermVectorAt.m_inSize-1) * clTermVectorAt.m_inStride)
        );
        valarray<double> vlrAt(rClTermAg.m_vlrDb);
        rClTermAg.m_vlrDb.resize( clTermVectorAt.m_inSize );
        rClTermAg.m_vlrDb = valarray<double>(
                    vlrAt[slice( 
                                     clTermVectorAt.m_inStart
                                    ,clTermVectorAt.m_inSize
                                    ,clTermVectorAt.m_inStride
                              )
                    ]
        );
    }

    delete rClTermAg.m_pTcSfMtrxCplxDb;
    rClTermAg.m_pTcSfMtrxCplxDb = 0;
    delete rClTermAg.m_pTcSfMtrxInvsCplx;
    rClTermAg.m_pTcSfMtrxInvsCplx = 0;
    delete rClTermAg.m_pTcSfMtrxDb;
    rClTermAg.m_pTcSfMtrxDb = 0;
    delete rClTermAg.m_pTcSfMtrxInvs;
    rClTermAg.m_pTcSfMtrxInvs = 0;
    rClTermAg.m_inStart = 0;
    rClTermAg.m_inSize = 0;
    rClTermAg.m_inStride = 0;
}

static void detectVariableTerm(string& rStrResidualAg, ClTerm& rClTermAg)
{
    kAssert( "We detect size 0 term string.", rStrResidualAg.size() > 0);

    static krgstr krgVariableTermStt("^([��-����-��A-Za-z_][A-Za-z_0-9]*[_'``]*)({[^{}]+})?(`..*)?(`[)?");
    string strSquareBrAt;
    string strCurlyBrAt;

    rStrResidualAg/krgVariableTermStt;
    string strFileNameAt = krgVariableTermStt % 1;  // first name

    string strKrg4IndexAt = krgVariableTermStt % 4;   //index string
    string strKrg3ScndAt = krgVariableTermStt % 3;
    size_t sztKrgAt = krgVariableTermStt.size();

    if (krgVariableTermStt.size() == 0){
        kAssert("We can't find variable term in rStrResidualAg:" + rStrResidualAg + " at detectVariableTerm(.):", 0);
    }else{
        string strAt = krgVariableTermStt % 2;
        if ( strAt != ""){
            // variableName{...}
            kAssert("Internal error", (strAt[0] == '{') && strAt[strAt.size()-1] == '}');
            strAt = "<"+strAt.substr(1,strAt.size()-2 )+">";
            ClTerm clTermAt;
            GetRightSideVal(strAt, kr clTermAt);
            kAssert("Abnormal Curly Brace variable:" + krgVariableTermStt
                    , (clTermAt.m_vlrDb.size() > 0)
                   && (clTermAt.m_pTcSfMtrxDb == 0) );
            
            
            ostringstream ostrmAt;
            for (size_t i=0; i< clTermAt.m_vlrDb.size(); ++i){
                int inIndexAt = static_cast<int>(clTermAt.m_vlrDb[i]);
                ostrmAt << "," << inIndexAt;
            }
            strCurlyBrAt = ostrmAt.str();
            strCurlyBrAt = strCurlyBrAt.substr(1);  // delete first ',' character
            strFileNameAt += "{"+strCurlyBrAt+"}";
        }

        if ( strKrg4IndexAt == ""){
            rStrResidualAg = rStrResidualAg.substr(sztKrgAt);
        }else{
            //This variable has square bracket. We must detect corresponding ']'
            size_t sztSquareBrAt = rStrResidualAg.find('[');
            StPairOld stPairedAt( '[', ']');
            size_t sztRightAt
                    = findSztStPaired(rStrResidualAg, sztSquareBrAt, rStrResidualAg.size() , kr stPairedAt );
            kAssert("For '[', we can't detect ']' at ." +rStrResidualAg, sztRightAt != string::npos); 
            strSquareBrAt = rStrResidualAg.substr(sztSquareBrAt+1,sztRightAt - sztSquareBrAt - 1);
            cutFrontRearWhiteSpace(kr strSquareBrAt );
            rStrResidualAg = rStrResidualAg.substr(sztRightAt+1);
        }
        cutFrontRearWhiteSpace(kr rStrResidualAg);
    }

    ClTerm* pClTermAt;
    if ( (pClTermAt = ClTmpVar::GetTmpVarStt(strFileNameAt)) != 0 ){
        rClTermAg = *pClTermAt;
    }else{
        if ( strKrg3ScndAt == ""){
            strFileNameAt += ".val";
        }else{
            strFileNameAt += strKrg3ScndAt; //secondary name
        }

        rClTermAg.ConvertFileToValue(strFileNameAt);
        rClTermAg.m_strVarName = strFileNameAt;
    }

    if ( strSquareBrAt.size() != 0){
         getSubarrayByeSquareBr(strSquareBrAt, strFileNameAt, kr rClTermAg);
    }
}

void getBinaryOperator(string& rStrResidualAg, string& rStrOprtnAg)
{
    if ( rStrResidualAg.size() == 0){
        rStrOprtnAg = "";
        return;
    }else if ( rStrResidualAg[0] == '!'){
        rStrOprtnAg = "NoOperator";
        
        //03.05.04 �C��  >sf "2 3 !cos(��/7 - ��/8)"  kAseert �΍�
        // strResidualAt begins with !: extneding operator
        //kAssert(" ! operator is not implemented.", 0);   // for sg, sn
    }else if ( strBinaryOperatorStt.find(rStrResidualAg[0]) !=  string::npos){
        rStrOprtnAg = string(1, rStrResidualAg[0]); // one character operator
        rStrResidualAg = rStrResidualAg.substr(1);
        cutFrontRearWhiteSpace(kr rStrResidualAg);
    }else{
        rStrOprtnAg = "NoOperator";
    }
}


static void getUntilBar(string& rStrSourceAg, string& rStrDestAg)
{
    cutFrontRearWhiteSpace(kr rStrSourceAg);
    if ( rStrSourceAg.size() == 0){
        rStrDestAg = "";
        return;
    }

    size_t sztRighttBracketAt = 0;


    for(;;){
        size_t sztLeftBracketAt = rStrSourceAg.find_first_of(cStrLeftBracketStt, sztRighttBracketAt);
        size_t sztBarAt = rStrSourceAg.find_first_of('|',sztRighttBracketAt);

        if ( sztBarAt == string::npos){
            rStrDestAg = rStrSourceAg;
            rStrSourceAg = "";
            return;
        }

        if ( sztBarAt < sztLeftBracketAt ){
            rStrDestAg = rStrSourceAg.substr(0,sztBarAt);
            rStrSourceAg = rStrSourceAg.substr(sztBarAt+1);
            cutFrontRearWhiteSpace(kr rStrDestAg);
            cutFrontRearWhiteSpace(kr rStrSourceAg);
            return;
        }else{
            StPairOld stPairedAt( rStrSourceAg[sztLeftBracketAt]
                    ,cStrRightBracketStt[ cStrLeftBracketStt.find(rStrSourceAg[sztLeftBracketAt]) ] );
            sztRighttBracketAt = findSztStPaired(rStrSourceAg, sztLeftBracketAt, rStrSourceAg.size(), kr stPairedAt );
        }
    }
}
//! calculateInnerProduct(.) dosen't support recursive calculateInnerProduct(.) call
//! crStrAg == "vector | vector" or"vector | Matrix | vector. Both side '<' and '>' are ommiteed.
static void calculateInnerProduct( const string& crStrAg, ClTerm& rClTermAg )
{
    string strLeftAt;
    ClTerm clLeftAt;

    string strRightMiddleAt;
    ClTerm clRightMiddleAt;

    string strRightMiddleRightAt;
    ClTerm clRightMiddleRightAt;

#if 1
    string strArgAt(crStrAg);
    getUntilBar(kr strArgAt, kr strLeftAt);
    getUntilBar(kr strArgAt, kr strRightMiddleAt);      // <a|b> �̂Ƃ��� "b" �� <a|M|b> �̂Ƃ��� "M" ���ݒ肳���
    getUntilBar(kr strArgAt, kr strRightMiddleRightAt); // <a|b> �̂Ƃ��� ""  �� <a|M|b> �̂Ƃ��� "b" ���ݒ肳���
#else
    std::istringstream istrmAt(crStrAg);
    getline(kr istrmAt,kr strLeftAt, '|');
    cutFrontRearWhiteSpace(kr strLeftAt);
    getline(kr istrmAt,kr strRightMiddleAt, '|');
    cutFrontRearWhiteSpace(kr strRightMiddleAt);
    getline(kr istrmAt,kr strRightMiddleRightAt, '\n');
    cutFrontRearWhiteSpace(kr strRightMiddleRightAt);
#endif

    GetRightSideVal( strLeftAt, kr clLeftAt);
    GetRightSideVal( strRightMiddleAt, kr clRightMiddleAt);
    if ( strRightMiddleRightAt.size() != 0){
        GetRightSideVal( strRightMiddleRightAt, kr clRightMiddleRightAt);
        clRightMiddleAt.CalculateFourOperations("*", clRightMiddleRightAt);
    }

    makeCmplxRealSame( kr clLeftAt, kr clRightMiddleAt);
    kAssert("<.|...> vector operation requests both sizes are same."
            , (clLeftAt.m_vlrDb.size() == clRightMiddleAt.m_vlrDb.size() )
            &&(clLeftAt.m_vlrCplxDb.size() == clRightMiddleAt.m_vlrCplxDb.size() )
    );
    if ( clLeftAt.m_blCmplx == true ){
        rClTermAg.Initialize();
        rClTermAg.m_blCmplx = true;
        rClTermAg.m_vlrCplxDb.resize(1);
        rClTermAg.m_vlrCplxDb[0] = complex<double>(0);
        for (size_t i=0; i<clLeftAt.m_vlrCplxDb.size(); ++i){
            rClTermAg.m_vlrCplxDb[0]
                += conj(clLeftAt.m_vlrCplxDb[i]) * clRightMiddleAt.m_vlrCplxDb[i];
        }
    }else{
        rClTermAg.Initialize();
        rClTermAg.m_vlrDb.resize(1);
        rClTermAg.m_vlrDb[0] = 0;
        for (size_t i=0; i<clLeftAt.m_vlrDb.size(); ++i){
            rClTermAg.m_vlrDb[0]
                += clLeftAt.m_vlrDb[i] * clRightMiddleAt.m_vlrDb[i];
        }
    }
}


static void loopCommand(const string& crStrAg, ClTerm& rClTermResultAg);

/* <<....>> ������ parse
 *<< <...>pair >> �Ȃ�� <...> pair �� vector �ł���B�������̂́Areal �� size()==1, or 3
 *<< <..>pair, ... >> �� <..> pair �̌�� ',' �܂��� '@' ����������Ȃ�
 *<...>@ �Ƒ����Ă��邱�Ƃ��O��̃R�[�h�ɂȂ��Ă���
 *
 *<-- <..> ��΂��� @ ��T��
 *    @ �܂ł̕�������x�N�^�ɕϊ�����
 *    <-- @ �܂ł̕�����ɑ΂��āA<..> ��΂� ',' ��T���Č�����΁A�ŏ��ƍŌ�� '<', '>' ������
 *        vector �����߂�����
 *    <-- @ �܂ł̕�����ɑ΂��āA<..> ��΂� ',' ��T���Č�����Ȃ���΁A�₤���ƂȂ���
 *        vector �����߂�����
 *
 *    @ ���Ȃ��Ƃ��A���߂��x�N�^�� size()==1 or size() == 3 �łȂ���΂Ȃ�Ȃ�
 *    <-- size() == 1 �̂Ƃ� 0 entity vector 
 *    <-- size() == 3 �̂Ƃ��� start/size/stride vector
 *    <-- ���̂ق��� Unexpected
 *    @ ������Ƃ��́A�x�N�^�ł��肳������΋������
 *    <-- strTEmpVarAt, strTempIndeAt, strExpressionAt �ɕ�������
 *
 *���炵���p�^�[��
 *"< <1,2,3,4>| <0,4,1,3> >"  or  "<<1,2,3,4>| <0,4,1,3>>" 
 *"<<<3>>|<1,2,3>>" <-- ���ς�����Ɏ���
 *"< <<1,2>|<2,3>>, 4,5>" �����肤��
 *<a|b> �ϐ�������
 *"<< < <1,2> | <2,3> > >>" �����肤��
 *"<< <<1,2>|<2,3>> >>", "< < <1,2> | <2,3> >,3,4 >", "<<<<1,2>|<2,3>>>>" �����肤��
 *"< 8,< <3,4>|<2,1> >, 5,4>"
 *"a @= 3,< a,< <1,2> | <3,4> > >"
 */

// rStrEntityAg is a inner string of "<< rStrEintityAg >>"
static int inLoopNestCountStt = 0;
static void getDualLtVector(const string& crStrEntityAg, ClTerm& rClResultAg)
{
    

    ClTerm clLoopTermAt;
    clLoopTermAt.Initialize();

    string strExpressionAt("");
    string strTempVarAt("");
    string strTempIndexAt("_n");
    size_t sztLengthAt;
    

    //crStrEntityAg ���� <..>pair ��΂��� '@' ��T��
    size_t sztAtMarkAt;
    size_t sztBracketAt=0;
    do{
        sztAtMarkAt = crStrEntityAg.find('@', sztBracketAt);
        sztBracketAt = crStrEntityAg.find_first_of(cStrLeftBracketStt,sztBracketAt);
        if ( sztBracketAt > sztAtMarkAt){
            break;
        }
        char chLeftBracketAt = crStrEntityAg[sztBracketAt];
        StPairOld stPairedAt( chLeftBracketAt
                ,cStrRightBracketStt[ cStrLeftBracketStt.find(chLeftBracketAt) ] );
        sztBracketAt = findSztStPaired(crStrEntityAg, sztBracketAt, crStrEntityAg.size() , kr stPairedAt );
    }while ( sztAtMarkAt != string::npos);

    string strVectorAt = crStrEntityAg.substr(0, sztAtMarkAt);
    //strVectorAt ���� <..>pair ��΂��� ',' ��T��
    size_t sztCommaAt=0;
    sztBracketAt = 0;
    do{
        sztCommaAt = strVectorAt.find(',', sztBracketAt);
        sztBracketAt = strVectorAt.find_first_of(cStrLeftBracketStt,sztBracketAt);
        if ( sztBracketAt > sztCommaAt){
            break;
        }
        char chLeftBracketAt = strVectorAt[sztBracketAt];
        StPairOld stPairedAt( chLeftBracketAt
                ,cStrRightBracketStt[ cStrLeftBracketStt.find(chLeftBracketAt) ] );
        sztBracketAt = findSztStPaired(strVectorAt, sztBracketAt, strVectorAt.size() , kr stPairedAt );
    }while ( sztCommaAt != string::npos);

    if ( sztCommaAt != string::npos ){
        strVectorAt = "<" + strVectorAt + ">";
    }
    ClTerm clVectorAt;
    GetRightSideVal(strVectorAt, kr clVectorAt);

    if ( (sztCommaAt != string::npos )
      || (  (sztAtMarkAt == string::npos )
          &&(  (clVectorAt.m_vlrDb.size()==1) || (clVectorAt.m_vlrCplxDb.size() == 1) )
         )
      || (  (sztAtMarkAt == string::npos )
          &&(  (clVectorAt.m_vlrDb.size()==3) || (clVectorAt.m_vlrCplxDb.size() == 3) )
         )
    ){
        //make loop parameter or vecitor size parameter
        clLoopTermAt.Initialize();
        if (clVectorAt.m_blCmplx == true ){
            kAssert("Inner of <<...>> is Matrix:"+ crStrEntityAg, clVectorAt.m_pTcSfMtrxCplxDb == 0);
            complex<double> cplxDbStartAt(0);
            complex<double> cplxDbStrideAt(0);
            size_t sztSizeAt = 0;
            if ( clVectorAt.m_vlrCplxDb.size() == 3){
                cplxDbStartAt = clVectorAt.m_vlrCplxDb[0];
                sztSizeAt = static_cast<size_t>(clVectorAt.m_vlrCplxDb[1].real() );
                cplxDbStrideAt = clVectorAt.m_vlrCplxDb[2];
            }else if ( clVectorAt.m_vlrCplxDb.size() == 1){
                kAssert("sf detect <<Complex 1 parameter>>::<<"+ crStrEntityAg+">>",false);
            
            }else{
                kAssert("Inner vector of <<...>> is  not size 1 or 3:start/size/stride::<<"+ crStrEntityAg+">>"
                        , false);
            }
            kAssert("Inner vector of <<...>> is size is less than 1:"+ crStrEntityAg
                        , sztSizeAt >= 1);
            clLoopTermAt.m_blCmplx = true;
            clLoopTermAt.m_vlrCplxDb.resize(sztSizeAt);
            clLoopTermAt.m_vlrCplxDb[0] = cplxDbStartAt;
            for (size_t i=1; i< sztSizeAt; ++i){
                clLoopTermAt.m_vlrCplxDb[i] = clLoopTermAt.m_vlrCplxDb[i-1]+cplxDbStrideAt;
            }
        }else{
            kAssert("Inner of <<...>> is Matrix."+ crStrEntityAg, clVectorAt.m_pTcSfMtrxDb == 0);
            double dbStartAt(0);
            double dbStrideAt(0);
            size_t sztSizeAt = 0;
            if ( clVectorAt.m_vlrDb.size() == 3){
                dbStartAt = clVectorAt.m_vlrDb[0];
                sztSizeAt = static_cast<size_t>(clVectorAt.m_vlrDb[1]);
                dbStrideAt = clVectorAt.m_vlrDb[2];
            }else if ( clVectorAt.m_vlrDb.size() == 1){
                sztSizeAt = static_cast<size_t>(clVectorAt.m_vlrDb[0]);
            }else{
                kAssert("Inner vector of <<...>> is  not size 1 or 3:start/size/stride::<<"+ crStrEntityAg+">>"
                        , false);
            }
            kAssert("Inner vector of <<...>> is size is less than 1:"+ crStrEntityAg
                        , sztSizeAt >= 1);
            clLoopTermAt.m_vlrDb.resize(sztSizeAt);
            clLoopTermAt.m_vlrDb[0] = dbStartAt;
            for (size_t i=1; i< sztSizeAt; ++i){
                clLoopTermAt.m_vlrDb[i] = clLoopTermAt.m_vlrDb[i-1]+dbStrideAt;
            }
        }
    }else{
        clLoopTermAt = clVectorAt;
    }

    if ( sztAtMarkAt == string::npos ){
        // crStrEntityAg is simple <<size>> or <<start, size, stride>>
        rClResultAg = clLoopTermAt;
        return;
    }

    // now << ... @tempVar[,indexVar|expression ...> 
    kAssert("Inner of <<...>> is empty"+ strVectorAt
            , (clLoopTermAt.m_vlrCplxDb.size() >= 1) || (clLoopTermAt.m_vlrDb.size() >=1) );

    if ( clLoopTermAt.m_blCmplx == true ){
        sztLengthAt = clLoopTermAt.m_vlrCplxDb.size();
    }else{
        sztLengthAt = clLoopTermAt.m_vlrDb.size();
    }

    size_t sztBarAt = crStrEntityAg.find('|', sztAtMarkAt);
    kAssert("We can't detect '|' at <<....@..|....>>:"+crStrEntityAg
            , sztBarAt != string::npos);
    istringstream istrmAt( crStrEntityAg.substr(sztAtMarkAt+1, sztBarAt - sztAtMarkAt -1) );
    getline(kr istrmAt, kr strTempVarAt, ',');
    if ( !istrmAt.eof() ){
        getline(kr istrmAt, kr strTempIndexAt, ',');
    }
    cutFrontRearWhiteSpace(kr strTempVarAt);
    cutFrontRearWhiteSpace(kr strTempIndexAt);

    strExpressionAt = crStrEntityAg.substr(++sztBarAt);

    // 07.04.09 separate the last value expressions string from expressions
    size_t sztAtCommaAt = strExpressionAt.find("|,");
    string strExpreesionBackAt("");
    if ( sztAtCommaAt != string::npos ){
        strExpreesionBackAt = strExpressionAt.substr(sztAtCommaAt+2);
        strExpressionAt = strExpressionAt.substr(0,sztAtCommaAt);
        cutFrontRearWhiteSpace(kr strExpreesionBackAt);
    }
    cutFrontRearWhiteSpace(kr strExpressionAt);

    kAssert("At dual less than bracket, there is no expression string:" + crStrEntityAg
        , (strExpressionAt != "" ) || (strExpreesionBackAt != "" )
    );


    // << start, size, stride @ temporaryVar | expression >>
    // << vector @ temporaryVar | expression >>
    rClResultAg.Initialize();
    rClResultAg.m_vlrDb.resize(sztLengthAt);

    ClTmpVar clTemporaryAt;
    ClTmpVar::RegistStt(strTempVarAt);
    ClTmpVar::RegistStt(strTempIndexAt);

    ++inLoopNestCountStt;
    for (size_t i=0; i< sztLengthAt; ++i){
        if ( clLoopTermAt.m_blCmplx == true ){
            ClTmpVar::GetTmpVarStt(strTempVarAt)->m_blCmplx = true;
            ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrCplxDb.resize(1);
            ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrCplxDb[0] = clLoopTermAt.m_vlrCplxDb[i];
        }else{
            ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrDb.resize(1);
            ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrDb[0] = clLoopTermAt.m_vlrDb[i];
        }
        ClTmpVar::GetTmpVarStt(strTempIndexAt)->m_vlrDb.resize(1);
        ClTmpVar::GetTmpVarStt(strTempIndexAt)->m_vlrDb[0] = i;


        {
            ClTerm clTmExprssnAt;
            //GetRightSideVal( strExpressionAt, kr clTmExprssnAt);
            ClTmpVar clTmpVarAt;
            {for(int i=0; i<inLoopNestCountStt; ++i){
                cout << "    ";
            }}
            if ( ClTerm::IsAbleToPrintStt() == true){
                cout << "loop count:" << strTempIndexAt << "  " << dec << i;
            }else{
                cout << "loop count:" << strTempIndexAt << "  " << dec << i <<endl;
            }


            loopCommand( strExpressionAt, kr clTmExprssnAt);

            //03.11.10 <<..@temp|multipelExpression>> �Ɋg���������߁A scalar �̒l�ɂȂ�Ƃ͌���Ȃ��Ȃ���
            //�̂ŁA���� kAssert ���R�����g�E�A�E�g����
            //kAssert("<<..@expression>>:"+strExpressionAt+" must be scalar value."
            //    , (clTmExprssnAt.m_vlrDb.size()+ clTmExprssnAt.m_vlrCplxDb.size() == 1)
            //);
            if (clTmExprssnAt.m_blCmplx == true){
                if (rClResultAg.m_blCmplx == false ){
                    // change from real to complex
                    convertRealToComplex(kr rClResultAg);
                }
                rClResultAg.m_vlrCplxDb[i] = clTmExprssnAt.m_vlrCplxDb[clTmExprssnAt.m_vlrCplxDb.size()-1];
            }else{
                if (rClResultAg.m_blCmplx == true){
                    rClResultAg.m_vlrCplxDb[i] = complex<double>(clTmExprssnAt.m_vlrDb[clTmExprssnAt.m_vlrDb.size()-1],0);
                }else{
                    rClResultAg.m_vlrDb[i] = clTmExprssnAt.m_vlrDb[clTmExprssnAt.m_vlrDb.size()-1];
                    //cout <<"debug:clTmExprssnAt.m_vlrDb[0]:" << clTmExprssnAt.m_vlrDb[clTmExprssnAt.m_vlrDb.size()-1] << endl;
                }
            }
            if ( clLoopTermAt.m_blCmplx == true ){
                ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrCplxDb[0] = clLoopTermAt.m_vlrCplxDb[i];
            }else{
                ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrDb[0] = clLoopTermAt.m_vlrDb[i];
            }

            if ( strExpreesionBackAt != "" ){
                // execute after "|," expressions
                loopCommand( strExpreesionBackAt, kr clTmExprssnAt);
            }
            
            // set next vector value for @ temporaryVar
            if ( clLoopTermAt.m_blCmplx == true ){
                ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrCplxDb[0] = clLoopTermAt.m_vlrCplxDb[i];
            }else{
                ClTmpVar::GetTmpVarStt(strTempVarAt)->m_vlrDb[0] = clLoopTermAt.m_vlrDb[i];
            }
        }
    }
    --inLoopNestCountStt;
}


//! �s���� -(..) �� +[[3]], @sub(-<<4>>) �Ȃǂ̂悤�� - �t���̊���
//! line head is - + bracket as -(..)
static void getBracketInnerTerm(string& rStrResidualAg, ClTerm& rClResultAg)
{

    StPairOld stPairedAt( rStrResidualAg[0],cStrRightBracketStt[ cStrLeftBracketStt.find(rStrResidualAg[0]) ] );
    //StPairOld stPairedAt( '(',')');
    
    size_t sztRightAt = findSztStPaired(rStrResidualAg, 0, rStrResidualAg.size() , kr stPairedAt );
    kAssert("We find not paired bracket in " + rStrResidualAg, sztRightAt != string::npos);
    string strEntityAt = rStrResidualAg.substr(1,-1+sztRightAt);
    cutFrontRearWhiteSpace(kr strEntityAt);

    if ( rStrResidualAg[0] == '<'){
        if ( strEntityAt[0] == '<'){
            size_t sztEndAt=string::npos;
            StPairOld stPairedSecondAt( '<', '>');
            sztEndAt = findSztStPaired(strEntityAt, 0, strEntityAt.size() , kr stPairedSecondAt );
            kAssert("We find not paired bracket in " + strEntityAt, sztEndAt != string::npos);

            if ( sztEndAt == strEntityAt.size() -1 ){ 
                //kAssert(strEntityAt + " is not <<...>>.", strEntityAt[strEntityAt.size()-1] == '>');
                strEntityAt = string(1+strEntityAt.begin(), -1+strEntityAt.end());
                cutFrontRearWhiteSpace(kr strEntityAt);
                getDualLtVector( strEntityAt, rClResultAg);
            }else{
                // < <...> ? .... > �� ? �̈ʒu�ɂ���̂� ',' �� '|' �݂̂ł�
                // 2004.06.24 sf "< <0,1>+<0,0> | <0,1> >" ������܂��B���̂Ƃ��͓��ς����߂鑤�ɕ��ނ��܂�
                size_t sztFrontAt = strEntityAt.find_first_not_of(cpChWhiteSpaceStt,sztEndAt+1);
                kAssert("We can't parse:"+rStrResidualAg, sztFrontAt != string::npos);
                //<  <.....>|<....>  > nested inner product or < <...>,....> or nested vector
                if ( strEntityAt[sztFrontAt] == ','){
                    // for example sf "< <<1,2>|<2,3>>, 4,5>"
                    getVectorVal( strEntityAt, kr rClResultAg );
                }else{
                    calculateInnerProduct( strEntityAt, rClResultAg );
                }
            }
        }else{
            //find '|' that is outside of bracket
            string strWithBracketAt("");
            

            size_t sztBarAt;
            size_t sztBracketAt = 0;
            do{
                sztBarAt = strEntityAt.find('|', sztBracketAt);
                sztBracketAt = strEntityAt.find_first_of(cStrLeftBracketStt,sztBracketAt);
                if ( sztBracketAt > sztBarAt){
                    break;
                }
                char chLeftBracketAt = strEntityAt[sztBracketAt];
                StPairOld stPairedAt( chLeftBracketAt
                        ,cStrRightBracketStt[ cStrLeftBracketStt.find(chLeftBracketAt) ] );
                sztBracketAt = findSztStPaired(strEntityAt, sztBracketAt, strEntityAt.size() , kr stPairedAt );
            }while ( sztBarAt != string::npos);

            if ( sztBarAt != string::npos){
                calculateInnerProduct( strEntityAt, rClResultAg );
            }else{
                //kAssert(strEntityAt + " is not <...>.", (*strEntityAt.rbegin() == '>') ); <-- strEntityAt �� '<', '>' ���������̕�����
                // vector number expression
                getVectorVal( strEntityAt, kr rClResultAg );
            }
        }
    }else if ( rStrResidualAg[0] == '['){
        if ( rStrResidualAg[1] == '['){
            kAssert(strEntityAt + " is not [[...]].", (*strEntityAt.rbegin() == ']') );
            // << start, stride, size >> vector generator
            ClTerm clTermAt;
            getVectorVal( string(1+strEntityAt.begin(), -1+strEntityAt.end()), kr clTermAt );
            kAssert( "["+ strEntityAt + "] must be real vector.",  clTermAt.m_blCmplx == false);

            if ( clTermAt.m_vlrDb.size() == 2){
                int inNat = static_cast<int>(clTermAt.m_vlrDb[0]);
                int inMat = static_cast<int>(clTermAt.m_vlrDb[1]);
                kAssert( "["+ strEntityAt + "] vector size must be plus", (inNat > 0) && ( inMat > 0) );
                rClResultAg.m_vlrDb.resize(inNat*inMat, 0);
                rClResultAg.m_vlrDb = 0;
                delete rClResultAg.m_pTcSfMtrxDb;
                rClResultAg.m_pTcSfMtrxDb = new TcSfMtrx<double>(rClResultAg.m_vlrDb, inNat, inMat);
            }else if ( clTermAt.m_vlrDb.size() == 1){
                int inNat = static_cast<int>(clTermAt.m_vlrDb[0]);
                kAssert( "["+ strEntityAt + "] vector size must be plus", inNat > 0 );
                rClResultAg.m_vlrDb.resize(inNat*inNat, 0);
                rClResultAg.m_vlrDb = 0;
                delete rClResultAg.m_pTcSfMtrxDb;
                rClResultAg.m_pTcSfMtrxDb = new TcSfMtrx<double>(rClResultAg.m_vlrDb, inNat, inNat);
            }else{
                kAssert( "["+ strEntityAt + "] inner vector size is not 1 or 2.", false );
            }
        }else{
            // vector number expression
            kAssert( "Abnormal Bracket " + rStrResidualAg, 0 );
        }
    }else{
        kAssert("Abnormal Bracket" + rStrResidualAg, rStrResidualAg[0]=='(');
        GetRightSideVal( strEntityAt, kr rClResultAg);
    }

    string strBrExpressionAt = rStrResidualAg.substr(0, sztRightAt+1);
    rStrResidualAg = rStrResidualAg.substr( ++sztRightAt);
    cutFrontRearWhiteSpace(kr rStrResidualAg);
    
#if 1
    if ( (rStrResidualAg.size() > 2)
      && (rStrResidualAg[0] == '[')
//      && (rStrResidualAg[1] == '<') <-- [0,*] �Ȃǂ����肦��
    ){
        size_t sztSquareBrAt = rStrResidualAg.find('[');
        StPairOld stPairedAt( '[', ']');
        size_t sztRightAt
                    = findSztStPaired(rStrResidualAg, sztSquareBrAt, rStrResidualAg.size() , kr stPairedAt );
        kAssert("For '[', we can't detect ']' at ." +rStrResidualAg, sztRightAt != string::npos); 
        string strSquareBrAt = rStrResidualAg.substr(1,sztRightAt-1);
        cutFrontRearWhiteSpace(kr strSquareBrAt );
        rStrResidualAg = rStrResidualAg.substr(sztRightAt+1);
        cutFrontRearWhiteSpace(kr rStrResidualAg);

        getSubarrayByeSquareBr(strSquareBrAt, strBrExpressionAt, kr rClResultAg);
    }
#endif
}

static void processMathFnctn(ClTerm& rClTermAg, string& rStrResidualAg)
{
    //static krgstr krgSubroutineFunctionStt("!([A-Za-z][A-Za-z_0-9]*)`(");
    cutFrontRearWhiteSpace(kr rStrResidualAg);
    if (rStrResidualAg / krgSubroutineFunctionStt == ""){
        kAssert("Abnormal mathematical fucntion: " + rStrResidualAg, 0);
    }else{
        string strFuncAt = krgSubroutineFunctionStt % 1;
        rStrResidualAg = rStrResidualAg.substr(strFuncAt.size()+1 );
        
        StPairOld stPairedAt( '(',')');
        string::const_iterator csiRightAt;
        csiRightAt = findIfStPaired(rStrResidualAg.begin(), rStrResidualAg.end() , kr stPairedAt );
        kAssert("We can't find paired (...) at "+ rStrResidualAg + " in processMathFnctn(.)."
                , *csiRightAt == ')');
        string strEntityAt((string::const_iterator)(1+rStrResidualAg.begin()),csiRightAt);
        rStrResidualAg = string( ++csiRightAt, (string::const_iterator)rStrResidualAg.end() );

        ClTerm clSingleTermAt;
        GetRightSideVal( strEntityAt, kr clSingleTermAt);
        rClTermAg.CalculateUnitaryMathFnctn( strFuncAt, kr clSingleTermAt);
        cutFrontRearWhiteSpace(kr rStrResidualAg);
    }
}

static void processAtFileName(const string& crStrFileNameAg, ClTerm& rClTermResultAg);
static void executeAtFile( string& kr rStrResidualAg)
{
    if (rStrResidualAg / krgSubroutineFunctionStt == ""){
        kAssert("Abnormal subroutine name: @" + rStrResidualAg, 0);
    }else{
        cutFrontRearWhiteSpace(rStrResidualAg);
        string strFuncAt = krgSubroutineFunctionStt % 1;
        string strOldAgAt = rStrResidualAg;
        rStrResidualAg = rStrResidualAg.substr(strFuncAt.size() );
        
        StPairOld stPairedAt( '(',')');
        string::const_iterator csiRightAt;
        csiRightAt = findIfStPaired(rStrResidualAg.begin(), rStrResidualAg.end() , kr stPairedAt );
        string strEntityAt((string::const_iterator)(1+rStrResidualAg.begin()),csiRightAt);
        cutFrontRearWhiteSpace(strEntityAt);
        rStrResidualAg = string( ++csiRightAt, (string::const_iterator)rStrResidualAg.end() );

        //cout << "size:" << strEntityAt.size() << "  " << strEntityAt << endl; // to debug
            //kAssert("Now we support only \'....\' argment in tilda user function argment:"+strEntityAt,false);
        ClTerm clDammieAt;

        int inCountAt=0;
        while (strEntityAt.size() > 0 ){
            string strAt = getCommand(kr strEntityAt);
            cutFrontRearWhiteSpace(kr strAt);
            if ( strAt.size() == 0){
                kAssert("sf detect blank parameter at executeAtFile(.) for "+ strOldAgAt, false);
            }

            ostringstream ostrmAt;
            ++inCountAt;
            ostrmAt << inCountAt;
            string strArgAt = "_prmTemp"+ostrmAt.str();

            //cout << "debug:Mat.m_vlrDb:" << tfGetStrVal(ClTmpVar::GetTmpVarStt("Mat")->m_vlrDb ) << endl;
            mtrxCommand(strArgAt +"@="+ strAt, kr clDammieAt); //!< _argN = command �ɕύX���Ă���
            if ( ClTerm::IsAbleToPrintStt() == true ){
                cout << endl;
            }
            delete clDammieAt.m_pTcSfMtrxDb;
            delete clDammieAt.m_pTcSfMtrxCplxDb;
            delete clDammieAt.m_pTcSfMtrxInvs;
            delete clDammieAt.m_pTcSfMtrxInvsCplx;
            clDammieAt.m_pTcSfMtrxDb = 0;
            clDammieAt.m_pTcSfMtrxCplxDb = 0;
            clDammieAt.m_pTcSfMtrxInvs = 0;
            clDammieAt.m_pTcSfMtrxInvsCplx = 0;
        }
        //04.07.03 sf command argment: _prm1@=_prm2, _prm2@=_prm1 �̂悤�� 
        //         _prmN �V���X�^�b�N��̕ϐ��̏Փ˂���������̂ŁA_prmTempN �o�b�t�@��݂���
        for ( int i=1; i<=inCountAt; i++){
            ostringstream ostrmAt;
            ostrmAt << i;
            string strLeftAt= "_prm" + ostrmAt.str();
            string strRightAt= "_prmTemp" + ostrmAt.str();
            ClTmpVar::RegistStt(strLeftAt);
            *ClTmpVar::GetTmpVarStt(strLeftAt) = *ClTmpVar::GetTmpVarStt(strRightAt);
        }
        //ClTmpVar::RegistStt("_rs");
        // sf @strFuncAt(_prm1, _prm2,...) command
        kk::ClTmpVar clTmpVarAt;
        processAtFileName(strFuncAt, kr clDammieAt);
    }
}

void getRightTerm(const string& crStrLeftOprtrAg, ClTerm& rClTermAg, string& rStrResidualAg, string& rStrOprtnAg)
{
    if ( getAndCheckNumericTerm( kr rStrResidualAg, kr rClTermAg) ){ //!< rClTermAg.m_enValueType is changed
    }else{
        if ( rStrResidualAg[0] == '~'){ // tilda
            //~ extention
            string strOldAt = rStrResidualAg; 
            rStrResidualAg = rStrResidualAg.substr(1);

            //initialize _rt file variable
            ClTerm clTermAt;
            clTermAt.m_strVarName = "_rs.val";
            clTermAt.PrintTerm(false);   //set blank value < > to detect user function's abnormal work

            executeTildaExtention( kr rStrResidualAg);
            string strAt("_rs");
            detectVariableTerm( kr strAt, kr rClTermAg);

#if 0
            _rs �ݒ肳��Ȃ��Ƃ��� detectVariableTerm( kr strAt, kr rClTermAg) ���ŃG���[�ɂȂ�
            //Check returned value is not blank
            kAssert("You don't set return value at User Function "+strOldAt+"."
                    , rClTermAg.m_vlrDb.size() || rClTermAg.m_vlrCplxDb.size() );
#endif
        }else if ( rStrResidualAg[0] == '@'){ // command file
            ClTmpVar clTmpVarAt;
            ClTmpVar::RegistStt("_rt");
            string strOldAt = rStrResidualAg;
            rStrResidualAg = rStrResidualAg.substr(1);
            executeAtFile( kr rStrResidualAg);

            string strAt("_rt");
            detectVariableTerm( kr strAt, kr rClTermAg);

            //check returned value is not blank
            kAssert("You don't set return value at sf subroutine "+strOldAt+"."
                    , rClTermAg.m_vlrDb.size() || rClTermAg.m_vlrCplxDb.size() );

        }else if ( rStrResidualAg[0] == '!'){
            processMathFnctn(kr rClTermAg ,  kr rStrResidualAg);
        }else if ( cStrLeftBracketStt.find(rStrResidualAg[0]) != string::npos){
            // rStrResidualAg == {...} or (...) 
            getBracketInnerTerm( kr rStrResidualAg, kr rClTermAg);
        }else{
            detectVariableTerm( kr rStrResidualAg, kr rClTermAg);
        }
    }
    getBinaryOperator(kr rStrResidualAg, kr rStrOprtnAg);

    while ( rStrResidualAg.size() != 0){
        if ( rStrOprtnAg == "NoOperator"){
            rStrOprtnAg = "*";
        }
        if ( doesTakePriority(crStrLeftOprtrAg, rStrOprtnAg) ){
            string strOperatorAt;
            ClTerm clTermRightAt;
            clTermRightAt.Initialize();
            getRightTerm(rStrOprtnAg, kr clTermRightAt, kr rStrResidualAg, kr strOperatorAt);
             rClTermAg.CalculateFourOperations(rStrOprtnAg, clTermRightAt);
             rStrOprtnAg = strOperatorAt;
            continue;
        }else{
            return;
        }
    }
    return;
}


void getLeftTerm(string& rStrResidualAg, ClTerm& rClTermAg)
{
    if ( getAndCheckNumericTerm( kr rStrResidualAg, kr rClTermAg) ){
        // �s����-24 �Ȃǂ̂悤�ɐ��l
        // line head is ninum number as -24
    }else{
        if ( rStrResidualAg[0] == '!'){
            processMathFnctn(kr rClTermAg ,  kr rStrResidualAg);
        }else if ( rStrResidualAg[0] == '~'){
            string strOldAt = rStrResidualAg; 
            rStrResidualAg = rStrResidualAg.substr(1);

            //initialize _rt file variable
            ClTerm clTermAt;
            clTermAt.m_strVarName = "_rs.val";
            clTermAt.PrintTerm(false);   //set blank value < > to detect user function's abnormal work

            executeTildaExtention( kr rStrResidualAg);

            string strAt("_rs");
            detectVariableTerm( kr strAt, kr rClTermAg);

#if 0
            _rs �ݒ肳��Ȃ��Ƃ��� detectVariableTerm( kr strAt, kr rClTermAg) ���ŃG���[�ɂȂ�
            //Check returned value is not blank
            kAssert("You don't set return value at User Function "+strOldAt+"."
                    , rClTermAg.m_vlrDb.size() || rClTermAg.m_vlrCplxDb.size() );
#endif
        }else if ( rStrResidualAg[0] == '@'){ // command file
            ClTmpVar clTmpVarAt;
            ClTmpVar::RegistStt("_rt");
            string strOldAt = rStrResidualAg;
            rStrResidualAg = rStrResidualAg.substr(1);
            executeAtFile( kr rStrResidualAg);

            string strAt("_rt");
            detectVariableTerm( kr strAt, kr rClTermAg);

            //check returned value is not blank
            kAssert("You don't set return value at sf subroutine "+strOldAt+"."
                    , rClTermAg.m_vlrDb.size() || rClTermAg.m_vlrCplxDb.size() );
        }else if ( cStrLeftBracketStt.find(rStrResidualAg[0]) != string::npos){
            getBracketInnerTerm( kr rStrResidualAg, kr rClTermAg);
        }else{
            detectVariableTerm( kr rStrResidualAg, kr rClTermAg);
        }
    }
    cutFrontRearWhiteSpace(kr rStrResidualAg);
}

static double convertStr2Double(const string& crStrAg)
{
    size_t sztExpAt = crStrAg.find('e');
    if ( sztExpAt != string::npos ){
        //check 
        istringstream istrmMantissaAt(crStrAg.substr(sztExpAt+2) );
        int inAt;
        istrmMantissaAt >> inAt;
        kAssert("Too big/small float number at " + crStrAg, inAt <= 300);
    }
    // strResidualAt consistes of only numbers
    istringstream strmAt(crStrAg);
    double dbAt;
    strmAt >> dbAt;
    return dbAt;
}

void GetRightSideVal(const string& crStrResidualAg, ClTerm& rClResultAg)
{

    string strResidualAt = crStrResidualAg;
    cutFrontRearWhiteSpace(kr strResidualAt);

    //< To speed up, a number only expression is processed below.
    if ( ( strResidualAt.find_first_not_of(" +-01234565789.ei") ) == string::npos ){
        if (*strResidualAt.rbegin() == 'i'){
            // complex number
            size_t sztBlankAt = strResidualAt.find_first_of(" ");
            string strRealAt = strResidualAt.substr(0,sztBlankAt);
            string strImageAt = strResidualAt.substr(sztBlankAt+1, strResidualAt.size()-sztBlankAt-2);
            if ( ( strRealAt.find_first_not_of("+-01234565789.e") == string::npos )
              && ( strImageAt.find_first_not_of("+-01234565789.e") == string::npos )
            ){
                size_t sztRealExpAt = strRealAt.find('e');
                size_t sztRealExpSecondAt = strRealAt.rfind('e');
                size_t sztImageExpAt = strImageAt.find('e');
                size_t sztImageExpSecondAt = strImageAt.rfind('e');
                if ( (    (sztRealExpAt == string::npos) 
                       || (  (sztRealExpAt == sztRealExpSecondAt) 
                          && (sztRealExpAt < strRealAt.size()-2) 
                          && (string("+-").find(strRealAt[sztRealExpAt+1]) != string::npos)
                          )
                     )
                  && (    (sztImageExpAt == string::npos) 
                       || (  (sztImageExpAt == sztImageExpSecondAt)
                          && (sztImageExpAt < strImageAt.size()-2)
                          && (string("+-").find(strImageAt[sztImageExpAt+1]) != string::npos)
                          ) 
                     )
                ){
                    rClResultAg.Initialize();
                    rClResultAg.m_blCmplx = true;
                    rClResultAg.m_vlrCplxDb.resize(1);
                    rClResultAg.m_vlrCplxDb[0] = 
                        complex<double>(convertStr2Double(strRealAt)
                                      , convertStr2Double(strImageAt)
                        );
                    return;
                }
            }
        
        }else if ( ( strResidualAt.find_first_not_of("+-01234565789.e") ) == string::npos ){
            size_t sztExpAt = strResidualAt.find('e');
            size_t sztPlusMinusAt = strResidualAt.find_first_of("+-");
            size_t sztExpSecondAt = strResidualAt.rfind('e');
            if ( (sztExpAt == string::npos)
               &&( (sztPlusMinusAt == 0) || ( sztPlusMinusAt == string::npos ) )    //example +25, 35
              || ( (sztExpAt != string::npos )                                      //example 35e+14
                && (sztExpAt == sztExpSecondAt)
                && (sztExpAt < strResidualAt.size()-2 )
                && ( string("+-").find(strResidualAt[sztExpAt+1]) != string::npos )
                 )
            ){
                rClResultAg.Initialize();
                rClResultAg.m_vlrDb.resize(1);
                rClResultAg.m_vlrDb[0] = convertStr2Double(strResidualAt);
                return;
            }
        }
    }

    if ( strResidualAt[0] == '+'){
        //! �s���� + �L���̂Ƃ��́A������Ƃ邾���ŉ������Ȃ��B�s���� + ���Ƃ�Ȃ��ƁA
        //! �㏈���� assert error �������N�����B
        strResidualAt = strResidualAt.substr(1);
        cutFrontRearWhiteSpace(kr strResidualAt);
    }

    ClTerm clTermLeftAt;
    clTermLeftAt.Initialize();
    string strNextOperatorAt;
    string strOperatorAt;

    if ( strResidualAt[0] == '-'){
        // �s���� - �I�y���[�^�Ŏn�܂��Ă���Ƃ������A- �ւ̕����ϊ��������K�v�ɂȂ�
        // If the line head character is just - operator, then we use below conversion codes
        strResidualAt = strResidualAt.substr(1);
        //getLeftTerm( kr strResidualAt, kr clTermLeftAt);
        getRightTerm("-"/*operator*/, kr clTermLeftAt, kr strResidualAt,kr strNextOperatorAt);
        ClTerm clAt;                
        if ( clTermLeftAt.m_blCmplx == true){
            clAt.m_vlrCplxDb.resize(clTermLeftAt.m_vlrCplxDb.size(), (0,0) );
            clAt.m_vlrCplxDb = complex<double>(0,0);
            clAt.m_blCmplx = true;
            if ( clTermLeftAt.m_pTcSfMtrxCplxDb != 0 ){
                clAt.m_pTcSfMtrxCplxDb = new TcSfMtrx<complex<double> >(
                        clAt.m_vlrCplxDb, clTermLeftAt.m_pTcSfMtrxCplxDb->m_sztColumn, 
                        clTermLeftAt.m_pTcSfMtrxCplxDb->m_sztColumn
                );
            }
        }else{
            clAt.m_vlrDb.resize(clTermLeftAt.m_vlrDb.size(), 0);
            clAt.m_vlrDb = 0;
            if ( clTermLeftAt.m_pTcSfMtrxDb != 0 ){
                clAt.m_pTcSfMtrxDb = new TcSfMtrx<double>(
                        clAt.m_vlrDb, clTermLeftAt.m_pTcSfMtrxDb->m_sztColumn, 
                        clTermLeftAt.m_pTcSfMtrxDb->m_sztColumn
                );
            }
        }
        clAt.CalculateFourOperations("-"/* operator */, clTermLeftAt);// clAt = 0 - clTermLeftAt
        clTermLeftAt = clAt;
        strOperatorAt = strNextOperatorAt;
    }else{
        getLeftTerm( kr strResidualAt, kr clTermLeftAt);
        getBinaryOperator(kr strResidualAt, kr strOperatorAt);
    }


    // Now Left term and operator are determind
    while( strResidualAt.size() != 0){
        ClTerm clTermRightAt;
        clTermRightAt.Initialize();

        if ( strOperatorAt == "NoOperator"){
            strOperatorAt = "*";
        }

        getRightTerm( strOperatorAt, kr clTermRightAt, kr strResidualAt, kr strNextOperatorAt);
        clTermLeftAt.CalculateFourOperations(strOperatorAt, clTermRightAt);
        strOperatorAt = strNextOperatorAt;
    }

    rClResultAg = clTermLeftAt;
}

static void setSquareBracketTerm(ClTerm& rClTermLeftAg, const string& crStrSquareAg)
{        
    string strSquareBrAt(crStrSquareAg);

    // Left Side expression has [...] bracket
    strSquareBrAt = strSquareBrAt.substr(1,strSquareBrAt.size()-2);
    cutFrontRearWhiteSpace(kr strSquareBrAt);
    if ( strSquareBrAt[0] == '<'){
        ClTerm clTermVectorAt;
        getVectorVal( strSquareBrAt.substr(1,strSquareBrAt.size()-2), kr clTermVectorAt );
        kAssert( strSquareBrAt + " must be real integer vector.",  clTermVectorAt.m_blCmplx == false);
        kAssert("[<...>] is not slice array.", clTermVectorAt.m_vlrDb.size() == 3);
        rClTermLeftAg.m_inStart = static_cast<int>(clTermVectorAt.m_vlrDb[0]);
        rClTermLeftAg.m_inSize = static_cast<int>(clTermVectorAt.m_vlrDb[1]);
        rClTermLeftAg.m_inStride = static_cast<int>(clTermVectorAt.m_vlrDb[2]);
        kAssert("Vector or Matrix [<n,m,l>]:"+ strSquareBrAt + " is abnormal."
                , (rClTermLeftAg.m_inStart >= 0)
               && (rClTermLeftAg.m_inSize > 0)
               && ( (rClTermLeftAg.m_inStride != 0)
                 || (rClTermLeftAg.m_inSize == 1)
                  )
        );
    }else if(strSquareBrAt.find(',') != string::npos){
        //[h,m] or [*,n] or [m,*] or [*,*]
        kAssert(rClTermLeftAg.m_strVarName + " right Side value must be matrix."
                , (rClTermLeftAg.m_pTcSfMtrxDb != 0 )
               || (rClTermLeftAg.m_pTcSfMtrxCplxDb != 0 )
        );
        string strLeftAt;
        string strRightAt;
        string strRemainAt;
        istringstream strmAt(strSquareBrAt);
        getline(kr strmAt, kr strLeftAt,',');
        getline(kr strmAt, kr strRightAt,',');
        getline(kr strmAt, kr strRemainAt);
        kAssert(rClTermLeftAg.m_strVarName + "[" + strSquareBrAt + "]" + " is abnormal.", strRemainAt =="");

        size_t sztColumnAt;
        size_t sztRowAt;
        if (rClTermLeftAg.m_blCmplx == true){
            sztColumnAt = rClTermLeftAg.m_pTcSfMtrxCplxDb->m_sztColumn;
            sztRowAt = rClTermLeftAg.m_pTcSfMtrxCplxDb->m_sztRow;
        }else{
            sztColumnAt = rClTermLeftAg.m_pTcSfMtrxDb->m_sztColumn;
            sztRowAt = rClTermLeftAg.m_pTcSfMtrxDb->m_sztRow;
        }

        ClTerm clTmIndxLeftAt;
        clTmIndxLeftAt.Initialize();
        ClTerm clTmIndxRightAt;
        clTmIndxRightAt.Initialize();

        if ( (strLeftAt == "*") && (strRightAt == "*") ){
            // Matrix[*,*]  diagonal element
            kAssert(rClTermLeftAg.m_strVarName + " must be square matrx."
                    ,  sztColumnAt == sztRowAt
            );
             kAssert( "Internal Error.", sztColumnAt > 1);
            rClTermLeftAg.m_inStart = 0;
            rClTermLeftAg.m_inSize = sztColumnAt;
            rClTermLeftAg.m_inStride = sztColumnAt+1;
        }else{
            if ( strLeftAt != "*"){
                GetRightSideVal( strLeftAt, kr clTmIndxLeftAt);
                kAssert("Matrix:"+ rClTermLeftAg.m_strVarName + " has wrong left side index:"+strLeftAt
                        , ( clTmIndxLeftAt.m_vlrDb.size() == 1)
                        &&( clTmIndxLeftAt.m_vlrDb[0] >= 0)
                        &&( clTmIndxLeftAt.m_vlrDb[0] < sztColumnAt)
                );
            }
            if ( strRightAt != "*"){
                GetRightSideVal( strRightAt, kr clTmIndxRightAt);
                kAssert("Matrix:"+ rClTermLeftAg.m_strVarName + " has wrong left side index:"+strRightAt
                        , ( clTmIndxRightAt.m_vlrDb.size() == 1)
                        &&( clTmIndxRightAt.m_vlrDb[0] >= 0)
                        &&( clTmIndxRightAt.m_vlrDb[0] < sztRowAt)
                );
            }
             if ( strLeftAt == "*"){
                // Matrix[*,n]  column element
                rClTermLeftAg.m_inStart = static_cast<size_t>(clTmIndxRightAt.m_vlrDb[0]);
                rClTermLeftAg.m_inSize = sztColumnAt;
                rClTermLeftAg.m_inStride = sztRowAt;
            }else if ( strRightAt == "*"){
                // Matrix[n,*]  row element
                rClTermLeftAg.m_inStart = static_cast<size_t>(clTmIndxLeftAt.m_vlrDb[0])*sztRowAt;
                rClTermLeftAg.m_inSize = sztRowAt;
                rClTermLeftAg.m_inStride = 1;
            }else{
                // Matrix[n,m] matrix element
                rClTermLeftAg.m_inStart = static_cast<size_t>(clTmIndxLeftAt.m_vlrDb[0]) * sztRowAt
                             + static_cast<size_t>(clTmIndxRightAt.m_vlrDb[0]);
                rClTermLeftAg.m_inSize = 1;
                rClTermLeftAg.m_inStride = 1;
            }
        }
    }else{
        //vector[n]
        kAssert( rClTermLeftAg.m_strVarName + " is not vector."
                , (rClTermLeftAg.m_pTcSfMtrxDb == 0)
               && (rClTermLeftAg.m_pTcSfMtrxCplxDb == 0)
        );

        ClTerm clTermAt;
        GetRightSideVal(strSquareBrAt, kr clTermAt);
        kAssert(rClTermLeftAg.m_strVarName+ "[strSquareBrAt] needs real number parameter:"
                + strSquareBrAt, (clTermAt.m_blCmplx == false)  && (clTermAt.m_vlrDb.size() == 1) );
        size_t sztAt = static_cast<size_t>(clTermAt.m_vlrDb[0]);
         rClTermLeftAg.m_inStart = sztAt;
        rClTermLeftAg.m_inSize = 1;
        rClTermLeftAg.m_inStride = 1;
    }
}

//makeCmplxRealSame(.) ���A�ǂ��炩�����f���ϐ��̂Ƃ��A�����𕡑f���ɂ���֐��ł��� const �����ɂł��Ȃ�
// LeftTerm[<start,size,stride> = RightTerm �̂Ƃ� rClTermLeftAg �ɂ� LeftTerm �ϐ��̒l�� m_inStart/Size/Stride
// �̒l�������Ă���BrClTermResultAg �ɂ� RightTerm �������l�ɂ܂Ōv�Z�������ʂ������Ă���B
// ==> rClTermResultAg �̒l�� rClTermLeftAg �Ɂi�K�v�Ȃ�� slice array ���������Ɍ��肵�āj�l���R�s�[����
void assignSquareBracketTerm(ClTerm& rClTermLeftAg, ClTerm& rClTermResultAg)
{
    if ( rClTermLeftAg.m_inSize == 0){
        // Left side expression is indicates to copy bones and all
        rClTermLeftAg.m_vlrDb.resize(rClTermResultAg.m_vlrDb.size() ); 
        rClTermLeftAg.m_vlrDb = rClTermResultAg.m_vlrDb;
        delete rClTermLeftAg.m_pTcSfMtrxDb;
        //rClTermLeftAg.m_pTcSfMtrxDb = rClTermResultAg.m_pTcSfMtrxDb;
        if ( rClTermResultAg.m_pTcSfMtrxDb != 0){
            rClTermLeftAg.m_pTcSfMtrxDb = new TcSfMtrx<double>( rClTermLeftAg.m_vlrDb
                    , rClTermResultAg.m_pTcSfMtrxDb->m_sztColumn, rClTermResultAg.m_pTcSfMtrxDb->m_sztRow);
        }
        rClTermLeftAg.m_vlrCplxDb.resize(rClTermResultAg.m_vlrCplxDb.size() ); 
        rClTermLeftAg.m_vlrCplxDb = rClTermResultAg.m_vlrCplxDb;
        delete rClTermLeftAg.m_pTcSfMtrxCplxDb;
        //rClTermLeftAg.m_pTcSfMtrxCplxDb = rClTermResultAg.m_pTcSfMtrxCplxDb;
        if ( rClTermResultAg.m_pTcSfMtrxCplxDb != 0){
            rClTermLeftAg.m_pTcSfMtrxCplxDb = new TcSfMtrx<complex<double> >( rClTermLeftAg.m_vlrCplxDb
                    , rClTermResultAg.m_pTcSfMtrxCplxDb->m_sztColumn, rClTermResultAg.m_pTcSfMtrxCplxDb->m_sztRow);
        }
        rClTermLeftAg.m_blCmplx = rClTermResultAg.m_blCmplx;
    }

    makeCmplxRealSame( kr rClTermLeftAg, kr rClTermResultAg);

    if ( (rClTermLeftAg.m_blCmplx == true) && (rClTermLeftAg.m_inSize > 0 ) ){
        kAssert( "We can't assign the calculated result because left term size is not the result size."
                , rClTermLeftAg.m_inSize == rClTermResultAg.m_vlrCplxDb.size()
        );
        kAssert( "Left term index goes beyond the valarray size."
            , static_cast<int>(rClTermLeftAg.m_vlrCplxDb.size() )
              > (rClTermLeftAg.m_inStart + (rClTermLeftAg.m_inSize-1) * rClTermLeftAg.m_inStride)
        );

        rClTermLeftAg.m_vlrCplxDb[ slice( rClTermLeftAg.m_inStart
                                       , rClTermLeftAg.m_inSize
                                       , rClTermLeftAg.m_inStride
                                  )
        ] = rClTermResultAg.m_vlrCplxDb;
        delete rClTermLeftAg.m_pTcSfMtrxInvsCplx;
        rClTermLeftAg.m_pTcSfMtrxInvsCplx = 0;
    }else if ( (rClTermLeftAg.m_blCmplx == false) && (rClTermLeftAg.m_inSize > 0 ) ){
        kAssert( "We can't assign the calculated result because left term size is not the result size."
                , rClTermLeftAg.m_inSize == rClTermResultAg.m_vlrDb.size()
        );
        kAssert( "Left term index goes beyond the valarray size."
            , static_cast<int>(rClTermLeftAg.m_vlrDb.size() )
              > (rClTermLeftAg.m_inStart + (rClTermLeftAg.m_inSize-1) * rClTermLeftAg.m_inStride)
        );
        rClTermLeftAg.m_vlrDb[ slice( rClTermLeftAg.m_inStart
                                       , rClTermLeftAg.m_inSize
                                       , rClTermLeftAg.m_inStride
                                  )
        ] = rClTermResultAg.m_vlrDb;
        delete rClTermLeftAg.m_pTcSfMtrxInvs;
        rClTermLeftAg.m_pTcSfMtrxInvs = 0;
        rClTermLeftAg.m_inStart = 0;
        rClTermLeftAg.m_inSize = 0;
        rClTermLeftAg.m_inStride = 0;

#ifdef debugX
        cout << "rClTermResultAg.m_vlrDb:" << tfGetStrVal( rClTermResultAg.m_vlrDb) << endl;
        cout << "rClTermLeftAg.m_vlrDb:" << tfGetStrVal( rClTermLeftAg.m_vlrDb) << endl;
        cout << "vrf:" << tfGetStrVal( vlrAt ) << endl;
#endif //debugX
    }
}

static void addSimply(ClTerm& rClTermRsltAg, string& rStrAg, bool bl_dtAg/* if true then add _dt */)
{
    cutFrontRearWhiteSpace(kr rStrAg);
    istringstream istrmAt(rStrAg);
    double dbResultAt=0;
    while (!istrmAt.eof()){
        double dbAt;
        istrmAt >> dbAt;
        dbResultAt += dbAt;
    }

    if ( bl_dtAg == true ){
        ClTerm clDtAt;
    
        clDtAt.ConvertFileToValue("_dt.val");
        kAssert("_dt.val variable is not real simple value at addSimpley(.).",clDtAt.m_vlrDb.size() == 1);
        dbResultAt += clDtAt.m_vlrDb[0];
    }
    rClTermRsltAg.Initialize();
    rClTermRsltAg.m_vlrDb.resize(1);
    rClTermRsltAg.m_vlrDb[0] = dbResultAt;
}

//! if krgAg has !print command then return true;
static bool checkPrintCommand(krgstr& krgAg)
{
    string strRightSideValAt = krgAg % 7;

    size_t sztPrintAt;
    if ( (sztPrintAt = strRightSideValAt.find("!print")  )== string::npos ){
        return false;
    }

    // Now !print(..) command
    kAssert("Dont use left side brackt:" + krgAg%1 +" at !print(.) command", krgAg%4 == "");
    kAssert("!print(.) last character is not ')' at "+strRightSideValAt, strRightSideValAt[strRightSideValAt.size()-1] == ')');

    strRightSideValAt = strRightSideValAt.substr(7,-8+strRightSideValAt.size() );
    cutFrontRearWhiteSpace(kr strRightSideValAt);
#if 0
    kAssert("!print(.) argment is abnormal:" + strRightSideValAt
            , (strRightSideValAt.size() >= 2) 
           && (strRightSideValAt[0] == '"')
           && (strRightSideValAt[-1+strRightSideValAt.size()] == '"') );
    strRightSideValAt = strRightSideValAt.substr(1,-2+strRightSideValAt.size());
#endif

    string strLeftAt = krgAg % 2;
    if ( strLeftAt == ""){
        strLeftAt = "_dt";
    }

    if (ClTmpVar::GetTmpVarStt(strLeftAt) != 0){
        kAssert("Dont use !print(...) for temporary variable:"+ strLeftAt, false);
    }

    //detect {....} curly brace term
    string strAt = krgAg % 3; 
    if ( strAt != ""){
        // LeftSideValue has curly bracket:variableName{...}
        kAssert("Internal error", (strAt[0] == '{') && strAt[strAt.size()-1] == '}');
        strAt = strAt.substr(1,strAt.size()-2 );
        ClTerm clTermAt;
        GetRightSideVal(strAt, kr clTermAt);
        kAssert("Abnormal Curly Brace variable:" + krgAg
                , (clTermAt.m_vlrDb.size() > 0)
               && (clTermAt.m_pTcSfMtrxDb == 0) );
        
        
        ostringstream ostrmAt;
        for (size_t i=0; i< clTermAt.m_vlrDb.size(); ++i){
            int inIndexAt = static_cast<int>(clTermAt.m_vlrDb[i]);
            ostrmAt << "," << inIndexAt;
        }

        string strCurlyBrAt = ostrmAt.str();
        strCurlyBrAt = strCurlyBrAt.substr(1);  // delete first ',' character
        strLeftAt += "{" + strCurlyBrAt + "}";
    }


    if ( strLeftAt.find('.') == string::npos ){
        // There is no secondary name, so we add ".val" 
        strLeftAt += ".val";
    }

    ifstream ifstrmAt;
    ifstrmAt.open( strLeftAt.c_str(), ifstream::in );
    if ( !(ifstrmAt) == true ){
        // There  is strLeftSideValAt variable file
        // Some[n,*] �Ə����Ă��邱�Ƃ����肤��̂ŁA���Ӓl�ł����Ă��}�g���b�N�X�Ƃ��Đ�������
        kAssert( "At !print(...) sf can't find the variable file:" + strLeftAt, false);
    }

    list<string> lstStrPrintAt;
    list<string> lstStrDataAt;
    while ( !ifstrmAt.eof() ){
        string strAt;
        getline(kr ifstrmAt, kr strAt);
        if ( (strAt.size() >= 2) && (strAt[0] == '#') && (strAt[1] == 'g')  ){
            lstStrPrintAt.push_back(strAt);
        }else{
            lstStrDataAt.push_back(strAt);
        }
    }
    ifstrmAt.close();

    ofstream ofstrmAt( strLeftAt.c_str() );
    if ( !ofstrmAt){
        kAssert( "\"sf\" can't open file:"+strLeftAt,false);
    }

    DfEachLoop(list<string>::const_iterator, lstStrPrintAt){
        ofstrmAt << *plstStrPrintAt_ << endl;
        //cout << "debug:" <<*plstStrPrintAt_ << endl;
    }

    ofstrmAt << "#g " << strRightSideValAt << endl;
    if ( (ClTerm::IsAbleToPrintStt() == true)
      && (strLeftAt == "_dt.val")
    ){
        cout << "#g " << strRightSideValAt << endl;
    }

    DfEachLoop(list<string>::const_iterator, lstStrDataAt){
        ofstrmAt << *plstStrDataAt_ << endl;
        //cout << "debug:" <<*plstStrDataAt_ << endl;
    }

    ofstrmAt.close();

    return true;
}

// mtrxCommand(.) may be called by program.
static void mtrxCommand(const string& crStrAg, ClTerm& rClTermResultAg)
{
//#ifdef DfDebugX
#if 1
    if ( ClTerm::IsAbleToPrintStt() == true ){
        cout << " sf command argment: " << crStrAg << endl;
    }
#endif

    if ( crStrAg[0] == '/'){
        if ( (crStrAg == "/s")
//          || (crStrAg == "-s")        //-s calculation �Ƃ̋�ʂ����Ȃ��̂Ŏ~�߂�
//          || (crStrAg == "-silent")
          || (crStrAg == "/silent")
        ){
            ClTerm::m_blPrintStt = false;
            return;
        }else if ( (crStrAg == "/ns")
          || (crStrAg == "/notSilent")
        ){
            ClTerm::m_blPrintStt = true;
            return;
        }else if ( crStrAg.substr(0,4) == "/pvt"){
            istringstream istrmAt(crStrAg.substr(4));
            istrmAt >> ClTerm::m_dbTinyStt;
            if ( ClTerm::m_dbTinyStt <= 0) {
                ClTerm::m_dbTinyStt = 0.00001;    // default value
                cout << "Warning: " + crStrAg + " is abnormal. We don't use that value for the matrix inverse pivot." << endl;
            }
            return;
        }else if ( (crStrAg.substr(0,2) == "/p")
          || (crStrAg.substr(0,10) == "/precision")
        ){
            string strAt;
            if ( crStrAg.substr(0,10) == "/precision"){
                strAt = crStrAg.substr(10);
            }else{
                strAt = crStrAg.substr(3);
            }
            
            istringstream istrmAt(strAt);
            istrmAt.unsetf(ios::basefield);
            istrmAt >> ClTerm::m_inPrecisionStt;
            if ( (ClTerm::m_inPrecisionStt > 0) && (ClTerm::m_inPrecisionStt < 17) ){
            }else{
                ClTerm::m_inPrecisionStt = 6;   // default value
                cout << "Warning: " + crStrAg + " is abnormal. We use default 6 precision." << endl;
            }
            return;
        }else if ( crStrAg.substr(0,3) == "/zs"){
            istringstream istrmAt(crStrAg.substr(3));
            istrmAt >> ClTerm::m_dbZeroSuppressStt;
            if ( !istrmAt.eof() ){
                istrmAt >> ClTerm::m_inZeroSuppressStt;
            }
            if ( ClTerm::m_dbZeroSuppressStt < 0) {
                ClTerm::m_dbZeroSuppressStt = 0;    // default value
                cout << "Warning: " + crStrAg + " is abnormal. We don't use zero suppress." << endl;
            }
            if ( ClTerm::m_inZeroSuppressStt < 0) {
                ClTerm::m_inZeroSuppressStt = 4;    // default value
                cout << "Warning: " + crStrAg + " is abnormal. We set defualt degit 4 at zero supress" << endl;
            }
            return;
        }
    }

    rClTermResultAg.Initialize();
    kAssert("There is no expression.", crStrAg.size() != 0);
    //static krgstr krgStt("(([A-Za-z]`S*)`s*=)?`s*(.*)");
    //static krgstr krgLeftStt("`s*((0x|[��-����-��A-Za-z_][A-Z``a-z0-9_]*)?(`[`S+`])?`s*=)?`s*(.*)");
    //static krgstr krgLeftStt("`s*((0x|[��-����-��A-Za-z_][A-Z``a-z0-9_]*)?({.*})?(`[.+`])?(`.val)?`s*(@)?`s*=)?`s*(.*)");
    krgstr krgLeftStt("^`s*((0x|[��-����-��A-Za-z_][A-Za-z0-9_]*[_'``]*)?({[^{}]+})?(`[.+`])?(`.val)?`s*(@)?`s*=)?`s*(.*)");

    crStrAg / krgLeftStt;

    if ( checkPrintCommand( kr krgLeftStt ) ){  // krgLeftStt % n operation is not constant
        return;
    }

    string strLeftSideValAt = krgLeftStt % 2; // left side for '= ' command operator
    string strArgAt = krgLeftStt % 7;

    // getRigntSideVal(.) �̌�ł� mtrxCommand(.) �� recursive �Ăяo�����ꂽ�Ƃ��AkrgLeftStt ������
    string strCurlyrAt = krgLeftStt % 3; 
    bool blTemVarAtmartAt = ( (krgLeftStt % 6) == "@");
    string strSquareBrAt = krgLeftStt % 4;

    size_t szt_dtAt;
    cutFrontRearWhiteSpace(kr strArgAt);
//****************** calculate expression begin ***********************************
    if ( strArgAt.find_first_not_of( "0123456789. \t") == string::npos ){
        kAssert("Right side expression include .. string at "+strArgAt,  strArgAt.find( "..") == string::npos);
        addSimply(kr rClTermResultAg, strArgAt, false /* No _dt */);
    }else if ( (  (szt_dtAt = strArgAt.find("_dt")) == 0  )
            && ( strArgAt.find_first_not_of( "0123456789. \t", 3) == string::npos )
            && (strArgAt != "_dt")
            && (strArgAt != "_dt.val")
    ){
        string strSubAt = strArgAt.substr(3);
        addSimply(kr rClTermResultAg, kr strSubAt, true /* add _dt */);
    }else if ( ( strArgAt.size() >= 4)
            && ( strArgAt.substr(strArgAt.size()-3) == "_dt")
            && ( strArgAt.find_first_not_of( "0123456789. \t") == strArgAt.size()- 3 )
            && (strArgAt != "_dt")
            && (strArgAt != "_dt.val")
    ){
        string strSubAt = strArgAt.substr(0, strArgAt.size()-3);
        addSimply(kr rClTermResultAg, kr strSubAt, true /* add _dt */);
    }else{
        //string strArgAt = krgLeftStt % 4;
        kAssert("There is no right side expression.", strArgAt.size() != 0);

        //cout << "debug: " << strArgAt << endl; // debug
        GetRightSideVal( strArgAt, kr rClTermResultAg);
    }
//****************** calculate expression end ***********************************

    //detect {....} curly brace term
    if ( strCurlyrAt != ""){
        // variableName{...}
        kAssert("Internal error", (strCurlyrAt[0] == '{') && strCurlyrAt[strCurlyrAt.size()-1] == '}');
        strCurlyrAt = "<" + strCurlyrAt.substr(1,strCurlyrAt.size()-2 ) + ">";
        ClTerm clTermAt;
        GetRightSideVal(strCurlyrAt, kr clTermAt);
        kAssert("Abnormal Curly Brace variable:" + crStrAg
                , (clTermAt.m_vlrDb.size() > 0)
               && (clTermAt.m_pTcSfMtrxDb == 0) );
        
        
        ostringstream ostrmAt;
        for (size_t i=0; i< clTermAt.m_vlrDb.size(); ++i){
            int inIndexAt = static_cast<int>(clTermAt.m_vlrDb[i]);
            ostrmAt << "," << inIndexAt;
        }

        string strCurlyBrAt = ostrmAt.str();
        strCurlyBrAt = strCurlyBrAt.substr(1);  // delete first ',' character
        strLeftSideValAt += "{" + strCurlyBrAt + "}";
    }
    
    if (blTemVarAtmartAt == true){
        ClTmpVar::RegistStt(strLeftSideValAt);
    }
    
    kAssert("You don't use 'i' variable name because 'i' indicates pure imaginary number.", strLeftSideValAt != "i");
    kAssert( "Temporary value declaration cant use square bracket:"+ crStrAg
            , (blTemVarAtmartAt==false) || (strSquareBrAt == "")  );
    if ( strLeftSideValAt == "0x"){
        kAssert( "0x = hex value operation requests real scalar value.",rClTermResultAg.m_vlrDb.size() == 1);
        cout << hex << "0x" << static_cast<int>(rClTermResultAg.m_vlrDb[0]) << endl;
    }else if ( ClTmpVar::GetTmpVarStt(strLeftSideValAt) != 0){
        ClTerm* pClTermAt = ClTmpVar::GetTmpVarStt(strLeftSideValAt);
        if ( strSquareBrAt == ""){
            rClTermResultAg.m_strVarName = strLeftSideValAt;
            pClTermAt->Initialize();
            *pClTermAt = rClTermResultAg;
            //ClTmpVar::GetTmpVarStt(strLeftSideValAt)->m_strVarName = strLeftSideValAt;
        }else{
            setSquareBracketTerm(kr *pClTermAt,strSquareBrAt);
            assignSquareBracketTerm(kr *pClTermAt, kr rClTermResultAg);
        }
        pClTermAt->m_inStart=0;
        pClTermAt->m_inSize=0;
        pClTermAt->m_inStride=0;
    }else{
        if ( strLeftSideValAt == ""){
            strLeftSideValAt = "_dt.val";
        }else if ( strLeftSideValAt.find('.') == string::npos ){
            // There is no secondary name, so we add ".val" 
            strLeftSideValAt += ".val";
        }

        ClTerm clTermLeftAt;
        clTermLeftAt.Initialize();
        clTermLeftAt.m_strVarName = strLeftSideValAt;

        if ( strSquareBrAt != ""){
            clTermLeftAt.ConvertFileToValue(strLeftSideValAt);
            kAssert(strLeftSideValAt + " is not Matirx or Vector and there is  [..] term."
                    ,  ( clTermLeftAt.m_vlrDb.size() > 1 )
                    || ( clTermLeftAt.m_vlrCplxDb.size() > 1 )
            );
    
            setSquareBracketTerm(kr clTermLeftAt, strSquareBrAt);
        }

        assignSquareBracketTerm(kr clTermLeftAt, kr rClTermResultAg);

        clTermLeftAt.PrintTerm();

    }
}

void ClTerm::getStrConsoleVal(size_t sztAg)
{
    //! to make response more first
    if ( ClTerm::IsAbleToPrintStt() == false ){
        return;
    }

    double dbRealAt = 0;
    double dbImageAt = 0;

    if ( m_blCmplx == true ){
        dbRealAt = m_vlrCplxDb[sztAg].real();
        dbImageAt = m_vlrCplxDb[sztAg].imag();

        if ( fabs(dbRealAt) * pow(10.0, -m_inPrecisionStt ) > fabs(dbImageAt) ){
            dbImageAt = 0;
        }else if ( fabs(dbImageAt) * pow(10.0, -m_inPrecisionStt )  > fabs(dbRealAt) ){
            dbRealAt = 0;
        }

        if ( fabs(dbRealAt -1) < pow(10.0, -m_inPrecisionStt) ){
            dbRealAt = 1;
        }
        if ( fabs(dbRealAt +1) < pow(10.0, -m_inPrecisionStt) ){
            dbRealAt = -1;
        }

        if ( fabs(dbImageAt -1) < pow(10.0, -m_inPrecisionStt) ){
            dbImageAt = 1;
        }
        if ( fabs(dbImageAt +1) < pow(10.0, -m_inPrecisionStt) ){
            dbImageAt = -1;
        }

        if ( (m_pTcSfMtrxCplxDb==0) && (m_vlrCplxDb.size() > (m_inZeroSuppressStt/2))
          || (m_pTcSfMtrxCplxDb!=0) && (m_pTcSfMtrxCplxDb->m_sztRow > (m_inZeroSuppressStt/2))
        ){
            if ( fabs(dbImageAt) < m_dbZeroSuppressStt ){
                dbImageAt = 0;
            }
            if (fabs(dbRealAt) < m_dbZeroSuppressStt){
                dbRealAt = 0;
            }
        }
    }else{
        dbRealAt = m_vlrDb[sztAg];
        if ( fabs(dbRealAt -1) < pow(10.0, -m_inPrecisionStt) ){
            dbRealAt = 1;
        }
        if ( fabs(dbRealAt +1) < pow(10.0, -m_inPrecisionStt) ){
            dbRealAt = -1;
        }

        if ( (m_pTcSfMtrxDb==0) && (m_vlrDb.size() > (m_inZeroSuppressStt))
          || (m_pTcSfMtrxDb!=0) && (m_pTcSfMtrxDb->m_sztRow > (m_inZeroSuppressStt))
        ){
            if ( fabs(dbRealAt) < m_dbZeroSuppressStt ){
                dbRealAt = 0;
            }
        }
    }

    //! Writing at file, we use format: "realNumber spce imageNumber+"i" to ease data processing program
    ostringstream ostrmAt;
    ostrmAt.precision(m_inPrecisionStt);
    ostrmAt.fill(' ');

    if ( m_blCmplx == true ){
        if ( (dbRealAt == 0) && (dbImageAt == 0) ){
            ostrmAt <<  0;
        }else{
            if ( dbRealAt != 0){
                ostrmAt <<  dbRealAt;
            }
            if (  (dbImageAt > 0) && (dbRealAt == 0) ){
                if ( dbImageAt == 1){
                    ostrmAt <<  "i";
                }else{
                    ostrmAt <<  dbImageAt << "i";
                }
            }else if (  dbImageAt > 0 ){
                if ( dbImageAt == 1){
                    ostrmAt <<  "+" << "i";
                }else{
                    ostrmAt <<  "+" << dbImageAt << "i";
                }
            }else if (  dbImageAt < 0 ){
                if ( dbImageAt == -1){
                    ostrmAt <<  "-i";
                }else{
                    ostrmAt <<  dbImageAt << "i";
                }
            }
        }
    }else{
        //cout <<  "debug:" << dbRealAt <<endl;   //04.10.06
        ostrmAt <<  dbRealAt;
    }

    //gcc3.3 �ŉ��̏��������Ȃ��� -0 ���o�͂���邱�Ƃ�����B�Č������͕s���ł��B
    string strAt = ostrmAt.str();
    if ( strAt == "-0"){
        strAt = "0"; //gcc3.3 �ł��̋����ݒ�����Ȃ��� -0 ���o�͂���邱�Ƃ�����B�Č������͕s���ł��B
    }

    if ( m_sztConsoleStrLengthMax < ostrmAt.str().size() ){
        m_sztConsoleStrLengthMax  = ostrmAt.str().size();
    }


    //cout << "debug:" << ostrmAt.str() << endl; //debug
    m_lstStrConsole.push_back(strAt);
}

string ClTerm::getStrFileVal(size_t sztAg)
{
    double dbRealAt = 0;
    double dbImageAt = 0;

    if ( m_blCmplx == true ){
        dbRealAt = m_vlrCplxDb[sztAg].real();
        dbImageAt = m_vlrCplxDb[sztAg].imag();
    }else{
        dbRealAt = m_vlrDb[sztAg];
    }

    ostringstream ostrmAt;
    ostrmAt.precision(16);

    string strRealAt;
    //gcc3.3 �ŉ��� strAt �� "+0i" �Ȃǂɖ߂�����������Ȃ��� -0 ���o�͂���邱�Ƃ�����

    ostrmAt <<  dbRealAt;
    strRealAt = ostrmAt.str();
    if ( strRealAt == "-0"){
        strRealAt = "0";
    }

    if ( m_blCmplx == true ){
        ostringstream ostrmImageAt;
        ostrmImageAt.precision(16);
        string  strImageAt("");
            
        ostrmImageAt << dbImageAt;

        strImageAt = ostrmImageAt.str();
        if ( strImageAt == " -0"){
            strImageAt = "0";   //gcc3.3 �ł��̋����ݒ�����Ȃ��� -0 ���o�͂���邱�Ƃ�����B�Č������͕s��
        }

        if ( dbImageAt < 0){
            strRealAt = strRealAt + " " + strImageAt + "i";
        }else{
            strRealAt = strRealAt + " +" + strImageAt + "i"; 
        }
    }


    return strRealAt;
}

int ClTerm::m_inPrecisionStt = 6;
bool ClTerm::m_blPrintStt = true;
bool ClTerm::m_blIniStt = true;     // readSfIniFile() �̍Œ��ł��邱�Ƃ��Ӗ�����t���O�ł�

double ClTerm::m_dbTinyStt = 0.00001;
const double& crDbTinyStt = ClTerm::m_dbTinyStt;

double ClTerm::m_dbZeroSuppressStt = 0;
double ClTerm::m_inZeroSuppressStt = 4;

#ifdef DfVrfy
    static size_t sztCoutLength; // to check cout number string lentth.
    static string strConsoleStt;
#endif //DfVrfy
    

void ClTerm::PrintTerm(bool blDefaultPrintAg)
{
    kAssert("Internal Error at printTerm(.).", m_strVarName.size() != 0);

    m_lstStrConsole.resize(0);
    m_sztConsoleStrLengthMax = 0;


    ofstream ostrmAt( m_strVarName.c_str() );
    if ( !ostrmAt){
        kAssert( "\"sf\" can't open file:"+m_strVarName, false);
    }
    if ( m_blCmplx == true){
        //kAssert("CodingLefted 03.04.05.",0);
        if ( m_pTcSfMtrxCplxDb == 0){
            // vector
            ostrmAt << "% BaseComplexDouble " << m_vlrCplxDb.size() << endl;
        }else{
            // matrix
            ostrmAt << "% BaseComplexDoubleMatrix " << m_pTcSfMtrxCplxDb->m_sztColumn
                    << ",  " << m_pTcSfMtrxCplxDb->m_sztRow << endl;
        }
    }else{
        // real
        if ( m_pTcSfMtrxDb == 0){
            // vector
            ostrmAt << "% BaseDouble " << m_vlrDb.size() << endl;
        }else{
            // matrix
            ostrmAt << "% BaseDoubleMatrix " << m_pTcSfMtrxDb->m_sztColumn
                    << ",  " << m_pTcSfMtrxDb->m_sztRow << endl;
        }
    }

    size_t sztColumnAt, sztRowAt;
    if ( m_blCmplx == true){
        if ( m_pTcSfMtrxCplxDb == 0){
            sztColumnAt = 1;    
            sztRowAt = m_vlrCplxDb.size();
        }else{
            sztColumnAt = m_pTcSfMtrxCplxDb->m_sztColumn;   
            sztRowAt = m_pTcSfMtrxCplxDb->m_sztRow; 
        }
    }else{
        if ( m_pTcSfMtrxDb == 0){
            sztColumnAt = 1;    
            sztRowAt = m_vlrDb.size();
        }else{
            sztColumnAt = m_pTcSfMtrxDb->m_sztColumn;   
            sztRowAt = m_pTcSfMtrxDb->m_sztRow; 
        }
    }

    for ( size_t i=0; i<sztColumnAt; ++i){
        ostrmAt << "< ";
        for ( size_t j=0; j<sztRowAt; ++j){
            getStrConsoleVal( i*sztRowAt + j);
            ostrmAt << getStrFileVal( i*sztRowAt + j );
            // At last, we don't out ','
            if ( j != sztRowAt -1 ){
                ostrmAt << ", ";
            }
        }
        ostrmAt << " >" << endl;
    }

#if 0
    //04.10.19  <== �t�s��f�[�^�̃t�@�C���ϐ��ւ̃R�s�[�� version 2 �ɂ���B
    // = operator �͋t�s����R�s�[�����Ă��邪�A�s��^-1 �����ł͋t�s�񕔕����R�s�[���Ă��Ȃ�
    //10 ���s�𒴂���x�N�^�t�@�C���ϐ��̓ǂݍ��݂̍������ƈꏏ�Ɍ������Ȃ��ƈӖ����Ȃ�
    //���̃R�[�h�́Am_pTcSfMtrxInvs ������t�������ĕ�������\��������
    if ( m_pTcSfMtrxInvsCplx != 0 ){
        ostrmAt << "% BaseComplexDoubleInverted " << m_pTcSfMtrxInvsCplx->m_determinantT << endl;
        //if ( m_pTcSfMtrxInvsCplx->m_determinantT ==complex<double>(0,0) )
        if(m_pTcSfMtrxInvsCplx->m_enState != TcSfMtrxInvs<complex<double> >::EnInverted){
            for ( size_t i=0; i<sztRowAt; ++i){
                ostrmAt << "< ";
                for ( size_t j=0; j<sztRowAt; ++j){
                    ostrmAt << getStrFileVal( i*sztRowAt + j );
                    if ( j<(sztRowAt-1) ){
                        ostrmAt << ", ";
                    }
                }
                ostrmAt << " >" << endl;
            }
        }
    }
#endif //0
    ostrmAt.close();

    if ( (ClTerm::IsAbleToPrintStt() == true) 
      && (blDefaultPrintAg == true)
    ){
        list<string>::const_iterator itrLstStrAt = m_lstStrConsole.begin();;
        for ( size_t i=0; i<sztColumnAt; ++i){
            cout << "< ";
            for ( size_t j=0; j<sztRowAt; ++j){
                cout << setfill(' ') << setw(m_sztConsoleStrLengthMax) << *itrLstStrAt++;
                // At last, we can't print out ','
                if ( j != sztRowAt -1 ){
                    cout << ", ";
                }
            }
            cout << " >" << endl;
        }
    }
#ifdef DfVrfy
    sztCoutLength = m_sztConsoleStrLengthMax;
#endif //DfVrfy
}

static bool isClosedBracket(string& rStrAg)
{
    size_t sztBracketAt = rStrAg.find_first_of(cStrLeftBracketStt);
    while ( sztBracketAt != string::npos ){

        StPairOld stPairedAt( rStrAg[sztBracketAt]
                ,cStrRightBracketStt[ cStrLeftBracketStt.find(rStrAg[sztBracketAt]) ] );
        
        size_t sztRightAt;
        sztRightAt = findSztStPaired(rStrAg, sztBracketAt, rStrAg.size(), kr stPairedAt );
        if ( sztRightAt == string::npos){
            return false;
        }
        sztBracketAt = rStrAg.find_first_of(cStrLeftBracketStt, sztRightAt);
    }
    return true;
}


//if rStrAg == ""  because rIfstrmAg.eof == true then getLineFromFile(.) return false
static bool getLineFromFile(string& rStrAg, ifstream& rIfstrmAg, int& rInTempLineAg)
{
    rStrAg = "";
    rInTempLineAg = 0;
    bool blEscapeAt = false;    // �s���� '\' �����o�����Ƃ��ɃZ�b�g����
    while ( !rIfstrmAg.eof() ){
        int inTempLineAt=0;
        string strAt="";
        getline(kr rIfstrmAg, kr strAt);
        ++rInTempLineAg;
        size_t sztAt = strAt.find('#');

        cutRearCR(kr strAt);

        if ( sztAt != string::npos ){
            // there is a comment starting with "##"
            if ( (ClTerm::IsAbleToPrintStt() == true )
              && ( strAt.size() > sztAt+1 )
              && ( strAt[sztAt+1] == '#' )
            ){
                cout << strAt << endl;
#ifdef DfVrfy
                strConsoleStt = strAt;
#endif
            }
            strAt = strAt.substr(0,sztAt);
        }
        cutFrontRearWhiteSpace( kr strAt);
        if ( strAt.size() == 0 ){
            continue;
        }

        if ( strAt[strAt.size()-1] == '\\' ){
            strAt = strAt.substr(0, strAt.size()-1); // cut last '\\' character
            if ( (rStrAg.size() != 0) && (*rStrAg.rbegin() != ',') && (strAt[0] != ',') && (blEscapeAt == false)){
                rStrAg += "," + strAt;
            }else{
                rStrAg += strAt;
            }
            blEscapeAt = true;
            continue;
        }
        if ( (rStrAg.size() != 0) && (*rStrAg.rbegin() != ',') && (strAt[0] != ',') && (blEscapeAt == false)){
            rStrAg += "," + strAt;
        }else{
            rStrAg += strAt;
        }
        blEscapeAt = false;
        if ( isClosedBracket(kr rStrAg) == false ){
            continue;
        }
        return true;
    }
    kAssert("We arrived file end unexpectedly:"+rStrAg, rStrAg== "");
    return false;
}

/*! @@subVar subVarFileName_x_y vectorSize ( or matrixColSize, rowSize)
        <x+y>          @@subVar ���� @@endSubVar �܂ł͈̔͂� block sf �t�@�C���Ƃ���
          �E
        other entity
    @@endSubVar
*/

static void processAtSubVar(const string& crStrConcatenatedAg, ifstream& rIfstrmAg, int& rInTempLineAg)
{
    //! now sf @file has "@@subVar fileName size/column row" string
    //! We write string untile @@endSubVar
    string strFileNameAt;
    int inSizeColumnAt;
    int inRowAt;
    istringstream istrmAt(crStrConcatenatedAg);

    istrmAt >> strFileNameAt;   // damie read "@subVar"
    istrmAt >> strFileNameAt >> inSizeColumnAt;
    if ( istrmAt.eof() ){
        inRowAt = 0;
    }else{
        char chAt;
        istrmAt >> chAt;  // read ',' character
        istrmAt >> inRowAt;
    }

    if ( strFileNameAt.find('.') == string::npos ){
        // There is no secondary name, so we add ".val" 
        strFileNameAt += ".val";
    }

    ofstream ofstrmAt( strFileNameAt.c_str() );
    if ( !ofstrmAt){
        kAssert( "\"sf\" can't open subVar file:"+strFileNameAt,false);
    }
    if ( inRowAt == 0){
        ofstrmAt << "% BaseVarDouble " << inSizeColumnAt << endl;
    }else{
        ofstrmAt << "% BaseVarDoubleMatrix " << inSizeColumnAt << ", " << inRowAt << endl;
    }
    string strAt;
    while ( getLineFromFile(kr strAt, rIfstrmAg, rInTempLineAg) ){
        if ( strAt == "@@endSubVar" ){
            return;
        }else{
            ofstrmAt << strAt << endl;
        }
    }
    kAssert( "\"sf\" can't find the @@endSubVar.", false);
}

/*! sub file definition format

    @@subFile subFileName   # argment is _prm1, prm2,....
        temp @= _prm1 + _prm2
          �E
        other entity
    @@endsubFile
*/

static void processAtSubFileBlock(const string& crStrConcatenatedAg, ifstream& rIfstrmAg, int& rInTempLineAg)
{
    //! now sf @file has "@@subVar fileName size/column row" string
    //! We write string untile @@endSubVar
    string strFileNameAt;
    istringstream istrmAt(crStrConcatenatedAg);

    istrmAt >> strFileNameAt;   // damie read "@subFile"
    istrmAt >> strFileNameAt;

    if ( strFileNameAt.find('.') == string::npos ){
        // There is no secondary name, so we add ".val" 
        strFileNameAt += ".sf";
    }

    ofstream ofstrmAt( strFileNameAt.c_str() );
    if ( !ofstrmAt){
        kAssert( "\"sf\" can't open output subFile:"+strFileNameAt,false);
    }
    string strAt;
    while ( getLineFromFile(kr strAt, rIfstrmAg, rInTempLineAg) ){
        if ( strAt == "@@endSubFile" ){
            return;
        }else{
            ofstrmAt << strAt << endl;
        }
    }
    kAssert( "\"sf\" can't find the @@endSubFile.", false);
}

static void processAtFileName(const string& crStrFileNameAg, ClTerm& rClTermResultAg)
{
    string strFileNameAt = crStrFileNameAg;
    if ( strFileNameAt.find('.') == string::npos ){
        // There is no secondary name, so we add ".sf" 
        strFileNameAt += ".sf";
    }

    ifstream ifstrmAt;
    ifstrmAt.open( strFileNameAt.c_str(), ifstream::in );
    if ( !(ifstrmAt) == true ){
         kAssert( "\"sf\" can't find the @ mark command file:" + strFileNameAt, false);
    }

    string strConcatenatedAt="";
    int inLineAt=1;
    int inTempLineAt;
    while ( getLineFromFile(kr strConcatenatedAt, kr ifstrmAt, kr inTempLineAt) ){

        if ( strConcatenatedAt.substr(0,8) == "@@subVar"){
            processAtSubVar(strConcatenatedAt, kr ifstrmAt, kr inTempLineAt);
            continue;
        }else if ( strConcatenatedAt.substr(0,9) == "@@subFile"){
            processAtSubFileBlock(strConcatenatedAt, kr ifstrmAt, kr inTempLineAt);
            continue;
        }

        cout << "CommandFile:" << strFileNameAt <<" line:" << inLineAt << "   " << strConcatenatedAt << endl;
        loopCommand(strConcatenatedAt, kr rClTermResultAg);
        inLineAt += inTempLineAt;
        strConcatenatedAt = "";
    }
}


static int inLoopCountStt = 0;
ClTerm* pClTermStt; //debug

static string getCommand(string& rStrAg)
{
    cutFrontRearWhiteSpace(kr rStrAg);
    string strWithBracketAt("");
    while ( rStrAg != ""){
        size_t sztCommaAt = rStrAg.find(',');
        size_t sztBracketAt = rStrAg.find_first_of(cStrLeftBracketStt);

        if ( ( sztBracketAt == string::npos)
          || (sztCommaAt < sztBracketAt )
        ){
            strWithBracketAt += rStrAg.substr(0,sztCommaAt);
            if ( sztCommaAt != string::npos ){
                rStrAg = rStrAg.substr(++sztCommaAt);
            }else{
                rStrAg = "";
            }
            cutFrontRearWhiteSpace(kr rStrAg);
            return strWithBracketAt;
        }else{
            StPairOld stPairedAt( rStrAg[sztBracketAt]
                    ,cStrRightBracketStt[ cStrLeftBracketStt.find(rStrAg[sztBracketAt]) ] );
            
            size_t sztRightAt;
            sztRightAt = findSztStPaired(rStrAg, sztBracketAt, rStrAg.size(), kr stPairedAt );
            
            string strBracketAt;
            strBracketAt += rStrAg[sztBracketAt];
            strBracketAt += "...";
            strBracketAt += cStrRightBracketStt[ cStrLeftBracketStt.find(rStrAg[sztBracketAt]) ];
            kAssert("We can't find paired "+strBracketAt+" at "+ rStrAg + " in loopCommand()", (sztRightAt != string::npos) );
            strWithBracketAt += rStrAg.substr(0,sztRightAt+1);
            rStrAg = rStrAg.substr(sztRightAt+1);
            cutFrontRearWhiteSpace(kr rStrAg);
        }
    }
    return strWithBracketAt;    //���̂� gdb, gcov �Ƃ��Awhile(.) �u���b�N�𔲂����ɂ�������킸�A���̍s���΂��B
}

//! rClTermResultAg �����́AkVerifier ���v�Z���ʂ��m�F���邽�߂ɐ݂���
static void loopCommand(const string& crStrAg, ClTerm& rClTermResultAg)
{
    string strResidualAt(crStrAg);
    //cout << "loopCommand() arg:" << crStrAg << endl;    //debug

    //kk::ClTmpVar clTmpVarAt;
    while (strResidualAt.size() > 0 ){
        string strAt = getCommand(kr strResidualAt);
        cutFrontRearWhiteSpace(kr strAt);
        if ( strAt.size() == 0){
            continue;
        }
#if 0
2004.04.07 sf var = @fileName �̋L�q�������悤�ɂ������Ƃɔ����ύX
        if ( strAt[0] == '@'){
            kAssert("@subVar can be used only program file without nesting:"+crStrAg
                    , strAt.substr(0,4) != "@subVar" );
            kk::ClTmpVar clTmpVarAt;
            // sf @FileName command
            strAt = strAt.substr(1);
            processAtFileName(strAt, kr rClTermResultAg);
        }else if ( *(--strAt.end()) == '@' ){
            //! Temporary variable declaration
            //! strAt == "temporaryVariableName@"
            kAssert("Abnormal temporay variable name:" + strAt
                , strAt.find_first_of(" \t[]<>") == string::npos);
            ClTmpVar::RegistStt(  strAt.substr(0,-1+strAt.size() )  );
            ClTmpVar::GetTmpVarStt(  strAt.substr(0,-1+strAt.size() )  )->Initialize();
            
            //ClTmpVar* pClTmpVar = *ClTmpVar::m_lstpClTmpVarStt.begin(); //debug
            //pClTermStt = *(pClTmpVar->m_lstpClTerm.begin());  //debug
            cout << " sf command argment: " << strAt << endl;
            continue;
        }else{
#endif
        if ( strAt.substr(0,2) == "@@" ){
            // block execution
            kk::ClTmpVar clTmpVarAt;
            // sf @FileName command
            strAt = strAt.substr(2);
            if ( strAt.find('.') == string::npos ){
                // There is no secondary name, so we add ".se" 
                strAt += ".se";
            }
            processAtFileName(strAt, kr rClTermResultAg);
        }else if ( *(--strAt.end()) == '@' ){
            //! Temporary variable declaration
            //! strAt == "temporaryVariableName@"
            kAssert("Abnormal temporay variable name:" + strAt
                , strAt.find_first_of(" \t[]<>") == string::npos);
            ClTmpVar::RegistStt(  strAt.substr(0,-1+strAt.size() )  );
            ClTmpVar::GetTmpVarStt(  strAt.substr(0,-1+strAt.size() )  )->Initialize();
            
            //ClTmpVar* pClTmpVar = *ClTmpVar::m_lstpClTmpVarStt.begin(); //debug
            //pClTermStt = *(pClTmpVar->m_lstpClTerm.begin());  //debug
            cout << " sf command argment: " << strAt << endl;
            continue;
        }else{

            //cout << "debug:Mat.m_vlrDb:" << tfGetStrVal(ClTmpVar::GetTmpVarStt("Mat")->m_vlrDb ) << endl;
            mtrxCommand(strAt, kr rClTermResultAg);
            if ( ClTerm::IsAbleToPrintStt() == true ){
                cout << endl;
            }
            //! rClTermResultAg �̍s��C���X�^���X�������B�v�Z���ʎ��̂� 
            //! m_vlrDb/m_vlrCplxDb �Ɏc���Ă���
            delete rClTermResultAg.m_pTcSfMtrxDb;
            delete rClTermResultAg.m_pTcSfMtrxCplxDb;
            delete rClTermResultAg.m_pTcSfMtrxInvs;
            delete rClTermResultAg.m_pTcSfMtrxInvsCplx;
            rClTermResultAg.m_pTcSfMtrxDb = 0;
            rClTermResultAg.m_pTcSfMtrxCplxDb = 0;
            rClTermResultAg.m_pTcSfMtrxInvs = 0;
            rClTermResultAg.m_pTcSfMtrxInvsCplx = 0;
        }
    }
}

//--------------------- Temporary Variable begin ----------------------------
list<ClTmpVar*> ClTmpVar::m_lstpClTmpVarStt;
ClTmpVar::ClTmpVar(void)
{
    m_lstpClTmpVarStt.push_front(this);
}

ClTmpVar::~ClTmpVar(void)
{
    //!delete all ClTerm member in m_lstpClTerm
    while (m_lstpClTerm.size() != 0){
        delete *m_lstpClTerm.begin();
        m_lstpClTerm.pop_front();
    }
    m_lstpClTmpVarStt.pop_front();
}

void ClTmpVar::DoAtExitStt(void)
{
    kAssert("Abnormal temporay variable nesting.", m_lstpClTmpVarStt.size() == 1);
}

ClTerm* ClTmpVar::GetTmpVarStt(const string& crStrAg, list<ClTmpVar*>::iterator itrAg)
{
    if ( itrAg == m_lstpClTmpVarStt.end() ){
        //! We can't find crStrAg name temporary variable
        return 0;
    }else{
        //! VC7.0 �ł́Aconst string& �ɂ���� bin2nd(.) �ŃG���[�ɂȂ�
        struct StP{ static bool p( ClTerm* pClTermAg, const string crStrAg){
            return pClTermAg->m_strVarName == crStrAg;
        }};
        ClTmpVar* pClTmpVarAt = *itrAg;
        list<ClTerm*>::iterator itrAt;
        itrAt = find_if( pClTmpVarAt->m_lstpClTerm.begin(), pClTmpVarAt->m_lstpClTerm.end()
                , bind2nd(ptr_fun(StP::p), crStrAg) );
        if (itrAt == pClTmpVarAt->m_lstpClTerm.end() ){
            return ClTmpVar::GetTmpVarStt( crStrAg,kr ++itrAg);
        }else{
            return *itrAt;
        }
    }
    return 0;
}


bool ClTmpVar::RegistStt(const string& crStrTermAg)
{
    kAssert("Don't use ClTmpVar::RegstStt(.) at m_lstpClTmpVarStt size = 0.", m_lstpClTmpVarStt.size() >= 1);
    ClTmpVar* pClTmpVarAt = *m_lstpClTmpVarStt.begin();

    struct StP{ static bool p( ClTerm* pClTermAg, const string crStrAg){
        return pClTermAg->m_strVarName == crStrAg;
    }};
    list<ClTerm*>::iterator itrAt;
    itrAt = find_if( pClTmpVarAt->m_lstpClTerm.begin(), pClTmpVarAt->m_lstpClTerm.end() 
                , bind2nd(ptr_fun(StP::p), crStrTermAg) );

    if ( itrAt == pClTmpVarAt->m_lstpClTerm.end() ){
        ClTerm* pClTermAt = new ClTerm(crStrTermAg);
        //************** debug begin***********************
        if (crStrTermAg == "Mat"){
            pClTermStt = pClTermAt;
        }
        //************** debug end***********************
        pClTmpVarAt->m_lstpClTerm.push_front(pClTermAt);
        return true;
    }else{
        kAssert("Multiple temporary variable declaration:"+crStrTermAg, false);
        return false;   // kAssert �̌�� damie return, ��������� warning ���ł�
    }
}

static void readSfIniFile(void )
{
    ifstream ifstrmAt;
    ifstrmAt.open( "sf.ini", ifstream::in );
    if ( !(ifstrmAt) == false ){
        string strConcatenatedAt="";
        ClTerm clDamieAt;
        int inLineAt=1;
        int inTempLineAt;
        while ( getLineFromFile(kr strConcatenatedAt, kr ifstrmAt, kr inTempLineAt) ){
            loopCommand(strConcatenatedAt, kr clDamieAt);
            inLineAt += inTempLineAt;
            strConcatenatedAt = "";
        }
    }
    ClTerm::m_blIniStt = false;
}

//--------------------- Temporary Variable End ----------------------------

ClTerm clTermRsltValStt;


} //namespace kk

#ifdef DfVrfy
#include <VrfyLib.h>


static string strAssertStt;
int main(int argc, char** argv)
{
    //cout << "In main at Verifier." <<endl;  //debug
#ifdef DfVC_X
    int tmpDbgFlagAt = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG);
    tmpDbgFlagAt |= _CRTDBG_LEAK_CHECK_DF;
    _CrtSetDbgFlag(tmpDbgFlagAt);
    //_CrtSetBreakAlloc(136);
    _CrtDumpMemoryLeaks(); 
#endif  // DfVC_
    try{
        int inAt;
        kk::ClTmpVar clTmpVarIniAt;
        kk::readSfIniFile();
        {
            kk::ClTmpVar clTmpVarAt;
            kk::ClTmpVar::RegistStt("_rt");
            // ClVrfySglt::Main() can handle protected, priveate member in the ClVrfySglt
           // ClVrfySglt::GetStt()->m_PvVrfyFiber = ConvertThreadToFiber(0);
            //ClVrfySglt::Main(,) �� 0 �����Ԃ��Ȃ�����ǁA��� verifier ���ς�����Ƃ��̂��߂ɁA���̂悤�ɏ����Ă���
            inAt= kk::ClVrfySglt::GetStt()->Main(argc, argv);
        }
        kk::ClTmpVar::DoAtExitStt();
        return inAt;
    }catch(kk::ClRglError* pClRglError){
        cout << "Internal Execption Error at Regular Expression Analysis: " << pClRglError->m_strCst << endl;
        strAssertStt = pClRglError->m_strCst;
        delete pClRglError;
        return 1;
    }catch(kk::ClError* pClError){
        cout << "Internal Execption Error: " << pClError->m_strCst << endl;
        strAssertStt = pClError->m_strCst;
        delete pClError;
        return 1;
    }catch(...){
        cout << "Internal Error, sf catched unexpected execption." << endl;
        return 1;
    }
}

namespace kk{

//void checkFile( char* pChFileNameAg, int inLineNumberAt, const string& strFileLineAg)
static void checkFileLine( const string& crStrAg)
{
    istringstream istrmAt(crStrAg);
    string strFileNameAt;
    int inLineNumberAt;
    string strFileLineAt;
    
    istrmAt >> strFileNameAt >> inLineNumberAt;
    getline(kr istrmAt, kr strFileLineAt, '|'); // delemiter '|' and damie read
    //cout << "debug: "  << crStrAg << endl;
    //cout << "debug: "  << inLineNumberAt << endl;
    
    getline(kr istrmAt, kr strFileLineAt, '|');

    //cout << "debug: "  << strFileLineAt << endl;

    ClGetLine clAt(strFileNameAt);

    string strLineAt;
    while ( int inAt = clAt(kr strLineAt) ){
        if (inAt == inLineNumberAt ){
            cutRearCR(kr strLineAt);
            if ( strLineAt == strFileLineAt ){
                ClVrfySglt::GetStt()->OutWithTime("OK!:checkFileLine(.) "+ crStrAg);
            }else{
                ClVrfySglt::GetStt()->OutError( "checked:" + strFileLineAt
                        + "  Real File String is " + strLineAt);
            }
            return;
        }
    }
    kAssert( "Internal Error:checkFileLine():argment is " + crStrAg, 0);
}

//! �e�X�g�̂��߂̃t�@�C���� makeFile(.) �ɍs�킹��
//! delemeter �� "\x0a" �Ƃ���B�ŏ��ɋL�^����t�@�C����������
//! example format 
//!     fileName \x0a 1stline\x0a 2ndl line\x0a
static void makeFile(const string& crStrAg)
{
    istringstream istrmAt(crStrAg);
    string strAt;
    size_t sztLeftAt =0;
    size_t sztRightAt = crStrAg.find("\\x0a");
    strAt = crStrAg.substr(sztLeftAt, sztRightAt - sztLeftAt);
    cutFrontRearWhiteSpace(kr strAt);
    ofstream ofstrmAt( strAt.c_str() );
    if ( !ofstrmAt){
        kAssert( "At makeFile(.), we can't open file:"+strAt,false);
    }

    for(;;){
        sztLeftAt = sztRightAt;
        if ( sztLeftAt == string::npos ){
            return;
        }
        sztRightAt = crStrAg.find("\\x0a", sztLeftAt+1);
        strAt = crStrAg.substr(sztLeftAt+4, sztRightAt - sztLeftAt-4);
        cutFrontRearWhiteSpace(kr strAt);
#if 0
        if ( strAt[0] == '#'){
            continue;
        }
#endif
        ofstrmAt << strAt << endl;
    }
}

class ClCompare : public ClBaseVerified{
    const double m_cDbPresision;// = 0.0001;
    const ClTerm* m_cpClTerm;
  public:
    ClCompare(const ClTerm* cpcClTermAg, const string& crStrAg):ClBaseVerified(crStrAg), m_cDbPresision(0.0001)
            ,m_cpClTerm(cpcClTermAg){};
    virtual bool Compare(const std::string& crStrAg)
    {
        if (m_cpClTerm->m_vlrDb.size() ){
            valarray<double> vlrDbAt;
            tfSet(crStrAg,kr vlrDbAt);
            vlrDbAt -= m_cpClTerm->m_vlrDb;
            return (double)tfCntnrAbs(vlrDbAt) <=  m_cDbPresision;
        }else if ( m_cpClTerm->m_vlrCplxDb.size() ){
            valarray<complex<double> > vlrDbCplxAt;
            tfSet(crStrAg,kr vlrDbCplxAt);
            vlrDbCplxAt -= m_cpClTerm->m_vlrCplxDb;
            return (double)tfCntnrAbs(vlrDbCplxAt) <=  m_cDbPresision;
        }else{
            kAssert("Both m_cpClTerm->m_vlr..Db size are 0", false);
            return false;
        }
    }
    virtual std::string WhatValue(void)
    {
        if (m_cpClTerm->m_vlrDb.size() ){
            return tfGetStrVal(m_cpClTerm->m_vlrDb);
        }else{
            return tfGetStrVal(m_cpClTerm->m_vlrCplxDb);
        }
    }
};

class ClTestVctDD : public ClVfLibActn {
  public:
  protected:
    virtual void doAtInitialVl( const std::string& crStrAg);
    //virtual void polling();
};

static ClTestVctDD clTestVctD;

void callLoopCommand(const string& crStrAg)
{
    try{
        ClTmpVar clTmpVarAt;
        loopCommand(crStrAg, kr clTermRsltValStt);
    }catch(ClVrfyError* pClVrfyError){
        strAssertStt = pClVrfyError->m_cStrCst;
        cout << "Now in callLoopCommand(.) cattch: " << strAssertStt << endl; // to debug
    }catch(...){
        clTestVctD.OutError("sf catched unexpected execption.");
        cout << "sf catched unexpected execption." << endl;
    }
}

void ClTestVctDD::doAtInitialVl( kc string& crStrAg)
{

    if ( IsSameNocase(crStrAg,"typical.vrf")
      || IsSameNocase(crStrAg,"testSc.vrf")
      || IsSameNocase(crStrAg,"testCm.vrf")
      || IsSameNocase(crStrAg,"test.vrf")
      || IsSameNocase(crStrAg,"v\\testCm.vrf")
      || IsSameNocase(crStrAg,"cvrg.vrf")
    ){
        ClTestVct::doAtInitialVl(crStrAg);  // open crStrAg file
        //openTestVct(crStrAg);  // �g���e�X�g�E�x�N�^���w�肷��
        kcout << "Now verifying input file is " << crStrAg << " in main.cpp" << endl;

        //tfRgstVerified(this, tfNewVerified(clTermRsltValStt.m_inValue, "clTermRsltValStt.m_inValue") );
        //tfRgstVerified(this, tfNewVerified(clTermRsltValStt.m_vlrDb[0], "����", 0.0001) );
        //!< m_vlrDb �� resize() �������Ȃ����̂ŁA&m_vlrDb[0] �͎��s�r���ŕω����Ă��܂�
        RgstVerified(this, tfNewVfCntnr(clTermRsltValStt.m_vlrDb, "����Cntnr", 0.0001) );
        RgstVerified(this, tfNewVfCntnr(clTermRsltValStt.m_vlrCplxDb, "���f����Cntnr", 0.0001) );
        //tfRgstVerified(this, tfNewVerified(clTermRsltValStt.m_vlrCplxDb, "���f���� Cntnr", 0.0001) );
        //tfRgstVerified(this, tfNewVerified(clTermRsltValStt.m_dbValue, "clTermRsltValStt.m_dbValue" ) );
        //tfRgstVerified(this, tfNewVfFnctnSpl(mtrxCommand, "����") );
        RgstVerified(this, tfNewVfFnctnSpl(callLoopCommand, "����") );
        RgstVerified(this, tfNewVfFnctnSpl(checkFileLine,"checkFileLine") );
        RgstVerified(this, tfNewVfFnctnSpl(makeFile,"makeFile") );

        RgstVerified(this, tfNewVerified(strAssertStt,"strAssertStt") );
        RgstVerified(this, tfNewVerified(strConsoleStt,"strConsoleStt") );

        RgstVerified(this, new ClCompare(&clTermRsltValStt,"����") );

        RgstVerified(this, tfNewVerified(sztCoutLength,"sztCoutLength") );

    }
}
}//namespace kk

#else   // DfVrfy

namespace kk{
static string strStt1("\x0a\
::four operations: + - * / ^ >sf \"3+4+5, 3-4, 3*(4+5), (3+4)/5,3^0.4\"\x0a\
    default calculation result is in _dt.val. Use the last result. >sf _dt+1+2\x0a\
::complex number operations: >sf \"3+4, 3i-4,3*(1+4i),(4+i)/3,i^0.5+i\"\x0a\
::transform to hex integer   >sf 0x=1024+0x10+0b1111_0101\x0a\
::vector/matrix expression   >sf \"vector=<0,1,2,3,4>,vector[0]=1000\"\x0a\
  generate size 10, 0 element vector  >sf \"vector=<<10>>\"\x0a\
  generate Matrix of column/row e 3/4 >sf \"matrix=[[3,4]], matrix[0,1]=1000\"\x0a\
  generate 3x3 square matrix & set row >sf \"matrix=[[3]], matrix[0,*]=<1,2,3>\"\x0a\
  matrix row and diagonal access      >sf \"matrix[*,2]=<4,5,6>,matrix[*,*]=<7,8,9>\"\x0a\
:: inner product             > sf \"<vector|<1,2,3,4,5> >, <vector|matrix|vector>\"\x0a\
");

static string strStt2("\x0a\
::using slice array -- modification by 3 elements vector:<start, size, stride>\x0a\
    vector 0,2,4 element  >sf \"vector=<<9>>,vector[<0,3,2>] = <1,2,3>\"\x0a\
                  result  < 1, 0, 2, 0, 3, 0, 0, 0, 0 >\x0a\
    matrix diagonal element by slice >sf \"matrix=[[3]], matrix[<0,3,4>]=<1,2,3>\"\x0a\
        result  < 1, 0, 0 >\x0a\
                < 0, 2, 0 >\x0a\
                < 0, 0, 3 >\x0a\
::repeat with slice parameter and generate vector\x0a\
    generate vector by temporary parameter  >sf \"<<0,4,1 @t | t^2>>\"\x0a\
         result < 0, 1, 4, 9 >\x0a\
::options         \x0a\
    /s  : silent    /ns: not silent at console\x0a\
    /p N: print digit number\x0a\
    /zs float int:  zero supress, vector size\x0a\
    /pvt float   :  tiny pivot value to invert matrix\x0a\
");
static string strStt3("\x0a\
::embedded functions         \x0a\
        example     >sf !log(1+i)\x0a\
        result      < 0.346574+0.785398i >\x0a\
  basic functions\x0a\
    !sin  !cos  !tan  !sinh !cosh !tanh !exp  !log ---- real/complex parameter\x0a\
    !asin !acos !atan !log10 ---- real parameter only\x0a\
  other functions\x0a\
    !abs:   absolute for each element\x0a\
    !norm:  square root norm\x0a\
    !fft:   Fast Fourier Transformation\x0a\
    !rft:   Reverse Fast Fourier Transformation\x0a\
    !dggr:  dagger for matrix, conjugate for vector and scalar\x0a\
    !image, !real:  get image/real from complex number\x0a\
    !size:  get vector size\x0a\
    !print: print argment string into left side value file and on console\x0a\
    !floor: largest integer value less than parameter\x0a\
    !sign : -1 or 0 or 1:sing value of parameter\x0a\
    !sqrt : square root\x0a\
    !sum  : sum up all vector element\x0a\
    !prdct: product of all vector element\x0a\
    !print(....): print #g .... to file variable\x0a\
");

extern void callCopyRight();
extern char* GetVrfyLibVer(void);

}//namespace kk

#if 0 // object file �����Ƃ��R�����g�A�E�g����
int main(int argc, char** argv)
{
    //cout << "In main at Normal." <<endl;    //debug
    if ( (argc <= 1)
      || (string("/h") == argv[1])
      || (string("/?") == argv[1])
      || (string("/help") == argv[1])
    ){
        kk::callCopyRight();
        cout << "sf version 1.0.  Build::" << kk::GetVrfyLibVer() << endl;
        cout << kk::strStt1 << kk::strStt2 << kk::strStt3 << endl;
        return 0;
    }

    string strArgAt("");
    for(int i=1; i<argc; i++){
        strArgAt += argv[i];
        strArgAt += " ";
    }

    //  
    size_t sztAt = strArgAt.find('#');
    strArgAt = strArgAt.substr(0,sztAt);

    //mtrxCommand(strArgAt);
    //cout << "main argv:" << strArgAt << endl;    //debug
    try{
        kk::ClTmpVar clTmpVarIniAt;
        kk::ClTmpVar::RegistStt("_rt"); //!< readSfIniFile(.) �̒��� sub file ���Ăяo�����Ƃ�����
        kk::readSfIniFile();
        kk::loopCommand(strArgAt, kr kk::clTermRsltValStt);
    }catch(kk::ClRglError* pClRglError){
        cout << "Execption Error at Regular Expression Analysis: " << pClRglError->m_strCst << endl;
        delete pClRglError;
        return 1;
    }catch(kk::ClError* pClError){
        cout << "Execption Error: " << pClError->m_strCst << endl;
        delete pClError;
        return 1;
    }catch(...){
        cout << "We catched unexpected execption." << endl;
        return 1;
    }
    return 0;
}
#endif //0

#endif //DfVrfy


//@@@
//xcopy c:\#####.### a.cpp /y
//cl a.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Zm200 /c

//cl sfMtrx.cpp /ML /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Zm200 /c

//Jacobi.exe for DLL �̂Ƃ��� sfMtrx.obj ���쐬����
//cl sfMtrx.cpp /MDd /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX /Zm200 -I.\ -Ivrf\ /c

// Visual C �ł́A�����g���ăR���p�C������    
//cl a.cpp /ML /W3 /Od /D"DfVC_" /D"DfVC6_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Zm200 /c
    
//gcc a.cpp -I.\ -Ivrf\ -D"DfGcc_" -D"DfVrfy" libstdc++.a

//cl a.cpp /MDd /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Za /Zm200 vrfyMDd.lib

//cl a.cpp /MDd /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Za /Zm200 kreg.lib

//cl a.cpp /MDd /W3 /Od /D"DfVC_" /D"DfDebug" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Za /Zm200 kreg.lib

//���� verifier �������N���Ă��Ȃ��B a testCm.vrf �� action scripts �ɂ����s���ł��Ȃ�

//gcc a.cpp -I.\ -Ivrf\ -D"DfGcc_" -D"DfVrfy" libstdc++.a

//cl sfMtrx.cpp /c /MDd /W3 /Od /D"DfVC_" /D"_CONSOLE" /YX /GX -I.\ -Ivrf\ /Zm200 /c
//lib sfMtrx.obj  childMDd.obj /out:sfMtrxMDd.lib

//link a.obj kernel32.lib user32.lib netapi32.lib vrfyML.lib child.obj
//<-- 2005.01.25 ���ɑウ��
//link a.obj kernel32.lib user32.lib netapi32.lib vrfyML.lib

//copy a.exe sf.exe /v

