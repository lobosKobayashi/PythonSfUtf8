/*   ���̃v���O�����̒��쌠�� kVerifeir Lab ���ь������ۗL���܂��B ���̃v���O������
 * ����Ă����Ȃ��Q�E�������������Ă��A��҂͈�ؐӔC�𕉂��܂���B���̃v���O����
 * ��񎟔z�z���邽�߂ɂ� kVerifeir Lab ���ь����̕����ɂ�鏳����K�v�Ƃ��܂��B
 *   ���̃v���O�������z�z���ꂽ zip �t�@�C�����̂��̂�F�l�ɃR�s�[���ēn�����Ƃ͔F
 * �߂܂����A�l�b�g��ŕs���葽���ɔz�z���邱�Ƃ͂��~�߂��������B
 *
 *    �]�����Ԉꃖ���𒴂��Ă��̃v���O�������g�p����ɂ̓\�t�g�g�p���̎x�������K�v��
 *  ���B�ڍׂ� http://www.nasuinfo.or.jp/FreeSpace/kenji/���Q�Ƃ��邩�A
 *      kenji@nasuinfo.or.jp ���� kverifierlab@yahoo.co.jp\n
 *  �ɂ��q�˂��������B"
 */


#ifndef DfMatrix_H_
#define DfMatrix_H_

#include<kcommon.h>
#include<sfMtrx.h>
#include<assert.h>
#include<algorithm>
#include<iostream>
#include<valarray>
#include<complex>
#include<cmath>

#ifdef DfVrfy
#   include <Verifier.h>
#endif

namespace kk{
// Be cation. At VC6.0, 7.0 you need /Za option at compiling. because we use abs(.)
// and Microsoft limit abs to integer at default without /Za option
// So We define zaAbs(double), szAbs(complex<double> )
static double zaAbs(double dbAg)
{
    if ( dbAg < 0 ){
        return -dbAg;
    }else{
        return dbAg;
    }
}

static double zaAbs(const std::complex<double>& rCplxDbAg )
{
    return sqrt( rCplxDbAg.real() * rCplxDbAg.real()
              + rCplxDbAg.imag() * rCplxDbAg.imag()
           );
}

struct StMatrixError {
  public:
    const std::string m_strCst;
    StMatrixError(const std::string& rStrAg):m_strCst(rStrAg){};
};


template<class T>
void kSwap(kr std::valarray<T>& rSlarAgA, kr std::valarray<T>& rSlarAgB)
{
    std::valarray<T> vlrAt(rSlarAgA);
    rSlarAgA = rSlarAgB;
    rSlarAgB = vlrAt;
}

// Be cation !. argment is not const refference. But if we omit the const then gcc
// can't compile the kSwap template funciton. The slice_array itself is not changed.
template<class T>
void kSwap(kr const std::slice_array<T>& rSlarAgA, kr const std::slice_array<T>& rSlarAgB)
//void kSwap(kr std::slice_array<T>& rSlarAgA, kr std::slice_array<T>& rSlarAgB)
{
    std::valarray<T> vlrAt(rSlarAgA);
    rSlarAgA = std::valarray<T>(rSlarAgB);
    rSlarAgB = vlrAt;
}

template<class T>
void tfVlrPrint(const std::valarray<T>& crVlrAg, size_t sztRowAg = 0)
{
    for ( unsigned i=0; i< crVlrAg.size(); ++i){
        if ( (sztRowAg != 0)
          && (i % sztRowAg == 0)
        ){
            cout << endl;
        }
        //cout << tfGetStrVal(crVlrAg[i]) << " ";
        // if use Galoi field then define cout& operator << (const Galoi element&)
        cout << crVlrAg[i] << " ";
    }
    cout << endl;
}

template<class T>
double tfFindMax(const std::valarray<T>& crVlrAg, size_t& rSztIndexAg)
{
    double dbAt = zaAbs(crVlrAg[0]);
    rSztIndexAg=0;
    for (size_t sztAt=0; sztAt< crVlrAg.size(); ++sztAt){
        if ( dbAt < zaAbs(crVlrAg[sztAt]) ){
            dbAt = zaAbs(crVlrAg[sztAt]);
            rSztIndexAg = sztAt;
        } 
    }
    return dbAt;
}

template<class T>
double tfFindMax(const std::slice_array<T>& crSlarAg, size_t& rSztIndexAg)
{
    std::valarray<T> vlrAt(crSlarAg);
    double dbAt = zaAbs(vlrAt[0]);
    rSztIndexAg=0;
    for (size_t sztAt=0; sztAt< vlrAt.size(); ++sztAt){
        if ( dbAt < zaAbs(vlrAt[sztAt]) ){
            dbAt = zaAbs(vlrAt[sztAt]);
            rSztIndexAg = sztAt;
        } 
    }
    return dbAt;
}

//!inner_product(.) can't use slice_array(.) argment
//! because mulInvertedL/U(.) use teporary 
template<class T>
T productInner(const std::valarray<T> crVlrAgA, const std::valarray<T> crVlrAgB)
{
    assert(crVlrAgA.size() == crVlrAgB.size() );
    if ( crVlrAgA.size() == 0){
        return 0;
    }

    std::valarray<T> vlrAt(crVlrAgA);
    vlrAt *= crVlrAgB;
    return vlrAt.sum();
}

// if sztAg defalt value == 0 then matrix*vector multiply operation is executed
template<class T> std::valarray<T>
mulMatrix(const std::valarray<T>& crVlrMatrixAgL
        , const std::valarray<T>& crVlrMatrixAgR, size_t sztAg=0)
{
    if ( sztAg == 0){
        sztAg = crVlrMatrixAgR.size();
    }
    assert( sztAg > 0);
    assert( crVlrMatrixAgL.size() != 0);
    assert( crVlrMatrixAgR.size() != 0);
    assert( crVlrMatrixAgL.size() % sztAg == 0);
    assert( crVlrMatrixAgR.size() % sztAg == 0);

    const size_t  cSztColAt = crVlrMatrixAgL.size() / sztAg;
    const size_t  cSztRowAt = crVlrMatrixAgR.size() / sztAg;
    const size_t  cSztAt = cSztColAt * cSztRowAt;

    std::valarray<T> vlrAt( cSztAt );
    int inDebugAt;
    for(size_t i=0; i<cSztAt; ++i){
        inDebugAt = sztAg*(i/cSztRowAt);
        vlrAt[i] = productInner(
            std::valarray<T>(crVlrMatrixAgL[slice(sztAg*(i/cSztRowAt), sztAg, 1)])
           ,std::valarray<T>(crVlrMatrixAgR[slice(i%cSztRowAt, sztAg, cSztRowAt)])
        );
    }
    return vlrAt;
} 

template<class T>
void mulInvertedL(const std::valarray<T>& crVlrMtrxAg, std::valarray<T>& rVlrVctAg)
{
    size_t sztAt = rVlrVctAg.size();
    assert( crVlrMtrxAg.size() == sztAt * sztAt );
    //cout << "in:" << tfGetStrVal(rVlrVctAg) << endl;
    //std::valarray<T> vlrAt(rVlrVctAg);
    // start from i==1, because rVlrVctAg[0] is invariant
    for ( size_t i=1; i<sztAt; ++i){
        //cout << "rVlrVctAg[i] " << rVlrVctAg[i] << endl;    //to debug
        //assert( crVlrMtrxAg[ i + i*sztAt ] == 1);
        //cout << "(rVlrVctAg[slice(0,i,1)]) " << tfGetStrVal(std::valarray<T>(rVlrVctAg[slice(0,i,1)]) ) << endl; // to debug
        // changed rVlrVctAg[i] is used in productInner( , rVlrVctAg..) at i+1
        rVlrVctAg[i] = rVlrVctAg[i]
                -   kk::productInner(
                          std::valarray<T>(crVlrMtrxAg[slice(i*sztAt,i,1)])
                        , std::valarray<T>(rVlrVctAg[slice(0,i,1)])
                    );  // max length is sztAt-1
        //cout << "crVlrMtrxAg[slice(i*sztAt,i,1)] " << tfGetStrVal(std::valarray<T>(crVlrMtrxAg[slice(i*sztAt,i,1)]) ) << endl; //to debug
        //cout << "rVlrVctAg[i] " << rVlrVctAg[i] << endl;    //to debug
    }
    //cout << "out:" << tfGetStrVal(rVlrVctAg) << endl; // to debug
}

template<class T>
void mulInvertedU(const std::valarray<T>& crVlrMtrxAg, std::valarray<T>& rVlrVctAg)
{
#if 0   //03.04.15 to debug
    T tAt;
    size_t sztAt = rVlrVctAg.size();
    assert( crVlrMtrxAg.size() == sztAt * sztAt );
    // start from i==1, because rVlrVctAg[0] is invariant
    size_t i=sztAt-1; 
    tAt = crVlrMtrxAg[ i + i*sztAt ];
    tAt = (rVlrVctAg[i] /= crVlrMtrxAg[ i + i*sztAt ]);
    while( i != 0 ){      // Cation! size_t is unsigned int and don't becom negative
        --i;
        assert( crVlrMtrxAg[ i + i*sztAt ] != T(0));
        rVlrVctAg[i] = 
                (tAt = rVlrVctAg[i] 
                -   kk::productInner(
                          std::valarray<T>(crVlrMtrxAg[slice(i+1+i*sztAt,sztAt-1-i,1)])
                        , std::valarray<T>(rVlrVctAg[slice(i+1,sztAt-1-i,1)])
                    ) );
        tAt = (rVlrVctAg[i] /= crVlrMtrxAg[ i + i*sztAt ]);
    }

#else
    size_t sztAt = rVlrVctAg.size();
    assert( crVlrMtrxAg.size() == sztAt * sztAt );
    // start from i==1, because rVlrVctAg[0] is invariant
    size_t i=sztAt-1; 
    rVlrVctAg[i] /= crVlrMtrxAg[ i + i*sztAt ];
    while( i != 0 ){      // Cation! size_t is unsigned int and don't becom negative
        --i;
        assert( crVlrMtrxAg[ i + i*sztAt ] != T(0));
        //! xn-i = (yn-i - xn*��n-i,n ... - xn-i+1*��n-2,n-i+1) /��n-2,n-2
        rVlrVctAg[i] = rVlrVctAg[i] 
                -   kk::productInner(
                          std::valarray<T>(crVlrMtrxAg[slice(i+1+i*sztAt,sztAt-1-i,1)])
                        , std::valarray<T>(rVlrVctAg[slice(i+1,sztAt-1-i,1)])
                    );
        //! (�t n-i�s��,x)/ ��n-i,n-i
        rVlrVctAg[i] /= crVlrMtrxAg[ i + i*sztAt ];
    }
#endif
}

template<class T>
T tfDeterminant(const std::valarray<T>& crVlrAg)
{
    int inSignAt = 1;
    T tDeterminantAt;
    size_t sztRowAt = static_cast<size_t>( pow(crVlrAg.size(),0.5) );
    kAssert( "tfDeterminant(.) needs squared crVlrAg size", crVlrAg.size() == sztRowAt * sztRowAt);
    std::valarray<T> vlrAgAt(crVlrAg);

    {for (size_t i=0; i<sztRowAt; ++i){
        //std::cout << "debug:" << tfGetStrVal(vlrAgAt) << endl;
        if ( zaAbs(vlrAgAt[sztRowAt*i + i]) <= GetTinyPivot()){
            // find max row and exchange
            size_t j=i+1;
            double dbDummyAt = zaAbs(vlrAgAt[i+i*sztRowAt]);
            size_t sztDummyIndexAt = i;
            for (; j<sztRowAt; ++j){
                if ( zaAbs(vlrAgAt[i+j*sztRowAt]) > dbDummyAt ){
                    dbDummyAt = zaAbs(vlrAgAt[i+j*sztRowAt]);
                    sztDummyIndexAt = j;
                }
            }
            if ( (sztDummyIndexAt == i)
              && (dbDummyAt == 0)
            ){
                tDeterminantAt = T(0);
                return tDeterminantAt;
            }
            //swap i and row line
            std::valarray<T> vlrTempAt(vlrAgAt[slice(i*sztRowAt,sztRowAt,1)]);
            vlrAgAt[slice(i*sztRowAt,sztRowAt,1)] 
                    = std::valarray<T>(vlrAgAt[slice(sztDummyIndexAt*sztRowAt,sztRowAt,1)]);
            vlrAgAt[slice(sztDummyIndexAt*sztRowAt,sztRowAt,1)] = vlrTempAt;
            inSignAt *= -1;
        }
        for ( size_t k=i+1; k<sztRowAt; ++ k){
            vlrAgAt[slice(k*sztRowAt,sztRowAt,1)] = 
                std::valarray<T>(vlrAgAt[slice(k*sztRowAt,sztRowAt,1)]) -
                (vlrAgAt[i+k*sztRowAt]/vlrAgAt[i+i*sztRowAt])* std::valarray<T>(vlrAgAt[slice(i*sztRowAt,sztRowAt,1)]);
        }
    }}

    // calculate determinant
    tDeterminantAt = vlrAgAt[0];
    for (size_t i=1; i<sztRowAt; ++i){
        tDeterminantAt *= vlrAgAt[i + i*sztRowAt];
    }
    tDeterminantAt *= inSignAt;
    return tDeterminantAt;
}

template<class T>
class TcCrout{
  //private:
  public:
    size_t m_sztRow;
    std::valarray<T> m_vlrT;    // copy of operated matrix and exchanged by pivot
    std::valarray<T> m_vlrU;
    std::valarray<T> m_vlrL;
    //T                m_determinantT;

    enum EnmState{ EnInitial = 0, EnLessThanMinPivot, EnDecomposed, EnInverted } m_enState;
    std::valarray<int> m_vlrInExchanged; // 0... m_sztRow �܂ł� pivoit �u�����ʂ��c��

    //std::valarray<double> m_vlrDbPivot;
    std::valarray<T> m_vlrDbPivot;

  public:
    // coding lefted. Enable to set other matrix again
    TcCrout(void){}
    TcCrout(const std::valarray<T>& crVlrAg):m_enState(EnInitial)
    {
        SetMatrixLU(crVlrAg);
    }

#if 0
    // tfDeterminant(.) �����g���B�s�񎮂͋t�s��Ƃ͓Ɨ����ėL��ׂ�
    //! Calculate determinatn using Gauss Elimination
    void determinant(void)
    {
        int inSignAt = 1;
        for (size_t i=0; i<m_sztRow; ++i){
            //std::cout << "debug:" << tfGetStrVal(m_vlrT) << endl;
            if ( m_vlrT[i] == T(0)){
                //m_vlrT[i] == T(0) �̂Ƃ��͊���Ȃ��̂ő|���o�������g���Ȃ��B�� 0 �s�Ɠ���ւ��� 
                // find non 0 row and exchange
                size_t j=i+1;
                for (; j<m_sztRow; ++j){
                    if ( m_vlrT[i+j*m_sztRow] != T(0)){
                        break;
                    }
                }
                if ( j== m_sztRow){
                    m_determinantT = T(0);
                    return;
                }
                //swap i and row line
                valarray<T> vlrTempAt(m_vlrT[slice(i*m_sztRow,m_sztRow,1)]);
                m_vlrT[slice(i*m_sztRow,m_sztRow,1)] = valarray<T>(m_vlrT[slice(j*m_sztRow,m_sztRow,1)]);
                m_vlrT[slice(j*m_sztRow,m_sztRow,1)] = vlrTempAt;
                inSignAt *= -1;
            }
            for ( size_t k=i+1; k<m_sztRow; ++ k){
                m_vlrT[slice(k*m_sztRow,m_sztRow,1)] = 
                    valarray<T>(m_vlrT[slice(k*m_sztRow,m_sztRow,1)]) -
                    (m_vlrT[i+k*m_sztRow]/m_vlrT[i+i*m_sztRow])* valarray<T>(m_vlrT[slice(i*m_sztRow,m_sztRow,1)]);
            }
        }

        // calculate determinant
        m_determinantT = m_vlrT[0];
        for (size_t i=1; i<m_sztRow; ++i){
            m_determinantT *= m_vlrT[i + i*m_sztRow];
        }
        m_determinantT *= inSignAt;
    }
#endif
    void SetMatrixLU(const std::valarray<T>& crVlrAg)
    {
        //m_determinantT = T(0);
        m_vlrT.resize(crVlrAg.size());
        m_vlrT = crVlrAg;

        m_sztRow = static_cast<size_t>( static_cast<float>(pow(m_vlrT.size(),0.5)));
        //m_sztRow = (int)sqrt(m_vlrT.size()); //ambiguous call to overloaded function
        assert( m_vlrT.size() == m_sztRow * m_sztRow); 
        m_vlrInExchanged.resize(m_sztRow);
        //size_t i;
        {for (size_t i=0; i<m_sztRow; ++i){
            m_vlrInExchanged[i] = i;
        }}
        m_vlrU.resize(m_vlrT.size(),0);
        m_vlrDbPivot.resize(m_sztRow,0);
        m_vlrL.resize(m_vlrT.size(),0);

        size_t sztAt=0;
        std::valarray<T> vlrLAt(0., m_sztRow); // coding lefted complex �Ŏg���Ȃ�
        std::valarray<T> vlrUAt(0., m_sztRow);
        {for (size_t i=0; i<m_sztRow; ++i){
            //cout << "debug: "<<tfGetStrVal( std::valarray<T>(m_vlrT[slice(i*m_sztRow, m_sztRow,1)]) )<< endl; //debug
            m_vlrDbPivot[i] = tfFindMax(m_vlrT[slice(i*m_sztRow, m_sztRow,1)],kr sztAt);
        }}

        std::valarray<T> vlrTempAt(m_sztRow);
        {for (size_t i=0; i<m_sztRow; ++i){
            //!    vlrTempAt[j] 
            //!      ��������          
            //!  �`00��   0��........ 0
            //!  �`10���`11��........ 0
            //!  �`20���`21��........ 0
            //!  �`30���`31��........ 0
            //!   .  �� .  ��    .    .
            //!  �`n0��A n1��  ..     1
            //!      ��������          
            vlrTempAt[slice(0,i,1)] = T(0);
            vlrTempAt[slice(i,m_sztRow-i,1)]
                    = std::valarray<T>(m_vlrT[slice(i+i*m_sztRow,m_sztRow-i, m_sztRow)]);
        
            //!<A HREF="Crout.txt#calculate m_vlrL column">
            //cout << tfGetStrVal(vlrTempAt) << endl; //to debug
            {for ( size_t j=0;j<m_sztRow; ++j){
                if ( j < i){
                    vlrLAt[j] = T(0);
                }else{
                    //cout << tfGetStrVal(std::valarray<T>(m_vlrL[slice(j*m_sztRow, m_sztRow,1)])) <<"m_vlrL[slice]"<< endl;  //to debug
                    //cout << tfGetStrVal(std::valarray<T>(m_vlrU[slice(i,m_sztRow,m_sztRow)])) <<"m_vlrU[slice]"<< endl;  //to debug
                    vlrLAt[j] 
                    = vlrTempAt[j] 
                        -   kk::productInner(
                                  std::valarray<T>(m_vlrL[slice(j*m_sztRow, m_sztRow,1)])
                                , std::valarray<T>(m_vlrU[slice(i,m_sztRow,m_sztRow)])
                            );
                }
            }}

            //!<A HREF="Crout.txt#Select Pivot for Column vector A*m_vlrDbPoint">
            vlrTempAt = vlrLAt * m_vlrDbPivot;
            if ( fabs (tfFindMax(vlrTempAt,kr sztAt) ) <= GetTinyPivot()){
                m_enState = EnLessThanMinPivot;
                return;
            }
            //cout << "vlrAt:" << tfGetStrVal(vlrLAt) << endl;  //to debug
            T dbAt = vlrLAt[sztAt];
            vlrLAt /= dbAt;
            //cout << "vlrAt:" << tfGetStrVal(vlrLAt) << endl;  //to debug
            m_vlrL[slice(i,m_sztRow, m_sztRow)] = vlrLAt;
            if ( i != sztAt ){
                kSwap( kr m_vlrT[slice(i*m_sztRow, m_sztRow, 1)]
                     , kr m_vlrT[slice(sztAt*m_sztRow, m_sztRow, 1)]
                );
                kSwap( kr m_vlrL[slice(i*m_sztRow, m_sztRow, 1)]
                     , kr m_vlrL[slice(sztAt*m_sztRow, m_sztRow, 1)]
                );
                swap(kr m_vlrDbPivot[i], kr m_vlrDbPivot[sztAt]);
                swap(kr m_vlrInExchanged[i], kr m_vlrInExchanged[sztAt]);
            }


            //!<A HREF="Crout.txt#Calculate m_vlrU Row">
            vlrTempAt[slice(0,i,1)]=T(0);
            vlrTempAt[slice(i,m_sztRow-i,1)]
                    = std::valarray<T>(m_vlrT[slice(i+i*m_sztRow, m_sztRow-i,1)]);

            //cout << tfGetStrVal(vlrTempAt)<<":vlrTempAt" << endl;       //to debug
            //cout << tfGetStrVal(std::valarray<T>(m_vlrL[slice(i*m_sztRow, m_sztRow,1)]) )<<"m_vlrT[slice]]" << endl;    //to debug
            {for ( size_t j=0;j<m_sztRow; ++j){
                if ( j<i){
                    vlrUAt[j] = T(0);
                }else{
                    vlrUAt[j] 
                    = vlrTempAt[j] 
                        -   kk::productInner(
                                  std::valarray<T>(m_vlrL[slice(i*m_sztRow, m_sztRow,1)])
                                , std::valarray<T>(m_vlrU[slice(j,m_sztRow,m_sztRow)])
                            );  
                    //cout << "vlrUAt[j]:" << vlrUAt[j] << endl; //to debug
                }
            }}

            m_vlrU[slice(i*m_sztRow, m_sztRow, 1)] = vlrUAt;
            //cout << endl;         // to debug
            //cout << "m_vlrU" ;   // to debug
            //tfVlrPrint(m_vlrU,m_sztRow); // to debug
            //cout << endl;         // to debug
            //cout << "m_vlrL" ;   // to debug
            //tfVlrPrint(m_vlrL,m_sztRow); // to debug


            //tfVlrPrint(m_vlrT,m_sztRow);    // to debug
            //cout << tfGetStrVal(vlrLAt) << endl; //to debug
        }}
        m_enState = EnDecomposed;
    }


    //! A^-1*vector �̂Ƃ��� default szt �������g��
    //! ���ʂ� ���o�͕ϐ� rVlrAg �ɐݒ肷��
    //! m_vlrInExchanged �ɂ����͗v�f�̓���ւ����Ăяo�����ōs���B
    //! MulCrout ���ł͌��� m_sztRow �ȊO�ɂȂ��x�N�g���̓���ւ����ł��Ȃ��B
    void MulCrout( std::valarray<T>& rVlrAg, size_t sztRowAg = 1)
    {
        kAssert( "MulCrout(.) needs sztRowAg >=1.", sztRowAg >= 1);
        kAssert( "MulCrout(.) needs same m_sztRow and rVlrAg column.", m_sztRow == rVlrAg.size() / sztRowAg );
    
        //cout << "debug m_vlrL:" << tfGetStrVal(m_vlrL) << endl; // to debug
        //cout << "debug m_vlrU:" << tfGetStrVal(m_vlrU) << endl; // to debug
        //cout << "debug m_vlrInExchanged:" << tfGetStrVal(m_vlrInExchanged) << endl; // to debug

        size_t sztColumnAt = rVlrAg.size() / sztRowAg;
        std::valarray<T> vlrAt( sztColumnAt );
        for (size_t i=0; i<sztRowAg; ++i){
            vlrAt = std::valarray<T>( rVlrAg[slice(i, sztColumnAt, sztRowAg)] );
            //cout << "debugA:" << tfGetStrVal(vlrAt) << endl; // to debug
            mulInvertedL(m_vlrL, kr vlrAt);
            //cout << "debugA:" << tfGetStrVal(vlrAt) << endl;  // to debug
            //cout << "debugVlrU:" << tfGetStrVal(m_vlrU) << endl;//to debug
            mulInvertedU(m_vlrU, kr vlrAt);
            //cout << "debugB:" << tfGetStrVal(vlrAt) << endl;      // to debug
            //for ( size_t j=0; j<sztColumnAt; ++j){
            //    rVlrAg[i+j*sztRowAg] = vlrAt[ m_vlrInExchanged[j] ];
            //}
            rVlrAg[slice(i, sztColumnAt, sztRowAg)] = vlrAt;
        }
    }
    
    //! Invert m_vlrT from m_vlrU and m_vlrL and m_vlrInExchanged
    //! inverted m_vlrT data has been exchaged by m_vlrInExchanged
    void MakeInverse(void )
    {
        if ( m_enState == EnInverted ){
            kAssert("TcCrout has too small determinant.We can't calculate negative power:**-.", 0);
        }else if ( m_enState == EnDecomposed ){
            std::valarray<T> vlrIdentityMtrxAt( T(0), m_sztRow * m_sztRow );
            {
                for(size_t i=0; i<m_sztRow; ++i){
                    vlrIdentityMtrxAt[i*m_sztRow + m_vlrInExchanged[i] ] = T(1);
                    //vlrIdentityMtrxAt[m_vlrInExchanged[i]*m_sztRow + i ] = T(1);
                }
            }
            //vlrIdentityMtrxAt[slice(0,m_sztRow, m_sztRow+1)] = valarray<T>(T(1),m_sztRow);

            m_vlrT.resize(m_sztRow * m_sztRow );
            for (size_t i=0; i<m_sztRow; ++i){
                std::valarray<T> vlrAt(vlrIdentityMtrxAt[slice(i, m_sztRow, m_sztRow)]);
                //valarray<T> vlrAt(T(0), m_sztRow);
                //vlrAt[m_vlrInExchanged[i]] = T(1);
                //cout << "vlrAt:" << tfGetStrVal(vlrAt) << endl;      // to debug
                MulCrout( kr vlrAt);
                //cout << "MakeInverse:vlrAt:" << tfGetStrVal(vlrAt) << endl;      // to debug
                m_vlrT[slice(i, m_sztRow, m_sztRow)] = vlrAt;
            }
            m_enState = EnInverted;
        }else{
            // (m_enState == EnLessThanMinPivot ) || 
            kAssert("TcCrout has too small pivot value.We can't calculate matrix inverse.", false);
        }
    }

#ifdef DfVrfy
    void SetLUBuffer(const std::string& crStrAg)
    {
        std::valarray<T> vlrAt;
        tfSet<T>(crStrAg, kr vlrAt);
        SetMatrixLU(vlrAt);
    }
    void Register(ClTestVct* pClAg, const std::string& crStrAg)
    {
        tfRgstVerified(pClAg
            , tfNewVfClFnctnSpl(this, &TcCrout<T>::SetLUBuffer, crStrAg+".SetMatrixLU") );
        tfRgstVerified(pClAg, tfNewVfCntnr(m_vlrT, crStrAg+".m_vlrT") );
        tfRgstVerified(pClAg, tfNewVfCntnr(m_vlrL, crStrAg+".m_vlrL") );
        tfRgstVerified(pClAg, tfNewVfCntnr(m_vlrU, crStrAg+".m_vlrU") );
        tfRgstVerified(pClAg, tfNewVfCntnr(m_vlrInExchanged, crStrAg+".m_vlrInExchanged") );
        tfRgstVerified(pClAg, tfNewVfCntnr(m_vlrDbPivot, crStrAg+".m_vlrDbPivot") );
        tfRgstVerified(pClAg, tfNewVerified(m_inSign, crStrAg+".m_enSign") );
#ifdef debugX
        tfRgstVrfyUsr(pClAg, *(string*)this, crStrAg+".Matched");      //-0
        tfRgstVrfyUsr(pClAg, m_strPostMatched, crStrAg+".PostMatched");  //-1
        tfRgstVrfyUsr(pClAg, m_strPreMatched, crStrAg+".PreMatched");   //-2
        tfRgstVrfyUsr(pClAg, m_strTraversed, crStrAg+".Traversed");    //-3
        tfRgstFnctnStr(pClAg, this, &ClRegularString::SetRegularString
                , crStrAg+".SetRegularString");    //-3
#endif // debugX
    }
#endif  // DfVrfy
};

}   // namespace kk
#if DebugX
#endif


#endif  // DfMatrix_H_
