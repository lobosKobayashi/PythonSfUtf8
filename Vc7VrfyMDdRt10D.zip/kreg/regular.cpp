/*   ���̃v���O�����̒��쌠�� kVerifeir Lab ���ь������ۗL���܂��B ���̃v���O������
 * ����Ă����Ȃ��Q�E�������������Ă��A��҂͈�ؐӔC�𕉂��܂���B���̃v���O����
 * ��񎟔z�z���邽�߂ɂ� kVerifeir Lab ���ь����̕����ɂ�鏳����K�v�Ƃ��܂��B
 *   ���̃v���O�������z�z���ꂽ zip �t�@�C�����̂��̂�F�l�ɃR�s�[���ēn�����Ƃ͔F
 * �߂܂����A�l�b�g��ŕs���葽���ɔz�z���邱�Ƃ͂��~�߂��������B
 *
 *    �]�����Ԉꃖ���𒴂��Ă��̃v���O�������g�p����ɂ̓\�t�g�g�p���̎x�������K�v��
 *  ���B�ڍׂ� http://www.nasuinfo.or.jp/FreeSpace/kenji/���Q�Ƃ��邩�A
 *      kenji@nasuinfo.or.jp ���� kverifierlab@yahoo.co.jp\n
 *  �ɂ��q�˂��������B"
 */

#include <kreg.h>
#include <sstream>
using namespace std;
#include <typeinfo>
namespace kk{
//-----------------Gegeral routne Begin --------------------------
static bool isLessThan(const ksci& crKsciLeftAg, const ksci& crKsciRightAg)
{
    unsigned int wdLeftAt = (unsigned int)&(*crKsciLeftAg);
    unsigned int wdRightAt = (unsigned int)&(*crKsciRightAg);
    return wdLeftAt < wdRightAt;
}

bool overlapMax(ksci& rKsciAg, ksci ksciAg)
{
    if ( (isLessThan(ksciAg , rKsciAg ) || ( rKsciAg == (ksci)0 ))
      && (ksciAg != (ksci)0)
    ){
        // ksciAg �̂ق�������
        rKsciAg = ksciAg;
        return true;
    }else{
        return false;   
    }
}

#if 0
// �Ƃ肠�����ő��v�݂̂�ΏۂƂ���
static bool isGreaterThan(const ksci& crKsciLeftAg, const ksci& crKsciRightAg)
{
    unsigned int wdLeftAt = (unsigned int)&(*crKsciLeftAg);
    unsigned int wdRightAt = (unsigned int)&(*crKsciRightAg);
    return wdLeftAt > wdRightAt;
}
//-------------------------------------------

static bool overlapMin(ksci& rKsciAg, ksci ksciAg)
{
    if ( (isGreaterThan(ksciAg , rKsciAg ) || ( rKsciAg == (ksci)0 ))
      && (ksciAg != (ksci)0)
    ){
        // ksciAg �̂ق����Z��
        rKsciAg = ksciAg;
        return true;
    }else{
        return false;   
    }
}

bool ClRegularString::IsMaxLengthMatch(void)
{
    //99.08.31 code lefted until V1.1
    return true;
    //return m_pfOverlap == overlapMax;
}
#endif
void ClRegularString::PutMax_MinLengthMatchStt(bool blMaxAg)
{
#if 0
    m_vctApClPrimitiveRgl �S�Ă̗v�f�ɑ΂��Đݒ肷��K�v������
    if (blMaxAg){
        m_pfOverlap = overlapMax;
    }else{
        m_pfOverlap = overlapMin;
    }
#endif
}


void throwRglError(const string& rStrAg)
{
    throw new ClRglError(rStrAg);
}
//-----------------Gegeral routne End --------------------------

//------------------- ClRepeator class Beginning --------------------

ClPrimitiveRgl::~ClPrimitiveRgl()
{
    //cout << m_strRgl << endl;   //debug
}
void ClPrimitiveRgl::SetRepeator(ksci& rKsciAg)
{
    switch ( getChar(rKsciAg) ){
        case _T('?'):{
            m_blForward = true;
            rKsciAg++;
            break;
        }
        case _T('+'):{
            m_blBack = true;
            rKsciAg++;
            break;
        }
        case _T('*'):{
            m_blBack = true;
            m_blForward = true;
            rKsciAg++;
        }
        default:{}
    }
}


ksci ClPrimitiveRgl::ShiftFeedback(ksci ksciForwardAg)
{
    Overlap(m_ksciInput, ksciForwardAg);

    ksci ksciOutAt = m_ksciOutput;
    if ( (!(m_ksciOutput == (ksci)0) ) && m_blBack ){
        Overlap(kr m_ksciInput, m_ksciOutput);
    }

    if ( m_blForward ){
        // ������ m_ksciInput �� m_blForward �ł��̂܂ܑ��邱�Ƃ͂ł��Ȃ�
        // ���ԃ��[�v�ɂȂ�B m_ksciInput �� IsMatch() �̔���ő���
        Overlap(kr ksciOutAt, ksciForwardAg);
    }
    m_ksciOutput = (ksci)0;

    return ksciOutAt;
}

// m_blForward �ɂ��J�ڂ��]������
void ClPrimitiveRgl::TransferChForward( ksci ksciAg)
{
    kchar chAt = getChar(ksciAg);
    if ( IsMatched(chAt) ){
        m_ksciOutput = m_ksciInput;
    }
    m_ksciInput=(ksci)0;
    return;
}


//------------------- ClRepeator class End --------------------

//------------------- ClPrimitiveRgl class Begin --------------------

ClPrimitiveRgl::ClPrimitiveRgl(kc kstring& crStrAg
            , bool(*pfOverlapAg)(ksci& , ksci)  )
    :m_strRgl(crStrAg), m_blForward(false), m_blBack(false)
    ,m_pfOverlap(pfOverlapAg)
{}

void ClPrimitiveRgl::InitializeKsci(void)
{
    m_ksciInput = (ksci)0;
    m_ksciOutput = (ksci)0;
}

//------------------- ClPrimitiveRgl class End -----------------------

//------------- \s \S \d �Ȃǂ� �ʂ� Regular mathing class Begin ---------
ClPerlPrmtv* ClPerlPrmtv::MakePerlPrmtv(kchar chRglAg, kchar chFirstAg = _T('`') )
{
    assert( (chFirstAg == _T('`')) || (chFirstAg == _T('\\')) );
    assert( (chRglAg == _T('d')) || (chRglAg == _T('D')) 
         || (chRglAg == _T('s')) || (chRglAg == _T('S')) 
         || (chRglAg == _T('w')) || (chRglAg == _T('W')) 
    );


    kstring strAt(_T(""));
    strAt += chFirstAg;
    strAt += chRglAg;

    ClPerlPrmtv* pClPrimitiveRglAt;
    switch(chRglAg){
        case _T('d'):
        case _T('D'):{
            pClPrimitiveRglAt = new ClNumberPrmtv( strAt );
            break;
        }
        case _T('s'):
        case _T('S'):{
            pClPrimitiveRglAt = new ClWhiteSpacePrmtv( strAt );
            break;
        }
        case _T('w'):
        case _T('W'):{
            pClPrimitiveRglAt = new ClAlphaNumPrmtv( strAt );
            break;
        }
        // default �͔������Ȃ�
    }
    return pClPrimitiveRglAt;
}

ClNumberPrmtv::ClNumberPrmtv(kc kstring& crStrAg)
        : ClPerlPrmtv(crStrAg)
{
    assert( (crStrAg == _T("\\d")) || (crStrAg == _T("\\D")) 
        ||  (crStrAg == _T("`d")) || (crStrAg == _T("`D")) 
    );
    m_blNumber = (crStrAg == _T("\\d")) || (crStrAg == _T("`d")) ;
}

bool ClNumberPrmtv::IsMatched (kchar chAg)
{
    return  ((chAg >= '0') && (chAg <= '9' ) )
           ^ (!m_blNumber);
}

ClWhiteSpacePrmtv::ClWhiteSpacePrmtv(kc kstring& crStrAg)
    : ClPerlPrmtv(crStrAg)
{
    assert( (crStrAg == _T("\\s")) || (crStrAg == _T("\\S"))
        ||  (crStrAg == _T("`s")) || (crStrAg == _T("`S")) 
     );
    m_blWhiteSpace = (crStrAg == _T("\\s")) || (crStrAg == _T("`s"));
}

bool ClWhiteSpacePrmtv::IsMatched (kchar chAg)
{
    return  ( (chAg == _T(' ') )
           || (chAg == _T('\t') )
           || (chAg == _T('\n') )
           || (chAg == _T('\r') )
            )
           ^ (!m_blWhiteSpace);
}

ClAlphaNumPrmtv::ClAlphaNumPrmtv(kc kstring& crStrAg)
    : ClPerlPrmtv(crStrAg)
{
    assert( (crStrAg == _T("\\w")) || (crStrAg == _T("\\W")) 
        ||  (crStrAg == _T("`w")) || (crStrAg == _T("`W")) 
    );
    m_blAlphaNum = (crStrAg == _T("\\w")) || (crStrAg == _T("`w"));
}

bool ClAlphaNumPrmtv::IsMatched (kchar chAg)
{
    return  ( ( (chAg >= _T('0') ) && (chAg <= _T('9')) )
           || ( (chAg >= _T('A') ) && (chAg <= _T('Z')) )
           || ( (chAg >= _T('a') ) && (chAg <= _T('z')) )
           || (chAg == _T('_') )
            )
           ^ (!m_blAlphaNum);
}

bool Cl1CharPrm::IsMatched (kchar chAg)
{
    if ( m_blIgnoreCapitalSmall 
      && (  (('A' <= chAg ) && ( chAg <= 'Z'))
         || (('a' <= chAg ) && ( chAg <= 'z'))
         )
    ){
        return (m_inCode | 0x20) == (chAg | 0x20);
    }else{
        return m_inCode == (ku)chAg;
    }
}

ClSquareBrPrm::~ClSquareBrPrm()
{
    m_vctCh.erase(
            m_vctCh.begin(), m_vctCh.end() );
    m_vctPairRange.erase(
            m_vctPairRange.begin(), m_vctPairRange.end() );
    //cout << "m_vctpClPerlPrmtv.size();" << m_vctpClPerlPrmtv.size() << endl; //debug
    DfEachLoop(vector<ClPerlPrmtv*>::const_iterator, m_vctpClPerlPrmtv){
        delete *pm_vctpClPerlPrmtv_;
    }
    m_vctpClPerlPrmtv.erase(
            m_vctpClPerlPrmtv.begin(), m_vctpClPerlPrmtv.end() );
}

// rKsciAg �͖߂�Ƃ��A�Ō�Ƀ`�F�b�N�����������w���B`d... �Ȃ�� d ���w��
// d �̎��̕����ňʒu�͂Ȃ��BgetEscHatCharacter() ���Ăяo��������
// incrementKsci(.) �����s����
// `xnm �̂Ƃ��� nm �����R�[�h�� rChNowAg �ɐݒ肵�� rKsciAg �� m ���w��
// `,\ �Ŏn�܂�Ȃ����ʂ̕����̂Ƃ��́ArChNowAg �� rKsciAg ���w���l�����ɂȂ�B
// ���̂Ƃ��ArKsciAg �͕ω����Ȃ�
// \D,\d \S,\s, \W,\w �̂Ƃ� rBlDdSsWwAg == true �ɂȂ��ĕԂ�
void  ClSquareBrPrm::getEscHatCharacter(
        bool& rBlDdSsWwAg, kchar& rChNowAg, ksci& rKsciAg)
{
    kchar chAt= getChar(rKsciAg);
    if ( (chAt == '\\') || (chAt == '`')  ){
        rKsciAg=incrementKsci(rKsciAg);
        kchar chSecondAt;
        static string strDdSsWsStt("DdSsWw");
        if ( (chSecondAt=getChar(rKsciAg)) == _T('x') ){
            //\X61 �� X61 �ɓ���
            kstring strHexNumAt(_T("0123456789ABCDEFabcdef"));
            string strAt("0x");
            //rKsciAg=incrementKsci(rKsciAg);
            while(findFirstOf(strHexNumAt,getChar(incrementKsci(rKsciAg)))
                        != strHexNumAt.end() 
            ){ 
                // *rKsciAg �� _T("0123456789ABCDEFabcdef") �̕����Ɍ��肳���
                rKsciAg=incrementKsci(rKsciAg);
                strAt += *rKsciAg;
            }

            if ( strAt.size() == 2){
                rBlDdSsWwAg = false;
                rChNowAg = _T('x');
            }else{
                int inAt;
                istringstream iStrmAt(strAt);
                iStrmAt >> hex >> inAt;
                rChNowAg =(kchar)inAt;
                rBlDdSsWwAg = false;
            }
        }else if ( strDdSsWsStt.end() 
                !=  findFirstOf(strDdSsWsStt, chSecondAt )
        ){
                //[dDsSwW] �̕�����ł���BShift Jis �ł͂Ȃ�
                //rKsciAg++;   //`[dDsSwW] �����̎����w��
                m_vctpClPerlPrmtv.push_back(ClPerlPrmtv::MakePerlPrmtv(chSecondAt, chAt));
//                         ka<ClPerlPrmtv>(ClPerlPrmtv::MakePerlPrmtv(chSecondAt, chAt)) );

                rBlDdSsWwAg = true;
                rChNowAg = 0;
        }else{
            rBlDdSsWwAg = false;
            rChNowAg = getChar(rKsciAg);
        }
    }else{
        rBlDdSsWwAg = false;
        rChNowAg = chAt;
    }
}

bool ClSquareBrPrm::IsMatched(kchar chAg)
{
    // ���ʂ̒P�ƕ����̑��݂𒲂ׂ�
    DfEachLoop(vector<kchar>::const_iterator, m_vctCh){
        if ( m_blIgnoreCapitalSmall 
          && (  (('A' <= chAg ) && ( chAg <= 'Z'))
             || (('a' <= chAg ) && ( chAg <= 'z'))
             )
        ){
            if ((*pm_vctCh_ | 0x20) == (chAg | 0x20) ){
                return true ^ m_blCaret;
            }
        }else{
            if (*pm_vctCh_ == (ku)chAg ){
                return true ^ m_blCaret;
            }
        }
    }
    
    // alphabet/number�ȊO�� \[ �⊿���Ȃǂ̕�����͈͂𒲂ׂ�
    // alphabet �łȂ��̂ŁAm_blIgnoreCapitalSmall ���`�F�b�N���Ȃ�
    vector< pair<kchar, kchar> >::const_iterator pm_vctPairRange_;
    for( pm_vctPairRange_ = m_vctPairRange.begin();
         pm_vctPairRange_ != m_vctPairRange.end(); pm_vctPairRange_++){
        
        if ( (pm_vctPairRange_->first <= chAg) 
          && (pm_vctPairRange_->second >= chAg) 
        ){
            return true ^ m_blCaret;
        }

        if ( m_blIgnoreCapitalSmall ){
            kchar chAt;
            //invert capita<-->small chracter
            if ( ( _T('A') <= chAg ) && ( chAg <= _T('Z')) ){
                chAt = chAg | 0x20; // make small character
            }else if ( (_T('a') <= chAg ) && ( chAg <= _T('z')) ){
                chAt = chAg & ~0x20;    // make Capital character
            }

            if ( (pm_vctPairRange_->first <= chAt) 
              && (pm_vctPairRange_->second >= chAt) 
            ){
                return true ^ m_blCaret;
            }
        }
    }
    // \d,\D \s.\S \w,\W �� perl ���K�\�������𒲂ׂ�
    DfEachLoop(vector< ClPerlPrmtv* >::const_iterator, m_vctpClPerlPrmtv){
        if ( (*pm_vctpClPerlPrmtv_)->IsMatched(chAg) ){
            return true;
        }
    }
    return m_blCaret;
}

void ClSquareBrPrm::MakeRglExprssnElement(void)
{
    ksci ksciAt = m_strRgl.begin();
    
    if (getChar(ksciAt) == _T('^') ){
        m_blCaret = true;
        ksciAt++;
    }

    for(; ksciAt < m_strRgl.end(); ksciAt=incrementKsci(ksciAt)){
        bool blDdSsWwAt;
        kchar chNowAt;
        getEscHatCharacter(kr blDdSsWwAt, kr chNowAt, kr ksciAt);
        //cout << m_strRgl << endl; //debug
        
        if ( blDdSsWwAt ){
            continue;
        }else if ( ( (ksciAt + 2) < m_strRgl.end()) && (getChar( incrementKsci(ksciAt))) == _T('-') ){
            // detect range string
            pair<kchar, kchar> pairAt;
            pairAt.first = chNowAt;
            // ��� getChar( incrementKsci(ksciAt)) �ł� ksciAt ���ω����Ȃ�
            ksciAt = incrementKsci(ksciAt);
            ksciAt = incrementKsci(ksciAt);

            kchar chSecondAt;
            getEscHatCharacter(kr blDdSsWwAt, kr chSecondAt, kr ksciAt);

            if ( blDdSsWwAt ){
                throwRglError( "range second is Perl dDsSwW:" + m_strRgl );
            }else if ( chNowAt > chSecondAt ){
                string strAt("");
                strAt += chNowAt;
                strAt += " is greater than ";
                strAt += chSecondAt;
                throwRglError( strAt );
            }

            pairAt.second = chSecondAt;
            m_vctPairRange.push_back(pairAt);
        }else{
            m_vctCh.push_back( chNowAt);
        }
        //cout << "*ksciAt:" << *ksciAt << endl; //debug
        //cout << "chaNowAt:" << chNowAt << endl; //debug
    
    }
}
//------------- \s \S \d �Ȃǂ� �ʂ� Regular mathing class End ---------

//------------------- ClParenticRgl class Begin --------------------
void ClParenticRgl::InitializeKsci(void)
{
    ClPrimitiveRgl::InitializeKsci();
    m_blDetectMatchInput = false;
    m_blDetectMatchOutput = false;
    m_ksciOutArrived = (ksci)0;

    DfEachLoop(list<vector<ClPrimitiveRgl*>* >::iterator
            , m_lstpVctpClPrimitiveRgl){
        vector<ClPrimitiveRgl*>* pVctpClPrimitiveAt
            = *pm_lstpVctpClPrimitiveRgl_;
        
        DfEachLoopPtr(vector<ClPrimitiveRgl*>::iterator
                , pVctpClPrimitiveAt){

            (*ppVctpClPrimitiveAt_)->InitializeKsci();
        }
    }
}

ClParenticRgl::ClParenticRgl(kc kstring& crStrAg, ClRegularString* pClRegularStringAg)
        : ClPrimitiveRgl(crStrAg), m_ksciNfaFirst(0),m_ksciNfaLast(0), m_strMatched("")
        , m_pClRegularString(pClRegularStringAg)
        , m_blDetectMatchInput(false) , m_blDetectMatchOutput(false)
{
    //m_VctpClParenticRgl.push_back(this);
}

static ksci findIfStPaired(ksci ksciFirstAg, ksci ksciLastAg, StPaired& rStParedAg)
{
    ksci cStrItrRightParenticAt = ksciFirstAg;
    while(cStrItrRightParenticAt != ksciLastAg ){
        if ( rStParedAg(getChar(cStrItrRightParenticAt) )
        ){
            break;
        }
        cStrItrRightParenticAt = incrementKsci(cStrItrRightParenticAt);
    }
    return cStrItrRightParenticAt;
}


ClPrimitiveRgl* ClParenticRgl::makeSquareBracketRgl(ksci& rKsciNowAg)
{
    // �����ɗ����Ƃ� m_ksci �� '[' �̈ʒu�ɂ���
    StPaired stPairedAt( _T('['), _T(']'));
    kstring::const_iterator cStrItrRightSquareAt 
            = findIfStPaired(rKsciNowAg, m_strRgl.end() , kr stPairedAt );
//            = find_if((kstring::const_iterator)rKsciNowAg
//            , (kstring::const_iterator)m_strRgl.end() , StPaired( _T('['), _T(']')) );
    if ( cStrItrRightSquareAt == m_strRgl.end() ){
        throwRglError("Square Bracket is not paired");
    }

    ClSquareBrPrm* pClPrimitiveRglAt;
    pClPrimitiveRglAt = new ClSquareBrPrm(kstring(rKsciNowAg+1,cStrItrRightSquareAt) );
    pClPrimitiveRglAt->MakeRglExprssnElement();
    rKsciNowAg = cStrItrRightSquareAt;
    return pClPrimitiveRglAt;
}

ClPrimitiveRgl* ClParenticRgl::makeParenticBracketRgl(
        ksci& rKsciNowAg, ClRegularString* pClRegularStringAg)
{
    // �����ɗ����Ƃ� ksciNowAt �� '(' �̈ʒu�ɂ���
    StPaired stPairedAt( _T('('), _T(')'));
    ksci cStrItrRightParenticAt = 
        findIfStPaired(rKsciNowAg, m_strRgl.end() , kr stPairedAt );

    if ( cStrItrRightParenticAt == m_strRgl.end() ){
        throwRglError(m_strRgl+":Parentic Bracket is not paired");
    }else if ( (cStrItrRightParenticAt - rKsciNowAg) < 2){
        throwRglError("Parentic Bracket has no character");
    }

    ClParenticRgl* pClParenticRglAt;
    pClParenticRglAt = new ClParenticRgl(
            kstring(rKsciNowAg+1,cStrItrRightParenticAt), pClRegularStringAg );
    pClParenticRglAt->MakeRglExprssnElement(pClRegularStringAg);
    pClParenticRglAt->InitializeKsci();
    rKsciNowAg = cStrItrRightParenticAt;
    return pClParenticRglAt;
}

ClPrimitiveRgl* ClParenticRgl::makeEscHatCharRgl(ksci& rKsciNowAg, kchar chAg)
{
    // �����ɗ����Ƃ� rKsciNowAg �� \ �̈ʒu�ɂ���
    // \ �̎��̕����𒲂ׂ�
    ClPrimitiveRgl* pClPrimitiveRglAt;
    kc kstring cStrAbnormalAt(_T("dDsSwWx"));
    
    rKsciNowAg++;
    string strAt("");
    strAt += chAg;
    ksci ksciAt =  findFirstOf(cStrAbnormalAt,getChar(rKsciNowAg) );
    if ( ksciAt == cStrAbnormalAt.end() ){
        // makeEscapedCharRgl(.) ���Ăяo�����Ƃ���'\'==*rKsciNowAg 
        // �ł��� dDsSwWxtnr != *(rKsciNowAg+1)
        kchar chAt = getChar(rKsciNowAg);
        strAt += chAt;
        pClPrimitiveRglAt = new Cl1CharPrm( strAt, chAt);
        //pClPrimitiveRglAt = new Cl1CharPrm( 
        //        kstring(rKsciNowAg,incrementKsci(rKsciNowAg) ) );
    }else{
        //99.09.27 rKsciNowAg++;   // '\'<-- ���� \ �ł͂Ȃ� dDsSwW �̉��ꂩ���w���Ă���
        // *rKsciNowAg �� dDsSwWxtnr �̉��ꂩ�ł���
        //99.09.27 switch (*rKsciNowAg++)
        strAt += *rKsciNowAg;
        switch (*rKsciNowAg){
            case _T('d'):
            case _T('D'):{
                pClPrimitiveRglAt = new ClNumberPrmtv( strAt );
                break;
            }
            case _T('s'):
            case _T('S'):{
                //99.09.27 pClPrimitiveRglAt = new ClWhiteSpacePrmtv( kstring(rKsciNowAg-2,rKsciNowAg) );
                pClPrimitiveRglAt = new ClWhiteSpacePrmtv( strAt );
                break;
            }
            case _T('w'):
            case _T('W'):{
                pClPrimitiveRglAt = new ClAlphaNumPrmtv( strAt );
                break;
            }
            case _T('x'):{
                kstring strHexNumAt(_T("0123456789ABCDEFabcdef"));
                kstring strAt(_T("\\x"));
//                kstring strHexAt(_T("0x"));
                kstring strHexAt(_T(""));
                ksci ksciNextAt = rKsciNowAg + 1;
                   if ( findFirstOf(strHexNumAt, getChar(ksciNextAt) ) 
                            == strHexNumAt.end()
                ){
                    // \x �̎��� hex ���l�łȂ����� \x �� 'x' ������\���Ɖ��߂���
                    pClPrimitiveRglAt = new Cl1CharPrm(strAt, _T('x'));
                    break;
                }
                
                // *rKsciNowAg �� 0123456789ABCDEFabcdef �̉��ꂩ�ł���
                rKsciNowAg = ksciNextAt;
                strAt += *rKsciNowAg;
                strHexAt += *rKsciNowAg;
                ksciNextAt = rKsciNowAg + 1;
                if ( findFirstOf(strHexNumAt,getChar(ksciNextAt) ) != strHexNumAt.end()){
                    // �񌅂� hex ���l�\��
                    rKsciNowAg = ksciNextAt;
                    strAt += *rKsciNowAg;
                    strHexAt += *rKsciNowAg;
#ifdef DfSjisString
                    ksciNextAt = rKsciNowAg + 1;
                    if ( findFirstOf(strHexNumAt,getChar(ksciNextAt) ) 
                                != strHexNumAt.end()
                    ){
                        // �O���� hex ���l�\��
                        rKsciNowAg = ksciNextAt;
                        strAt += *rKsciNowAg;
                        strHexAt += *rKsciNowAg;
                        ksciNextAt = rKsciNowAg + 1;
                        if ( findFirstOf(strHexNumAt,getChar(ksciNextAt) ) 
                                    != strHexNumAt.end()
                        ){
                            // �l���� hex ���l�\��
                            rKsciNowAg = ksciNextAt;
                            strAt += *rKsciNowAg;
                            strHexAt += *rKsciNowAg;
                        }
                    }
#endif //DfSjisString
                }
                int inAt;
                istringstream iStrmAt(strHexAt);
                iStrmAt >> hex >> inAt;
                pClPrimitiveRglAt = new Cl1CharPrm(strAt, inAt);
                break;
            }
            default:{
                assert(0);  // �����ɂ͗��Ȃ�
            }
        }
            
    }
    //pClPrimitiveRglAt->SetRepeator(rKsciNowAg);
    return pClPrimitiveRglAt;
}

ClPrimitiveRgl* pClPrimitiveRglDebugStt;
int inSizeDebugStt;
void ClParenticRgl::MakeRglExprssnElement(ClRegularString* pClRegularStringAg)
{
    m_blFrontCaret = false;
    m_blRearDollar = false;
    if ( m_strRgl[0] == _T('^') ){
        // �s������n�܂镶�����T�����K�\���ł���
        m_blFrontCaret = true;
        m_strRgl = m_strRgl.substr(1, m_strRgl.size()-1);
    }
    // SJIS �ł� crStrRglAg.end()-1 �ł͍Ō�̕����ɂȂ�Ȃ�
    if (m_strRgl.size() &&  (getLastChar(m_strRgl) == _T('$')) ){
        // �s���ŏI��镶�����T�����K�\���ł���
        m_blRearDollar = true;
        m_strRgl = m_strRgl.substr(0, m_strRgl.size()-1);
    }

    kstring::const_iterator ksciNowAt = m_strRgl.begin();

    ClPrimitiveRgl* pClPrimitiveRglAt;
    //abnormal character
    vector<ClPrimitiveRgl*>* pVctpClPrimitiveRglAt
            = new vector<ClPrimitiveRgl*>;
    // save in ClParenticRgl::m_lstApVctpClPrimitiveRgl
    m_lstpVctpClPrimitiveRgl.push_back(pVctpClPrimitiveRglAt );
    pClRegularStringAg->SaveParenticRgl(this);
    pClRegularStringAg->SaveApPrimitiveRgl(this);  //!!!!030221
    kc kstring cStrAbnormalAt(_T("+?*|$^`") );
    kc kstring cStrRightBracket(_T("\x29]"));   //")]"

    while ( ksciNowAt <  m_strRgl.end() ){
        kchar chAt = getChar(ksciNowAt);
        //m_lstpClPrimitiveRgl.push_back((ClPrimitiveRgl*)0);

        if ( chAt == _T('(') ){
            // parenthesis bracket
            // ClRegularString::m_vctApClPrimitiveRgl �ɓ�d�o�^���Ȃ��悤��
            // _T('(') �̂Ƃ�����ʈ�������BpClPrimitiveRglAt �� repeator 
            // �ݒ�ɕK�v�ł���B
            pClPrimitiveRglAt = makeParenticBracketRgl(
                    kr ksciNowAt,  pClRegularStringAg);
        }else{
            if ( chAt == _T('[') ){
                pClPrimitiveRglAt = makeSquareBracketRgl( kr ksciNowAt );
            }else if ( chAt == _T('`') ){
                pClPrimitiveRglAt = makeEscHatCharRgl( kr ksciNowAt,_T('`') );
            }else if ( chAt == _T('\\') ){
#ifdef DfVC_
                pClPrimitiveRglAt = makeEscHatCharRgl( kr ksciNowAt,_T('\\') );
#elif defined(DfGcc_)
                pClPrimitiveRglAt = makeEscHatCharRgl( kr ksciNowAt, 0x5c /* \ */ );
#endif
            }else if ( chAt == _T('.') ){
                pClPrimitiveRglAt = new ClDotPrm();
            }else if ( findFirstOf( cStrRightBracket, chAt) != cStrRightBracket.end() ){
                throwRglError("Abnormal \x29 or ] character");
            }else if ( findFirstOf( cStrAbnormalAt, chAt) != cStrAbnormalAt.end() ){
                throwRglError("Abnormal +?*|$^` character in " + m_strRgl);
            }else{
                //�P���Ȉꕶ���ł���
                kchar chAt = getChar(ksciNowAt);
                string strAt;
                strAt += chAt;
                pClPrimitiveRglAt = new Cl1CharPrm(strAt, chAt);
            }
            pClRegularStringAg->SaveApPrimitiveRgl(pClPrimitiveRglAt);
        }
        ksciNowAt = incrementKsci(ksciNowAt);
        if ( ksciNowAt <  m_strRgl.end() ){
            pClPrimitiveRglAt->SetRepeator( kr ksciNowAt );
        }
        pVctpClPrimitiveRglAt->push_back(pClPrimitiveRglAt);

        if ( getChar(ksciNowAt) == _T('|') ){
            pVctpClPrimitiveRglAt = new vector<ClPrimitiveRgl*>;
            m_lstpVctpClPrimitiveRgl.push_back( pVctpClPrimitiveRglAt );
            // *ksciNoAt == '|' �ł���
            ksciNowAt++;
        }
    }
}


// feed back, feed foward �̗������܂ރÑJ�ڂ����s����
ksci ClParenticRgl::ShiftFeedback(ksci ksciForwardAg)
{
    if ( m_blDetectMatchInput &&  (ksciForwardAg != (ksci)0) ){
        // (...) �̒��O�܂œ��B�ł��� ksci �̏W�������߂�B
        m_pClRegularString->CallbackInput();
    }

    Overlap(kr m_ksciInput,ksciForwardAg);

    // ksciOutAt �͎��� m_ksciInput �ɓn���f�[�^�����グ��B
    ksci ksciLineOutputAt = (ksci)0;
    DfEachLoop(list<vector<ClPrimitiveRgl*>* >::iterator
                                    , m_lstpVctpClPrimitiveRgl ){
        vector<ClPrimitiveRgl*>* pVctpClPrimitiveRglAt
                        = *pm_lstpVctpClPrimitiveRgl_;
        // TransferChForward(.) ���I����Ă���Am_blFrontCaret==true �̂Ƃ��́A�����ւ�
        // m_ksciInput �� shift �͍s���Ă͂Ȃ�Ȃ�
        if ( m_blFrontCaret ){
            ksciLineOutputAt = (ksci)0;
        }else{
            ksciLineOutputAt = m_ksciInput;
        }
        DfEachLoopPtr(vector<ClPrimitiveRgl*>::iterator
                                    , pVctpClPrimitiveRglAt ){
            ksciLineOutputAt = 
                    (*ppVctpClPrimitiveRglAt_)->ShiftFeedback(ksciLineOutputAt);
        }
        
        if ( !(ksciLineOutputAt == (ksci)0)){
            ksci ksciAt = incrementKsci(ksciLineOutputAt);
            if ( !m_blRearDollar || m_pClRegularString->m_ksciEnd == ksciAt ){
                Overlap(kr m_ksciOutput, ksciLineOutputAt);
            }
        }
    }

    if ( m_blForward ){  //!< 03.03.17 ���̂R�s��ǉ�
        Overlap(kr m_ksciOutput, m_ksciInput); 
    }
    // shift �����I����Ă���Am_ksciInput �ւ� feedback �������s��
    if ( m_blBack ){
        Overlap(kr m_ksciInput, m_ksciOutput); // "hxi38b4y"/ "(i|`d)*" == "" �ɂȂ�
    }

    if ( m_blDetectMatchOutput && ( ksciLineOutputAt != (ksci)0) ){ //03.04.01 3 �s��ǉ�
        m_pClRegularString->CallbackOutput();
    }
    m_ksciOutArrived  = m_ksciOutput;
    m_ksciOutput = (ksci)0;

    return m_ksciOutArrived;
}

// IsMatched(chAg) == true �Ȃ�΁Am_ksciInput �� m_ksciOutput �Ɉڂ�
void ClParenticRgl::TransferChForward( ksci ksciAg)
{
    kchar chAt = getChar(ksciAg);
    if ( m_blDetectMatchInput && !(m_ksciInput==(ksci)0) ){
        // (`d)+ �Ȃ� ClParentic �̃��s�[�g�𓞒B ksci �Ɋ܂߂�
        // ## "23" / "(=)?(.*)" % 2== "23"---------- 2003 01 16
        m_pClRegularString->CallbackInput();
    }

    ksci ksciOutputAt = (ksci)0;   // detect output from inner element
    DfEachLoop(list<vector<ClPrimitiveRgl*>* >::iterator
            , m_lstpVctpClPrimitiveRgl){
        vector<ClPrimitiveRgl*>* pVctpClPrimitiveAt
                = *pm_lstpVctpClPrimitiveRgl_;
        if ( pVctpClPrimitiveAt->size() > 0){
//            cout << (*pVctpClPrimitiveAt)[1]->m_strRgl << ": "
//                 << *((*pVctpClPrimitiveAt)[1]->m_ksciInput) << endl; // to debug 03.02.22
            if ( !m_blFrontCaret || m_pClRegularString->m_ksciBegin == ksciAg ){
                Overlap(kr pVctpClPrimitiveAt->front()->m_ksciInput,m_ksciInput);
            }
            DfEachLoopPtr( vector<ClPrimitiveRgl*>::iterator
                    , pVctpClPrimitiveAt){
                (*ppVctpClPrimitiveAt_)->TransferChForward(ksciAg);
            }
            ksci ksciBackAt = pVctpClPrimitiveAt->back()->GetKsciOutput();
            
            if ( !(ksciAg == (ksci)0)){
                ksci ksciAt = incrementKsci(ksciAg);
                if ( !m_blRearDollar || m_pClRegularString->m_ksciEnd == ksciAt ){
                    Overlap(kr ksciOutputAt, ksciBackAt);
                    Overlap(kr m_ksciOutput, ksciBackAt);
                }
            }
        }
    }

    // Overlap �ł͏�肭�����Ȃ��Ƃ�������B��납��A���傫��
    // ksci ���������邱�Ƃ�����
//    if ( m_blDetectMatchOutput && ( m_ksciOutput != 0) ){
    // ����ʉ߂��Ă������̂Ɍ��肷�邽�� m_ksciOutput �ł͂Ȃ� ksciOutputAt ���g��
    if ( m_blDetectMatchOutput && !(ksciOutputAt == (ksci)0) ){
        m_pClRegularString->CallbackOutput();
    }
    m_ksciInput = (ksci)0;
    return;
}

kstring& ClParenticRgl::GetMatchedString(void)
{
    return m_strMatched;
}

void ClParenticRgl::ClearKsciFirstLast(void)
{
    m_ksciNfaFirst = m_ksciNfaLast = (ksci)0;
}

void ClParenticRgl::IgnoreCapitalSmall(bool blAg)
{
    DfEachLoop(list<vector<ClPrimitiveRgl*>* >::iterator
                                    , m_lstpVctpClPrimitiveRgl ){
        vector<ClPrimitiveRgl*>* pVctpClPrimitiveRglAt
                    = *pm_lstpVctpClPrimitiveRgl_;
        DfEachLoopPtr( vector<ClPrimitiveRgl*>::iterator
                                    , pVctpClPrimitiveRglAt ){
            (*ppVctpClPrimitiveRglAt_)->IgnoreCapitalSmall(blAg);
        }
    }
}

// �Ō�̗v�f��Ԃ��Bm_lstpVctpClPrimitiveRgl �̍Ō�̗v�f�� m_blFoward �����Ƃ���
// ���� m_ksciInput �� override ����
ksci ClParenticRgl::GetOutArrived(void)
{
    if ( !(m_ksciOutArrived == (ksci)0) ){
        return m_ksciOutArrived;
    }
    
    ksci ksciAt=(ksci)0;
    DfEachLoop(list<vector<ClPrimitiveRgl*>* >::iterator
                                    , m_lstpVctpClPrimitiveRgl ){
        vector<ClPrimitiveRgl*>* pVctpClPrimitiveRglAt
                        = *pm_lstpVctpClPrimitiveRgl_;
        if (pVctpClPrimitiveRglAt->back()->m_blForward ){
            Overlap(kr ksciAt, pVctpClPrimitiveRglAt->back()->m_ksciInput);
        }
    }
    return ksciAt;
}

//------------------- ClParenticRgl class End --------------------

//------------------- ClRegularString class Begin --------------------
ClParenticRgl::~ClParenticRgl()
{
    DfEachLoop( list< vector<ClPrimitiveRgl* >* >::iterator, m_lstpVctpClPrimitiveRgl ){
        delete *pm_lstpVctpClPrimitiveRgl_;
    }

    m_lstpVctpClPrimitiveRgl.erase(m_lstpVctpClPrimitiveRgl.begin(), m_lstpVctpClPrimitiveRgl.end());
}

void ClRegularString::EraseAllParenticPrimitiveInstance(void)
{
    DfEachLoop( vector<ClPrimitiveRgl* >::iterator, m_vctpClPrimitiveRgl ){
        delete *pm_vctpClPrimitiveRgl_;
    }
    m_vctpClPrimitiveRgl.erase(
            m_vctpClPrimitiveRgl.begin(), m_vctpClPrimitiveRgl.end() );
    m_VctpClParenticRgl.erase(
            m_VctpClParenticRgl.begin(), m_VctpClParenticRgl.end() );
}

void ClRegularString::SaveParenticRgl(ClParenticRgl* pClParenticRglAg)
{
    m_VctpClParenticRgl.push_back(pClParenticRglAg);
}

void ClRegularString::SaveApPrimitiveRgl(ClPrimitiveRgl* pClPrimitiveRglAg)
{
    m_vctpClPrimitiveRgl.push_back(pClPrimitiveRglAg);
#ifdef DfVrfyKreg_
        pClPrimitiveRglDebugStt = pClPrimitiveRglAg;
#endif //DfVrfyKreg_
        inSizeDebugStt = m_vctpClPrimitiveRgl.size();


}

ClRegularString::ClRegularString(const kstring& crStrRglAg
            , EnCpapitalSmall enAg )
        : m_strRgl(crStrRglAg), m_strTraversed("")
{
    kstring strAt = crStrRglAg;

    EraseAllParenticPrimitiveInstance();
    
    m_pClParenticRgl = new ClParenticRgl(strAt, this);
    m_pClParenticRgl->MakeRglExprssnElement(this);
    m_pClParenticRgl->InitializeKsci();
    // ClearKsciFirstLast() ���Ȃ��ƁA���ڂ� FlowNfa()
    if ( enAg == EnIgnoreSmall ){
        m_pClParenticRgl->IgnoreCapitalSmall(true);
    }
}


ClRegularString::~ClRegularString()
{
    EraseAllParenticPrimitiveInstance();
}

void ClRegularString::InitializeKsci(void)
{
    //ClPrimitiveRgl::InitializeAllClPrimitiveRgl();
    if (m_pClParenticRgl != 0){
        m_pClParenticRgl->InitializeKsci();
    }
}

void ClRegularString::ClearKsciFirstLast(void)
{
    // return value void ���g���Ȃ��̂� StP �ɂ���
    struct StP{ 
        static void p(ClParenticRgl* pClParenticRglAg){
        pClParenticRglAg->ClearKsciFirstLast();
    }};
    for_each(m_VctpClParenticRgl.begin(), m_VctpClParenticRgl.end()
            ,StP::p );
}

void ClRegularString::SetRegularString(kc kstring& crStrAg)
{
    if ( m_strRgl != crStrAg ){
        InitializeKsci();
        m_ksciFirstMatchReserved = (ksci)0;
        m_strPreMatched = _T("");
        m_strPostMatched = _T("");
        m_ksciMatchEnded = (ksci)0;
        ClearKsciFirstLast();
        *(string*)this = "";
        //99.12.02 refference cout ���듮�삵�āAcrStrAg.begin() ������
        //�����I�� m_strRgl �͐V�������������m�ۂ������̂ɂ�����
        //m_strRgl = crStrAg; 
#ifdef DfVC_
        m_strRgl = string(crStrAg.begin(), crStrAg.end());
#else
        m_strRgl = (string)crStrAg;
#endif

        kstring strAt = crStrAg;
        m_strTraversed = "";
    
        EraseAllParenticPrimitiveInstance();
        
        m_pClParenticRgl = new ClParenticRgl(strAt, this);
        m_pClParenticRgl->MakeRglExprssnElement(this);
        m_pClParenticRgl->InitializeKsci();
    }
}

ksci ClRegularString::GetKsciMatchedBegin(int inParNumAg)
{
    if (m_ksciFirstMatchReserved == (ksci)0){
        throwRglError("There is no matched strings!");
        return (ksci)0;   // damie to avoid warning C4715
    }else{
        assert( inParNumAg >= 0);
        if ( inParNumAg == 0){
            return m_ksciFirstMatchReserved;
        }else{
            operator %(inParNumAg);
            return m_VctpClParenticRgl[inParNumAg]->GetKsciMatchedBegin();
        }
    }
}

ksci ClRegularString::GetKsciMatchedEnd(int inParNumAg)
{ 
    if (m_ksciFirstMatchReserved == (ksci)0){
        throwRglError("There is no matched strings!");
        return (ksci)0;   // damie to avoid warning C4715
    }else{
        assert( inParNumAg >= 0);
        if ( inParNumAg == 0){
            return m_ksciMatchEnded;
        }else{
            operator %(inParNumAg);
            return m_VctpClParenticRgl[inParNumAg]->GetKsciMatchedEnd();
        }
    }
}

size_t ClRegularString::GetSztMatchedBegin(int inParNumAg)
{
    kAssert("Parameter of GetSztMatchedBegin(.) is negative.", inParNumAg >=0);
#ifndef DfGcc_
    // gcc �ł� != operator ���Ȃ�
    kAssert("There is no checked string.", m_ksciBegin != 0);
#endif
    if ( inParNumAg == 0 ){    // normal matched
        return (size_t)&*m_pClParenticRgl->GetKsciMatchedBegin()
                - (size_t)&*m_ksciBegin;
    }else{
        if ( m_VctpClParenticRgl[inParNumAg]->m_ksciNfaFirst == (ksci)0 ){
            // �܂�����������𖢌��o�̂Ƃ��� inParNumAg �܂ł� (..) �}�b�`����������o����
            FindParenticString(inParNumAg);
        }
        return (size_t)&*m_VctpClParenticRgl[inParNumAg]->GetKsciMatchedBegin()
                - (size_t)&*m_ksciBegin;
    }
}

size_t ClRegularString::GetMatchedSize(int inParNumAg)
{
    kAssert("Parameter of GetMatchedSize(.) is negative.", inParNumAg >=0);
#ifndef DfGcc_
    kAssert("There is no checked string.", m_ksciBegin != 0);
#endif
    if ( inParNumAg == 0 ){    // normal matched
        return (size_t)&*m_pClParenticRgl->GetKsciMatchedEnd()
             - (size_t)&*m_pClParenticRgl->GetKsciMatchedBegin();
    }else{
        if ( m_VctpClParenticRgl[inParNumAg]->m_ksciNfaFirst == (ksci)0 ){
            // �܂�����������𖢌��o�̂Ƃ��� inParNumAg �܂ł� (..) �}�b�`����������o����
            FindParenticString(inParNumAg);
        }
        return (size_t)&*m_VctpClParenticRgl[inParNumAg]->GetKsciMatchedEnd()
             - (size_t)&*m_VctpClParenticRgl[inParNumAg]->GetKsciMatchedBegin();
    }
}



// �Œ���v�ł̃}�b�`���O���o�����s���Ă��Ȃ�
void ClRegularString::Traverse(const kstring& crStrSentenceAg)
{
    //99.12.02 refference cout ���듮�삵�āAcrStrAg.begin() ������
    //�����I�� m_strTraversed �͐V�������������m�ۂ������̂ɂ�����
    //m_strTraversed = crStrSentenceAg; 
    //<-- 03.03.21 m_strTraversed �𐳋K�\���}�b�`���o��������Ƃ��ɗ����悤�ɕύX����
    //    Vc6.0 �ł͏�̖�肪�ĔR����\��������H
    m_ksciBegin = crStrSentenceAg.begin();
    m_ksciEnd   = crStrSentenceAg.end();
#ifdef DfVC_
    m_strTraversed = string(crStrSentenceAg.begin(),crStrSentenceAg.end());
#else
    m_strTraversed = (string)crStrSentenceAg; 
#endif
    InitializeKsci();
    m_ksciFirstMatchReserved = (ksci)0;
    m_strPreMatched = _T("");
    m_strPostMatched = _T("");
    m_ksciMatchEnded = (ksci)0;

    ClearKsciFirstLast();
    // �ꕶ�������������� ksciBeforeMatchReservedAt �̓}�b�`���O�̊J�n�ʒu���L�^����B
    ksci ksciBeforeMatchReservedAt = (ksci)0;
    // "<.*>" �̐��K�\���� "<<>x>f �̂悤�ɁA��x�}�b�`���O���r�؂ꂽ��ɁA������x
    // �}�b�`���O������̍Ō�����o���邽�߁AksciLasttMatchReservedAt �� ksciAt ��
    // �O��̒l����ς�������Ƃ����o����Ƃ��Ɏg��
    ksci ksciLastMatchReservedAt = (ksci)0;
    ksci ksciOutAt = (ksci)0;     // hold m_pClParenticRgl->GetOutArrived()
    ksci pcrStrSentenceAt_;
    for ( pcrStrSentenceAt_ = crStrSentenceAg.begin();
          pcrStrSentenceAt_ < crStrSentenceAg.end();
        pcrStrSentenceAt_ = incrementKsci(pcrStrSentenceAt_)
    ){  
        m_pClParenticRgl->SetDfaInAndShift(pcrStrSentenceAt_);
        m_pClParenticRgl->TransferChForward( pcrStrSentenceAt_ );
        m_pClParenticRgl->ShiftFeedback((ksci)0);
        ksciOutAt = m_pClParenticRgl->GetOutArrived();

        // 99.07.19 code lefted �ő��v�����L�q���Ă��Ȃ�
        if ( (ksciBeforeMatchReservedAt != (ksci)0) 
           &&( isLessThan( ksciBeforeMatchReservedAt, ksciOutAt)
             ||(ksciOutAt == (ksci)0)
             )
        ){
            //�ŏ��̍ō��Œ���v�̘A�����j�ꂽ�B

            //break;    // �Œ���v�̂Ƃ��� break �����Ă͂����Ȃ��B
            //�Œ���v�ł́A�����ƒ��������񂪁A��ł��ǂ蒅�����Ƃ�����
            if ( ( (m_ksciFirstMatchReserved == (ksci)0 )
                 || (m_ksciFirstMatchReserved >= ksciBeforeMatchReservedAt)
                 )
            ){
                // ���߂ă}�b�`���������񂪌�������
                m_ksciFirstMatchReserved = ksciBeforeMatchReservedAt;
                m_ksciMatchEnded = pcrStrSentenceAt_;
            }
        }
        
        if (ksciOutAt == (ksci)0 ){
            ksciBeforeMatchReservedAt = (ksci)0;
        }else{
            if ( (ksciBeforeMatchReservedAt == (ksci)0 )
              || !isLessThan(ksciBeforeMatchReservedAt, ksciOutAt )
            ){
                ksciLastMatchReservedAt = ksciOutAt;
            }
            ksciBeforeMatchReservedAt = ksciOutAt;
        }
    }

    if ( (    (m_ksciMatchEnded == (ksci)0)
           && (ksciBeforeMatchReservedAt != (ksci)0) )
         //!< �ŏ��Ƀ}�b�`���O���Ă���A������̍Ō�܂Ń}�b�`�𑱂����B
      || (    (m_ksciFirstMatchReserved >= ksciBeforeMatchReservedAt)
           && (ksciOutAt != (ksci)0) )
         //!< "0ab" / "0|0ab" == "0ab" ---22------ 2003 03 01 �Œ���v�ɂȂ�ׂ��΍�
         //! ��둤�� ClParenticRgl("0ab") ���ŁAend �܂Ń}�b�`���Ă���
    ){
        
        m_ksciFirstMatchReserved = ksciBeforeMatchReservedAt;
        m_ksciMatchEnded = pcrStrSentenceAt_;
    }

    if ( m_ksciFirstMatchReserved != (ksci)0){
        *(string*)this = kstring(m_ksciFirstMatchReserved, m_ksciMatchEnded);
        m_strPreMatched = kstring( m_ksciBegin
                , m_ksciFirstMatchReserved );
        m_strPostMatched =  string( m_ksciMatchEnded
            , m_ksciEnd );
    }else{
        m_strPreMatched = m_strTraversed;
    }

    m_pClParenticRgl->m_ksciNfaFirst = m_ksciFirstMatchReserved;
    m_pClParenticRgl->m_ksciNfaLast = m_ksciMatchEnded;
    m_pClParenticRgl->m_strMatched = *(string*)this;
    
}


void ClRegularString::CallbackInput(void)
{
    // CallbackInput(.) �� TransferChForward( kchar chAg) ��
    // ShiftFeedback(ksci ksciForwardAg) �̓������Ă΂��
    if ( (m_vctKsciStarted.back() != m_ksciFlowed) && (m_ksciFlowed != (ksci)0) ){
        m_vctKsciStarted.push_back(m_ksciFlowed);
    }
}

void ClRegularString::CallbackOutput(void)
{
    if ( m_ksciFlowed != (ksci)0 ){
        m_vctKsciEnded.push_back(m_ksciFlowed);
    }
}

bool ClPrimitiveRgl::SetDfaInAndShift( ksci ksciAg, bool blAffectAg)
{
    return blAffectAg && Overlap(kr m_ksciInput, ksciAg ) && m_blForward;
}

//blAffectAg �����͕s�K�v�����A��肠�����c�����܂܂ɂ���B2004.09.27
bool ClParenticRgl::SetDfaInAndShift( ksci ksciAg, bool blAffectAg)
{
    m_ksciOutArrived = (ksci)0;
    if ( !m_blFrontCaret || m_pClRegularString->m_ksciBegin == ksciAg ){
        Overlap(kr m_ksciInput, ksciAg );
    }else{
        return false;
    }
#if 0
    //03.06.05 v\test.vrf::## "xa" / "^a" == "" ----- 2003 06 05 NG �̑΍�̂��ߏ�� 5 �s�ɕύX����
    if ( !Overlap(kr m_ksciInput, ksciAg ) ){
        return false;
    }
#endif

    // ShiftFeedback(.) �� TransferChForward(.) �ɂ���Ă� m_ksciOutArrived
    // �͋r�F�����
    //  m_lstpVctpClPrimitiveRgl �͕����� pVctpClPrimitiveAt �����B
    // ���̂����̈�ł��Ō�܂� Shift �ł���� blAffectAt == true �ɂȂ�
    bool blAffectAt = false;
    DfEachLoop(list<vector<ClPrimitiveRgl*>* >::iterator
            , m_lstpVctpClPrimitiveRgl){
        vector<ClPrimitiveRgl*>* pVctpClPrimitiveAt
            = *pm_lstpVctpClPrimitiveRgl_;
        
        DfEachLoopPtr(vector<ClPrimitiveRgl*>::iterator
                , pVctpClPrimitiveAt){
            //if ( !(*ppVctpClPrimitiveAt_)->SetDfaInAndShift(ksciAg, blAffectAt) 
            if ( !(*ppVctpClPrimitiveAt_)->SetDfaInAndShift(ksciAg) 
            ){
                goto lbPass;
            }
        }
        blAffectAt = true;
        lbPass:continue;
    }
    
    return m_blForward | blAffectAt;
}

// m_ksciMatchEnded ���O�܂ŕ�������Ȃ����āAksciAg ���Ō�ɓ��B�������Ƃ��m�F����
void ClRegularString::flowInToEnd(ksci ksciAg)
{
    m_ksciFlowed = (ksci)0;
    for (ksci ksciAt = ksciAg; 
        ksciAt < m_ksciMatchEnded;
        ksciAt = incrementKsci(ksciAt)
    ){
        m_pClParenticRgl->ShiftFeedback((ksci)0);     // may push m_ksciFlowed
        m_ksciFlowed = ksciAt;
        m_pClParenticRgl->SetDfaInAndShift((ksci)0);
        m_pClParenticRgl->TransferChForward(ksciAt);// may push m_ksciFlowed
    }
    //return ksciAg == m_pClParenticRgl->GetOutArrived(); // This return value is not used.
}

ksci ClRegularString::DetectFirstReachAtEndForInput(int inParenticNumAg)
{
    InitializeKsci();
    m_vctKsciStarted.erase(
            m_vctKsciStarted.begin(), m_vctKsciStarted.end() );
    m_pClParenticRgl->SetDfaInAndShift(m_ksciFirstMatchReserved);


    ClParenticRgl* pClParenticRglAt = m_VctpClParenticRgl[inParenticNumAg];
    pClParenticRglAt->m_blDetectMatchInput = true;

    // a countermeasure of ## "@abc:" / "@(.*):.*" test $1 01.06.19 begin
    flowInToEnd(m_ksciFirstMatchReserved);
    pClParenticRglAt->m_blDetectMatchInput=false;
    m_pClParenticRgl->ShiftFeedback((ksci)0); //shift without pushing m_ksciFlowed
#if 0
    //03.01.17  GetOutArrived �̍l������ς����̂ŁA���̃R�[�h�͕K�v�Ȃ��Ȃ���
    if ( m_ksciFirstMatchReserved != m_pClParenticRgl->GetOutArrived() ){
    //if ( !flowInToEnd(m_ksciFirstMatchReserved) ){..}
        // flowToEnd �͍ŏI�̏o�͂܂ŗ������Ƃ� Yes ��Ԃ��B
        // "<ol>"/"<ol>(<li>)?(.*)" % 1 ���v�Z�����Ƃ��AflowToEnd()
        // �� false ��Ԃ�
        return m_ksciFirstMatchReserved;
    }
#endif    
    //DfEachLoop(vector<ksci>::const_iterator, m_vctKsciStarted)
    //�ō���v�Ƃ��邽�߂ɋt������T��
    DfEachReverse(vector<ksci>::reverse_iterator, m_vctKsciStarted){
        InitializeKsci();
        m_vctKsciEnded.erase(
                m_vctKsciEnded.begin(), m_vctKsciEnded.end() );
        //ksci& rKsci = *pm_vctKsciStarted_;    //debug 99.11.23
        pClParenticRglAt->m_blDetectMatchOutput = true;
        pClParenticRglAt->SetDfaInAndShift(*pm_vctKsciStarted_);
        // a countermeasure of ## "@abc:" / "@(.*):.*" test $1 01.06.19 begin
        flowInToEnd( *pm_vctKsciStarted_);
        m_pClParenticRgl->ShiftFeedback((ksci)0);
        pClParenticRglAt->m_blDetectMatchOutput = false;
        if ( *pm_vctKsciStarted_ == m_pClParenticRgl->GetOutArrived() ){
            return *pm_vctKsciStarted_;
        }
    }
    //assert(0);
    return (ksci)0;
}

bool ClRegularString::flowOutToEnd(ksci ksciAg)
{
    // m_ksciOutput ���ɗ��Ă���B����� ksciAg �� mathign shift ���I�����
    // ��ł��邱�Ƃ��Ӗ�����B
    ksci ksciAt = incrementKsci(ksciAg); 
    for (;;){
        m_ksciFlowed = ksciAt;
        // �Ō�� ClParenticRgl �v�f�� m_ksciOutput ��ݒ肵���Ƃ�
        // m_ksciOutArrived ��ݒ肳���邽�߂ɁA���� ShiftFeedback(0)
        // �����s������
        m_pClParenticRgl->ShiftFeedback((ksci)0);
        if (ksciAt >= m_ksciMatchEnded ){
            break;
        }
        m_pClParenticRgl->TransferChForward(ksciAt);
        ksciAt = incrementKsci(ksciAt);
    }
    return ksciAg == m_pClParenticRgl->GetOutArrived();
}
ksci ClRegularString::DetectLastReachAtEndForOutput
        (int inParenticNumAg, ksci ksciLasttMatchedAg)
{
    // ���� m_vctKsciEnded �Ƀf�[�^���ݒ肳��Ă���

    ClParenticRgl* pClParenticRglAt = m_VctpClParenticRgl[inParenticNumAg];
//    cout << "m_ksciEnded.size(): " << m_vctKsciEnded.size() 
//        << " 0: " << *m_vctKsciEnded[0] 
//        << "  1: " << *m_vctKsciEnded[1] 
//        << endl; // to debug 03.02.22
    DfEachReverse(vector<ksci>::reverse_iterator, m_vctKsciEnded){
        InitializeKsci();
        pClParenticRglAt->SetDfaOut( *pm_vctKsciEnded_ );
        //m_pClParenticRgl->ShiftFeedback(0);
        if ( flowOutToEnd( *pm_vctKsciEnded_) ){
            return incrementKsci(*pm_vctKsciEnded_);
        }
    }
    return ksciLasttMatchedAg;
}

// (..) �Ɉ͂܂ꂽ���� Perl �� $n �����߂�
void ClRegularString::FindParenticString(int inParenticNumAg)
{
    if (this->size() == 0){
        cout << "Regular Pattern match by krgstr::% is not detected \n";
        cout << "    for \"" << m_strTraversed <<"\"";
        cout << "\n" << endl;
        return;
    }

    m_vctKsciStarted.reserve( this->size() );
    m_vctKsciEnded.reserve( this->size() );

        ksci ksciAt =  // for debug
        m_VctpClParenticRgl[inParenticNumAg]->m_ksciNfaFirst
        = DetectFirstReachAtEndForInput(inParenticNumAg );

        // a countermeasure of ## "@abc:" / "@(.*):.*" test $1 01.06.19 begin
        if ( ksciAt == (ksci)0){
            m_VctpClParenticRgl[inParenticNumAg]->m_strMatched = "";
            return;
        }
        // a countermeasure of ## "@abc:" / "@(.*):.*" test $1 01.06.19 end

        m_VctpClParenticRgl[inParenticNumAg]->m_ksciNfaLast
        = DetectLastReachAtEndForOutput(inParenticNumAg
                    , m_VctpClParenticRgl[inParenticNumAg]->m_ksciNfaFirst);
#if 0
        m_VctpClParenticRgl[inParenticNumAg]->m_strMatched
        = string(m_VctpClParenticRgl[inParenticNumAg]->m_ksciNfaFirst
                    ,m_VctpClParenticRgl[inParenticNumAg]->m_ksciNfaLast);
#else
        // to debug, ksciFirstAt, ksciLastAt, strAt �ƌ��ʂ��f�o�b�K��Ō��₷������
        ksci ksciFirstAt = m_VctpClParenticRgl[inParenticNumAg]->m_ksciNfaFirst;
        ksci ksciLastAt = m_VctpClParenticRgl[inParenticNumAg]->m_ksciNfaLast;
        //ksciLastAt = incrementKsci(ksciLastAt);
        string strAt(ksciFirstAt, ksciLastAt);
        m_VctpClParenticRgl[inParenticNumAg]->m_strMatched = strAt;
#endif
}


//-----------------------ClRegularStr Flow DFA  Edn ---------------------
ClRegularString& ClRegularString::operator =(kc string& crStrAg)
{
    SetRegularString(crStrAg);
    return *this;
}

bool ClRegularString::operator ()(kc string& crStrAg)
{
    if ( m_strRgl.size() == 0){
        throwRglError("No Regular Expression string");
    }
    if ( m_strTraversed != crStrAg ){
        Traverse( crStrAg );
        //04.02.09 m_ksciFirstMatchReserved == 0 �̂Ƃ��̏ꍇ�킯�����Ȃ��� gcc ���Ƃ���Ȃ�
        if ( m_ksciFirstMatchReserved == (ksci)0){
            kAssert("m_ksciMatchEnded must be 0 because unmatch pattern."
                , m_ksciMatchEnded == (ksci)0);
            *(kstring*)this = string("");
        }else{
            kAssert("m_ksciMatchEnded become unexpedtedly.", m_ksciMatchEnded != (ksci)0);
            *(kstring*)this = kstring(m_ksciFirstMatchReserved, m_ksciMatchEnded);
        }
    }
    //return  m_ksciFirstMatchReserved != m_ksciMatchEnded;
    return  this->size() != 0;
}

kstring& ClRegularString::operator%(int inAg)
{
    if ( inAg < -3 ){
        kstring strAt = kTurnInt2Str(inAg);
        strAt +=  " is less than -3.";
        throwRglError(strAt);
    } else if ( ( ( (size_t) inAg) >= (m_VctpClParenticRgl.size()) )
            && (inAg > 0 )
    ){
        throwRglError( kTurnInt2Str(inAg)
                + " is bigger than ClParenticRgl vector size" );
    }

    if ( inAg == -1 ){          // Pre matched
        return m_strPreMatched;
    }else if ( inAg == -2 ){    // Post matched
        return m_strPostMatched;
    }else if ( inAg == -3 ){    // string traversed
        return m_strTraversed;
    }else if ( inAg == 0 ){    // normal matched
        return *(string*)this;
    }else{
        if ( m_VctpClParenticRgl[inAg]->m_ksciNfaFirst == (ksci)0 ){
            // inAg �܂ł� (..) �}�b�`����������o����
            FindParenticString(inAg);
        }
        return m_VctpClParenticRgl[inAg]->GetMatchedString();
    }
}

ClRegularString& operator / (kc string& crStrAg, ClRegularString& crKrgStrAg)
{
    crKrgStrAg(crStrAg);
    return crKrgStrAg;
}

#if 0
//SJIS ��p�ł���B���G���g�����g�����Ȃ�
static ka<ClRegularString> apClRegularStringStt;
static string strStt;
ClRegularString& operator | (kc string& crStrAg, const char* pChAg)
{
    strStt = pChAg;
    apClRegularStringStt = ka<ClRegularString>(new ClRegularString(strStt));
    return *(apClRegularStringStt.get());
}
#endif


void ClRegularString::IgnoreCapitalSmall(bool blAg)
{
    m_pClParenticRgl->IgnoreCapitalSmall(blAg);
}
//------------------- ClRegularString class End --------------------

//------------------ ClGetLine  Code Begin -------------------------
ClGetLine::ClGetLine(const kstring& crStrAg)
    : m_ifstream(crStrAg.c_str()),m_inLineNumber(0), m_blOK(false)
{
    if ( m_ifstream ){
        m_blOK = true;
    }else{
        cout << "file:" << crStrAg << " error."  << endl;
    }
}

bool ClGetLine::IsOK(void)
{
    return m_blOK;
}
int ClGetLine::operator ()(kstring& rStrAg)
{
    if ( !m_ifstream.eof() ){
        getline(m_ifstream, rStrAg);
        return ++m_inLineNumber;
    }else{
        return 0;
    }
}

//------------------ ClGetLine  Code End -------------------------

//------------------ DfPrint  Code Begin -------------------------
#ifdef DfPrint
kchar ClPrimitiveRgl::WhatRepeator(void)
{
    if ( (m_blBack == true ) && (m_blForward == true ) ){
        return _T('*');
    }else if ( (m_blBack == true ) && (m_blForward == false ) ){
        return _T('+');
    }else if ( (m_blBack == false ) && (m_blForward == true ) ){
        return _T('?');
    }else{
        return _T('n');
    }
}
DfVoid ClPrimitiveRgl::DebugPrint(const kstring& crStrIndentAg)
{
    kstring strAt(_T("    "));
    strAt += crStrIndentAg;
    kcout << strAt << typeid(*this).name() 
             << ":\"" << m_strRgl << "\" " << (char)WhatRepeator()
             << endl;

    DfVoidReturn;
}

DfVoid ClParenticRgl::DebugPrint( const kstring& crStrIndentAg)
{
    kstring strAt(_T("    "));
    strAt += crStrIndentAg;
    kcout << strAt << typeid(*this).name() 
             << ":\"" << m_strRgl << "\" " << (char)WhatRepeator()
             << endl;

    DfEachLoop(list<vector<ClPrimitiveRgl*>* >::iterator
                                    , m_lstpVctpClPrimitiveRgl ){
        kcout << strAt << "    |" << endl;
        vector<ClPrimitiveRgl*>* pVctpClPrimitiveRglAt
                = *pm_lstpVctpClPrimitiveRgl_;
        DfEachLoopPtr( vector<ClPrimitiveRgl*>::iterator
                                    , pVctpClPrimitiveRglAt ){
            (*ppVctpClPrimitiveRglAt_)->DebugPrint(strAt);
        }
    }

    DfVoidReturn;
}
DfVoid ClRegularString::DebugPrint( const kstring& rCtStrAg)
{
    kcout << _T("ClRegularString::") << m_strRgl << endl;
    m_pClParenticRgl->DebugPrint( _T("") );
    DfVoidReturn;
}

#endif //DfPrint
}   // namespace kk

//------------------ _DEBUG Only Code End -------------------------
//------------------ Simulatiion Code Begin -------------------------
#ifdef DfVrfy
#   ifdef DfVrfyKreg_
#include <Verifier.h>
using namespace std;
using namespace kk;

#include <VrfyLib.h>
#ifdef DfVC_debug
class ClDetectLeak{
  public:
    ClDetectLeak()
    {
        // Call DetectLeak() before ClTestVctD constructor.
        extern void DetectLeak(void);
        DetectLeak();
    }
} clDetectLeakStt;
#endif // DfVC_debug
class ClTestVctD : public ClVfLibActn {
  public:
  protected:
    virtual void doAtInitialVl( const std::string& crStrAg);
    //virtual void polling();
};

#if 0
void ClTestVctD::polling(void)
{
    // break at an indicated test vector file line
    if ( IsBreakLine() ){
        int inBreakLineAt=0;
        SetBreakLine(inBreakLineAt);
    }
}
#endif
static ClTestVctD clTestVctD;


namespace kk{

#ifdef DfWideString
void ClPrimitiveRgl::CheckMemberString(const string& crStrCompredAg
                    , const char cCharRepeatorAg)
{
        if ( (crStrCompredAg == wstr2str(m_strRgl))
          && ( cCharRepeatorAg == wchar2SJis(WhatRepeator()))
        ){
            string strAt;
            strAt += typeid(*this).name();
            strAt +=": ";
            strAt += wstr2str(m_strRgl);
            (strAt += " ") += cCharRepeatorAg;
            //strAt += cCharRepeatorAg;
            //strAt += "\n";
            clTestVctD.OutOK(strAt );
        }else{
            string strAt("�z��l�ƈقȂ�܂��BClPrimitiveRgl ������: ");
            strAt += typeid(*this).name();
            strAt +=": ";
            strAt += wstr2str(m_strRgl);
            strAt += "-----";
            strAt += crStrCompredAg;
            //strAt += "\n";
            clTestVctD.OutError(strAt );
        }
}

#else
void ClPrimitiveRgl::CheckMemberString(const kstring& crStrCompredAg
                    , const kchar cCharRepeatorAg)
{
        std::string strDamieAt = m_strRgl;

        if ( (crStrCompredAg == strDamieAt/*m_strRgl*/)
          && ( cCharRepeatorAg == WhatRepeator())
        ){
            kstring strAt;
            strAt += typeid(*this).name();
            strAt +=": ";
            strAt += m_strRgl;
            (strAt += " ") += (char)cCharRepeatorAg;
            //strAt += cCharRepeatorAg;
            //strAt += "\n";
            clTestVctD.OutOK(strAt );
        }else{
            kstring strAt("�z��l�ƈقȂ�܂��BClPrimitiveRgl ������: ");
            strAt += typeid(*this).name();
            strAt +=": ";
            strAt += m_strRgl;
            strAt += "-----";
            strAt += crStrCompredAg;
            //strAt += "\n";
            clTestVctD.OutError(strAt );
        }
}

#endif  //DfWideString

}   // namespace kk

//------------- simulation input file -----------

#include <sstream>
#include <stdlib.h>
using namespace std;
static std::string convertHB2Space(const std::string& crStrAg)
{
    std::string strAt(""); 
    ksci ksciAt = crStrAg.begin();
    while (ksciAt < crStrAg.end() ){
        if ( getChar(ksciAt) == _T('^') ){
            ksci ksciAt2 = incrementKsci(ksciAt);
            if ( getChar(ksciAt2) == _T('b') ){
                ksciAt = incrementKsci(ksciAt);
                ksciAt = incrementKsci(ksciAt);
                strAt += " ";
                continue;
            }
        }
        strAt += getChar(ksciAt);
        ksciAt = incrementKsci(ksciAt);
    }
    return strAt;
}

enum EnTestOperation { EnNoOperation, EnKrgstrMinus4=-4, EnKrgstrPlus2 = 2
    , EnTestClGetLine = 10
    } enTestOperationStt = EnNoOperation;
static std::string strRegularStt( _T("") );
static std::string strSentenseStt(_T(""));
static std::string strErrorThrowedStt(_T("") );
static krg krgStrStt("ab", ClRegularString::EnIgnoreSmall);
bool blDbgPrintStt=false;
bool blIgnoreCapitalSmallStt = false;
void blIgnoreCapitalSmall(bool blAg)
{
    if (blAg == true ){
        krgStrStt.IgnoreCapitalSmall(true);
    }else{
        krgStrStt.IgnoreCapitalSmall(false);
    }
}
static void setRglExprssnString(const std::string& crStrAg)
{
    strRegularStt = crStrAg;
    try{
        krgStrStt.SetRegularString(strRegularStt);
    }catch(ClRglError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        cout << "Execption Error: " << pClRglError->m_strCst << endl;
        delete pClRglError;
    }

}
static void setSentenseString(const std::string& crStrAg)
{
    strSentenseStt = crStrAg;
    try{
        strSentenseStt/krgStrStt;
    }catch(ClRglError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        cout << "Execption Error: " << pClRglError->m_strCst << endl;
        delete pClRglError;
    }
}

// matched string �̑S������ɒ��ׂ�͖̂ʓ|�ł���B
// chekString __fucntion "number string"  �ƋL�q����
// main.cpp �Œ�`���� krgStrStt ���g���̂� 
// krgstr::CheckMatchedString(.) �� main.cpp �ɂ���
static void reportError(int inAt, const std::string& crStrAssumedAg, const std::string& crStrRealAg)
{
    kstring strOKAt("not assumed string value�BClParenticRgl:");
    strOKAt += kTurnInt2Str(inAt) + ":";
    strOKAt += crStrAssumedAg;
    strOKAt +=" ---- ";
    strOKAt += crStrRealAg;
    //ClVrfySglt::GetStt()->OutError( strOKAt);
    clTestVctD.OutError(strOKAt );
}

static void reportOK(int inAt, const std::string& crStrAg)
{
    kstring strOKAt;
    strOKAt += kTurnInt2Str(inAt) + ":";
    strOKAt += crStrAg;
    strOKAt +=  " matched regular string";
    //ClVrfySglt::GetStt()->OutWithTime(strOKAt);
    clTestVctD.OutOK( strOKAt );
}

void ClRegularString::CheckMatchedString(const std::string& crStrAg)
{

    std::istringstream istrAt(crStrAg);
        //throwRglError("Test throwRglError()");  // to debug
    std::string strAt;

    int inAt;
    istrAt >> std::ws >> inAt >> std::ws >> strAt;
    strAt = convertHB2Space(strAt);

//    try{

    if ( inAt < -3 ){
        kstring strErrorAt("No corresponding parameter: ");
        ClVrfySglt::GetStt()->OutError( strErrorAt + kTurnInt2Str(inAt) +
            " is too small. Use parameter bigger than equal -3" );
        krgStrStt%inAt;
        return;
    }else if ( inAt == -1 ){          // Pre matched
        if ( m_strPreMatched == strAt){
            reportOK(inAt, strAt);
        }else{
            reportError(inAt, strAt, m_strPreMatched);
        }
        krgStrStt%inAt;
        return;
    }else if ( inAt == -2 ){    // Post matched
        if ( m_strPostMatched == strAt){
            reportOK(inAt, strAt);
        }else{
            reportError(inAt, strAt, m_strPostMatched);
        }
        krgStrStt%inAt;
        return;
    }else if ( inAt == -3 ){    // string traversed
        if ( m_strTraversed == strAt){
            reportOK(inAt, strAt);
        }else{
            reportError(inAt, strAt, m_strTraversed);
        }
        krgStrStt%inAt;
        return;
#if 0
    }else if ( inAt == 0 ){    // normal matched
        if ( (*(string*)this) == crStrAg){
            reportOK(inAt, crStrAg);
        }else{
            reportError(inAt, crStrAg, *(string*)this);
        }
        return;
#endif
    }

    if ( ( ( (size_t) inAt) >= m_VctpClParenticRgl.size() )
            && (inAt > 0 )
    ){
        std::ostringstream ostrAt;
        ostrAt << "Error! ";
        ostrAt << inAt << " is bigger than the array size: ";
        ostrAt << m_VctpClParenticRgl.size();
        //ostrAt << "\n";
        //ClVrfySglt::GetStt()->OutError(string(ostrAt.str(),(ostrAt.str()).size()));
        //ClVrfySglt::GetStt()->OutError(string(ostrAt.str()) );
        clTestVctD.OutError(std::string(ostrAt.str()) );
    }else if ( strAt == ( (krgStrStt) % inAt ) ){
        reportOK(inAt, strAt);
    }else{
        reportError(inAt, strAt, krgStrStt % inAt);
    }

    krgStrStt%inAt;

#if 0
    }catch(ClRglError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        cout << "Execption Error: " << pClRglError->m_strCst << endl;
        delete pClRglError;
    }
#endif
}


// ���K�\���������v�f�ɕ����������ʂ��m�F����
// checkRgExprssnString __fucntion "number string"  �ƋL�q����
//static void checkRglElementString(string strAg)
static void checkRglElementString(const std::string& strAg)
{
    std::istringstream istrAt(strAg);
    int inAt;
    std::string strAt;
    char chRepeatorAt;
    istrAt >> std::ws >> inAt >> std::ws >> strAt >> std::ws >> chRepeatorAt;

    //wstring wstrAt;
    //ChangeSJis2Unicode(strAt, kr wstrAt);
    //wchar_t wchAt;
    //mbtowc(&wchAt, &chRepeatorAt, sizeof( chRepeatorAt) );
    krgStrStt.WhatPrmtvRptRgl(inAt)
            ->CheckMemberString( strAt, chRepeatorAt );

}

void checkMatchedString(const std::string& pChAg)
{
    try{
        if ( !krgStrStt.IsTraversed(strSentenseStt) ){
            strSentenseStt / krgStrStt;
        }

        krgStrStt.CheckMatchedString(pChAg);
    }catch(ClRglError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        cout << strErrorThrowedStt << endl; // to debug
        delete pClRglError;
    }
}


static void makeCapatalSmallAtConstruct(const std::string& crStrAg)
{
    krgStrStt.SetRegularString(crStrAg);
    krgStrStt.IgnoreCapitalSmall(true);
}

static string strStt;
static void setGetKsciMatchedBeginEnd(int inParamAt)
{
    try{
        static bool blSecondStt=false;
        
        // GetKsciMatchedEnd() �����s�����邱�Ƃ��s��Ȃ��� coverage 100% �e�X�g�ł��Ȃ�
        blSecondStt = !blSecondStt;
        if ( blSecondStt ){
            kstring::const_iterator ksciBeginAt = krgStrStt.GetKsciMatchedBegin(inParamAt);
            kstring::const_iterator ksciEndAt = krgStrStt.GetKsciMatchedEnd(inParamAt);
            strStt=string(ksciBeginAt, ksciEndAt);
        }else{
            kstring::const_iterator ksciEndAt = krgStrStt.GetKsciMatchedEnd(inParamAt);
            kstring::const_iterator ksciBeginAt = krgStrStt.GetKsciMatchedBegin(inParamAt);
            strStt=string(ksciBeginAt, ksciEndAt);
        }
    }catch(ClRglError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        delete pClRglError;
    }
}

static size_t sztStt;
static void setGetSztMatchedBegin(int inParamAt)
{
    try{
        sztStt = krgStrStt.GetSztMatchedBegin(inParamAt);
    }catch(ClRglError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        delete pClRglError;
    }
}
static void setGetMatchedSize(int inParamAt)
{
    try{
        sztStt = krgStrStt.GetMatchedSize(inParamAt);
    }catch(ClRglError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        delete pClRglError;
    }
}
void ClTestVctD::doAtInitialVl( kc std::string& crStrAg)
{

    if ( IsSameNocase(crStrAg,"typical.vrf")
      || IsSameNocase(crStrAg,"test.vrf")
      || IsSameNocase(crStrAg,"v\\error.vrf")
      || IsSameNocase(crStrAg,"v\\abnormal.vrf")
      || IsSameNocase(crStrAg,"v\\after100cv.vrf")
      || IsSameNocase(crStrAg,"v\\sjistest.vrf")
      || IsSameNocase(crStrAg,"v\\test.vrf")
    ){

        ClVfLibActn::doAtInitialVl(crStrAg);  // open crStrAg file
        //openTestVct(crStrAg);  // �g���e�X�g�E�x�N�^���w�肷��
        kcout << "Now verifying input file is " << crStrAg << " in main.cpp" << std::endl;

        RgstVerified(this, tfNewVerified(blDbgPrintStt, "dbgPrintFlag") );


        RgstVerified(this, tfNewVfFnctnSpl(setRglExprssnString, "setRglExprssnString") );
        RgstVerified(this, tfNewVfFnctnSpl(setSentenseString, "setSentenseString") );
        RgstVerified(this, tfNewVfFnctnSpl(checkRglElementString,"checkRglElementString") );
        RgstVerified(this, tfNewVfFnctnSpl(checkMatchedString,"checkMatchedString") );


        RgstVerified(this, tfNewVfFnctn(blIgnoreCapitalSmall,"blIgnoreCapitalSmall") );

        RgstVerified(this, tfNewVerified(strErrorThrowedStt, "strErrorThrowed") );
        //tfRgstVrfyStr(this, strSentenseStt, "strSentenseStt");
        RgstVerified(this, tfNewVerified(strSentenseStt, "strSentenseStt") );

        RgstVerified(this, tfNewVerified(krgStrStt, "krgStrStt") );

        RgstVerified(this, tfNewVfFnctnSpl(makeCapatalSmallAtConstruct,"makeCapatalSmallAtConstruct") );

        RgstVerified(this, tfNewVerified(*(int*)&enTestOperationStt,"enTestOperationStt") );

        krgStrStt.Register(this, "krgStrStt");

        RgstVerified(this, tfNewVfFnctn(setGetSztMatchedBegin,"setGetSztMatchedBegin") );
        RgstVerified(this, tfNewVfFnctn(setGetMatchedSize,"setGetMatchedSize") );
        RgstVerified(this, tfNewVerified(sztStt, "sztStt") );

        RgstVerified(this, tfNewVfFnctn(setGetKsciMatchedBeginEnd,"setGetKsciMatchedBeginEnd") );
        RgstVerified(this, tfNewVerified(strStt, "strStt") );

        //pKrgstrStt->Register(this, "krgStrStt");
        //registFunctionVoid(g, "g");
#ifdef debugX
#endif //debugX
    }
}

//------------------ Simulatiion Code End -------------------------
#   endif //DfVrfyKreg_
#endif  // DfVrfy

