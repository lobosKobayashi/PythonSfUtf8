//04.12.30 test ito2
#include<stdlib.h>

int atoi( char* cPChAg)
{
    return 1;
}
int main(int argc, char** argv)
{
    char chAt='A';
    char arChAt[10];
    itoa(15,arChAt,2);
    return atoi(&chAt);
}

