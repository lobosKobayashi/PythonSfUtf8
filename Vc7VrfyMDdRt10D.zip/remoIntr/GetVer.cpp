namespace kk{
    extern void callCopyRight();
}
int main(int argc, char** argv)
{
    kk::callCopyRight();
}

