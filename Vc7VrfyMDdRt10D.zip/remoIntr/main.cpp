#include<Verifier.h>
#include<TestVct.h>
#include<string>
#include<iostream>
#include <Windows.h>
#ifdef DfVC_
#   include <crtdbg.h>
#endif  // DfVC_

using namespace std;
using namespace kk;

static kstring strErrorThrowedStt(_T("") );


int main(int argc, char** argv)
{
#ifdef DfVC_
    int tmpDbgFlagAt = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG);
    tmpDbgFlagAt |= _CRTDBG_LEAK_CHECK_DF;
    _CrtSetDbgFlag(tmpDbgFlagAt);
#endif  // DfVC_
    //return 0;   // to debug 08.23
    try{
        // ClVrfySglt::Main() can handle protected, priveate member in the ClVrfySglt
        ClVrfySglt::GetStt()->m_PvVrfyFiber = ConvertThreadToFiber(0);
        return ClVrfySglt::GetStt()->Main(argc, argv);	
    }catch(ClError* pClRglError){
        strErrorThrowedStt = pClRglError->m_strCst;
        cout << "Execption Error: " << pClRglError->m_strCst << endl;
        delete pClRglError;
        return 1;
    }
}


TyByte Port0;
