/* ���[�U�[�� void polling(void)�� void requestDFC(void) �������Œ�`����*/
#define dfGnrtTskStckFrmCntxtCd
#define dfNmTaskParameterSize 1
#define dfTaskStackSize 100
#include <TaskOOP.h>
extern TyByte Port0;
//TyByte Port0;
extern void intrTsk_display(char* pChAg);

/* Cast to Lower Byte */
#define dfClb(pVdPrmAg__) (*(TyByte*)(&pVdPrmAg__))
/* Cast to Upper Byte */
#define dfCub(pVdPrmAg__) (*(((TyByte*)(&pVdPrmAg__))+1))
/* Cast to integer */
#define dfCi(pVdPrmAg__) (*(int*)(&pVdPrmAg__))

static void subFuction(struct StStckFrmContext* pStAg, void* pVdPrmAg)
{
    dfCub(pVdPrmAg) = Port0;
    dfClb(pVdPrmAg) = 0;
    dfLoopingWait(0){
        if ( dfCub(pVdPrmAg) != Port0){
            dfCub(pVdPrmAg) = Port0;
            if ( DfBit(Port0).bit1 == 1){
                dfBreakLooping();
            }else if ( DfBit(Port0).bit0 == 1){
                extern void intrTsk_displayCount(int inAg);
                intrTsk_displayCount(
                    ++dfClb(pVdPrmAg) );
            }
        }
    }
    dfReturnValue(0x55);
}

/* dfTaskFnc(pf.vdAg) �}�N���̓^�X�N�֐� pf �̃v���g�^�C�v��
 * �w�肷��}�N���ł���Bthis �������B��ē������Ă���B
 */
static void displayString(struct StStckFrmContext* pStAg, void* pVdPchAg)
{
    /* inStt �� auto �ϐ��ł���� dfDelay(.) �ɂ��ϐ��l��
     * �����Ă��܂��Bstatic �ȕϐ��Ƃ���
     */
    static int inStt;
    for(inStt=0; inStt<4; inStt++){
        intrTsk_display((char*) pVdPchAg);
        dfWait(250);   /*250mSec delay*/
        intrTsk_display("");
        dfWait(250);   /*250mSec delay*/
    }
    dfReturnValue(0);   /*���̖߂�l�͎g���Ă��Ȃ�*/
}


//static void taskSimple( struct StStckFrmContext* pStAg,void* pVdPrmAg)
static void taskSimple( struct StStckFrmContext* pStAg,int pVdPrmAg)
{
    int inAt;
    inAt = 3;
    dfCi(pVdPrmAg) = 8;
    dfWait(100);
    inAt = 5;
    //pVdPrmAg = (void*)"Now Start";
    pVdPrmAg = (int)"Now Start";
    dfCall(displayString);    //

    //pVdPrmAg = (void*)0x33;
    pVdPrmAg = (int)0x33;
    dfCall(subFuction);
    //pVdPrmAg = (void*)"  Exit   ";
    pVdPrmAg = (int)"  Exit   ";
    dfCall(displayString);    //
}

void TestTask_Initialize(void)
{
    dfSetPrmStt("abcdefghij");
    dfStartStt(taskSimple);

    extern void IntrTsk_Initialize(void);
    IntrTsk_Initialize();
}

/*---------------- Beginning of Simulation -----------------*/
#ifdef DfVrfy
static StStckFrmContext& rStStckFrmContextStt
    = dfStTcbStt_;

#include <VrfyRtosPrdc.h>
#include <iostream>
using namespace std;
using namespace kk;

class ClTestVctD : public ClVrfyRtosActnPrdc {
  protected:
    virtual void doAtInitialVl( const string& crStrAg);
  public:
    ClTestVctD():ClVrfyRtosActnPrdc("testTask"){}
};
static ClTestVctD clTestVctDStt;

void ClTestVctD::doAtInitialVl( const string& crStrAg)
{
    if ( IsSameNocase(crStrAg,"v\\test.vrf")
      || IsSameNocase(crStrAg,"v\\TestTask.vrf")
    ){
        ClVrfyRtosActnPrdc::doAtInitialVl(crStrAg);
        cout << "Now simulation input file is " << crStrAg << " in testTask.c" << endl;
        
        RgstVerified(this, tfNewVfFnctnSpl(TestTask_Initialize,"TestTask_Initialize") );
        RgstVfMt(this
                , tfNewVerified(Port0, "Port0")
                , tfNewMonitored(Port0, "Port0") );
    }
}
#endif  /* DfVrfy*/

