#include "kcommon.h"

typedef unsigned int Tyword;
static Tyword wdRemoDetectedCodeStt;
static Tyword rmcnintr_getRawSharpCode(void)
{
    return wdRemoDetectedCodeStt;
}

/************* new TCB Beginning***************************/
#define dfGnrtFrmCntxtCd
#define dfNmTaskParameterSize 1
#include "mntr\TaskOOP.h"
/************* new TCB End ***************************/

/************* new Differed OOP Begin ***************************/
static void differedFunctionCall(void);
#define dfGnrtDfcCdInvlvFnctn differedFunctionCall
#include "mntr\DfcOOP.h"

static void rmcnTask( struct StFrameContext* pStTcbAg, void* pVdPrmAg);

static TyWord wdReceivedSharpCodeStt;
/* �����R�����荞�ݐM�����P�T�r�b�g���������Armcn task ���N������*/
static void differedFunctionCall(void)
{
    if( dfIsDormantStt() ){
        dfStartStt(rmcnTask);
    }else{
        dfRestartStt();
    }
}

/* remocon_requestDPC(.) �� ���荞�݋֎~��Ԃ� remoIntr.c ����Ă΂�� */
void remocon_requestDPC(TyWord wdSharpCodeAg)
{
    wdReceivedSharpCodeStt = wdSharpCodeAg;
    dfRequestDfcStt();
}

/************* new Differed OOP End ***************************/

bool RemoDvc_whatKindRemoCode(TyWord wdRemoconAg)
{
    return wdRemoconAg == 0xaa;
}

/********************* rmcn constructor *************************************/

/******* �V���[�v�R�[�h�̈�v���m�F���A�܂������R���M�����Ȃ��Ȃ������Ƃ�
 ******* ���o����^�X�N
 */
static TyWord wSharpCodeBuffer;  /*2 �� sharp code ���r���邽�߂Ɏg��*/
static bool btFlReceivingStt;

//#include "keyIntf.h"
static bool sendCodeIfConinue(void)
{
    wdReceivedSharpCodeStt = 0;
    return true;
}

static void rmcnTask( struct StFrameContext* pStTcbAg, void* pVdPrmAg)
{
    static bool btEvenStt;
    TyByte byDamieAt;
    /* pVdPrmAg �� struct StRemoBusTable*/
    enum { En2TimeInterval=110/* > 120mSec */, EnContinuousBit = 0x0080};
    
    dfPutTcbOnStack(pStTcbAg);

    byDamieAt = 0xaa;
firstSharpCode:
    wSharpCodeBuffer = wdReceivedSharpCodeStt;
    wdReceivedSharpCodeStt = 0;
    /* 2000.06.10 �X�L�����������Â����Ƃ��A��M�͂��邪�R�[�h�𑗂�Ȃ��Ȃ�
     * ���̂��߂̏C���ł��B���̕p�x�� CD �S���ň����x�ł����B -- begin
     */
    for (;;){
        if (dfWait(230) != EnTimeup_ ){
            /* 230mSec �ȓ��ɁA���ڂ̃V���[�v�E�R�[�h����M���� */
            if ( wdReceivedSharpCodeStt ){
                /* reverse sharp code */
                if( wSharpCodeBuffer == wdReceivedSharpCodeStt ){
                    if( RemoDvc_whatKindRemoCode( wSharpCodeBuffer ) ){
                        /*dfCi(pVdPrmAg) = 1;*/   /* FL �\�� On */
                        btFlReceivingStt = true;
                        //oprtn_sendFromRemocon( 
                        //    ((struct StRemoBusTable*)pVdPrmAg)->m_enOperate );
                        goto labelContinue;
                    }
                }
                wSharpCodeBuffer = wdReceivedSharpCodeStt;
                wdReceivedSharpCodeStt = 0;
            }
           /* goto firstSharpCode;*/
        }else{
            /* time up */
            btFlReceivingStt = false;
            wdReceivedSharpCodeStt = 0;
            return;
        }
    }
    /* 2000.06.10 �X�L�����������Â����Ƃ� --- end */

labelContinue:
    btEvenStt = true;
    for(;;){
        //TyWord wdResumedTimeAt;
        wdReceivedSharpCodeStt = 0;
        if ( dfWait(150) != EnTimeup_ ){
            /* sharp code �����o����*/
            if ( wSharpCodeBuffer != wdReceivedSharpCodeStt){
                //oprtn_sendFromRemocon( EnOprOff );
                goto firstSharpCode;
                /* �R�[�h��P�������邽�� goto ���g�����B�ŏ��ɖ߂邾����*/
            }
            btEvenStt ^= true;
            if ( btEvenStt ){
                if (!sendCodeIfConinue() ){
                    /* continue code �łȂ��̂� FL ��M�\�������� */
                    btFlReceivingStt = false;
                }
            }
        }else{
            break;
        }
    }
    btFlReceivingStt = false;
    //oprtn_sendFromRemocon( EnOprOff );
    wdReceivedSharpCodeStt = 0;
}

#include<VrfyRtosPrdc.h>
extern void CntxtCue_DecrementDelayCueStt(void);
extern DfBool CntxtCue_ExecuteReadyCueStt(void);
extern void Dffrd_execute(void);
extern DfBool timer_isTimeUpfromCntrxGrp(void);


using namespace kk;
using namespace std;
namespace kuos{
void main(void)
{
    //dfStartStt(taskSample);
    for(;;){
#ifdef DfVrfy
        if ( ClVfIntfRtosSgPrdc::GetStt()->IsEnded() ){
            break;
        }
        ClVfIntfRtosSgPrdc::GetCntxtStt()->DelayWithCpu();  //!< default m_tmLoopingPeriod
        //ClVfIntfRtosSgPrdc::GetCntxtStt()->DelayWithCpu( ClLongIn(0.003) );
#endif
        Dffrd_execute();
        if ( timer_isTimeUpfromCntrxGrp() ){
            CntxtCue_DecrementDelayCueStt();
        }
        CntxtCue_ExecuteReadyCueStt();
    }
    //return to ClVfIntfRtos::LaunchStt() 
    //ClVfIntfRtosSgPrdc::GetIntfStt()->SwitchToVrfy( ctmMaxGlb );
}
}   //namespace kuos

StRtosThrdPrdc stRtosThrdPrdcGlb 
    = { 0/* m_pClVfIntfRtosSgPrdc*/, 0.001/*1mSec*/, kuos::main};

static bit btTimeUp;
DfBool timer_isTimeUpfromCntrxGrp(void)
{
    if (btTimeUp ){
        btTimeUp = false;
        return true;
    }else{
        return false;
    }
}

void interrupt_10mSecInterval(void)
{
    btTimeUp = true;
}

#undef dfBreakLooping   // coding lefted
/*---------------- Beginning of Simulation -----------------*/
#ifdef DfVrfy
#include <VrfyRtosPrdc.h>
#include <iostream>
using namespace std;
using namespace kk;

static struct  dfStTcbArg_& crStTcbStt = dfStTcbStt_;

class ClTestVctD3 : public ClVrfyRtosActnPrdc {
  protected:
    virtual void doAtInitialVl( const string& crStrAg);
  public:
    ClTestVctD3():ClVrfyRtosActnPrdc("testTsk3"){}
};

static ClTestVctD3 clTestVctD3Stt;   //("testTsk3");

void ClTestVctD3::doAtInitialVl( const string& crStrAg)
{
    if ( IsSameNocase(crStrAg,"v\\test3.vrf")
      || IsSameNocase(crStrAg,"v\\T2Test.vrf")
    ){
        ClVrfyRtosActnPrdc::doAtInitialVl(crStrAg);  // open crStrAg file
        cout << "Now simulation input file is " << crStrAg << " in testTask3.c" << endl;
        RgstVerified(this
                //, new TcRgstFnctn<int,unsigned int>(remocon_requestDPC, "remocon_requestDPC") );
                , tfNewVfFnctn(remocon_requestDPC, "remocon_requestDPC") );
        //tfRgstMntrVrfy(this, btFlReceivingStt, "btFlReceivingStt");
        RgstVfMt(this
            , tfNewVerified(btFlReceivingStt, "btFlReceivingStt")
            //, new TcVerified<bool>(btFlReceivingStt, "btFlReceivingStt")
            , tfNewMonitored(btFlReceivingStt, "btFlReceivingStt") );

        extern void StartRemoconInterrupt(int inCodeAg);
        RgstVerified(this
            , tfNewVfFnctn(StartRemoconInterrupt, "StartRemoconInterrupt") );
    }else{
        //setAliveTime(15*S);
    }
}
#endif  /* DfVrfy*/
