#define dfGnrtTskStckFrmCntxtCd
#define dfTaskStackSize 100
#include <TaskOOP.h>

#include <windows.h>
HANDLE hMapStt;
static char* pChStt;
static void operate_FileMap()
{
    hMapStt
        = OpenFileMapping(FILE_MAP_WRITE, FALSE, "TkCdMapFile");
    pChStt = (char*)MapViewOfFile(hMapStt,
            FILE_MAP_WRITE,
            0,0,0);
    if ( pChStt == 0){
        // FL Window ��\�����Ă��Ȃ��Ƃ��ł��v���O�����𓮍삳����
        // ���̐ݒ肪�Ȃ��ƃv���O������ access violation error ���o��
        static char chArDisplayStt[10];
        pChStt = chArDisplayStt;
    }
}

char chArDisplayStt[10];
static struct StReceivedDisplayData{
    char chArBufferStt[257];       // �ʐM������o�b�t�@;
    unsigned char m_bySizeReceivedData;
    unsigned char m_byDisplayedChar;
} stReceivedDisplayData;
// �\���\�����s�킹��
void intrTsk_displayText(char *pChAg)
{
    for (int inAt=0; inAt<10; inAt++){
        pChStt[inAt] = pChAg[inAt];
    }
}

void intrTsk_displayCount(int inAg)
{
    TyByte byDigitAt;
     byDigitAt;
    intrTsk_displayText("Count 0000");

    byDigitAt = inAg/1000;
    inAg = inAg % 1000;
    pChStt[6] += byDigitAt;

    byDigitAt = inAg/100;
    inAg = inAg % 100;
    pChStt[7] += byDigitAt;

    byDigitAt = inAg/10;
    inAg = inAg % 10;
    pChStt[8] += byDigitAt;

    pChStt[9] += inAg;

}

static void clearDisplay(void)
{
    int inAt;
    stReceivedDisplayData.m_byDisplayedChar = 0;
    for(inAt=0; inAt<10; inAt++){
        pChStt[inAt] = ' ';
    }
}

static void clearCharBuffer(void)
{
    int inAt;
    stReceivedDisplayData.m_bySizeReceivedData = 0;
    for(inAt=0; inAt<256; inAt++){
        stReceivedDisplayData.chArBufferStt[inAt] = ' ';
    }
}

static void initializeDisplay(void)
{
    stReceivedDisplayData.m_bySizeReceivedData = 0;
    stReceivedDisplayData.m_byDisplayedChar = 0;
    clearDisplay();
    clearCharBuffer();
}

// testTask.c calls intrTsk_display(.) 
void intrTsk_display(char* pChAg)
{
    initializeDisplay();
    for(int inAt=0; (inAt<10) && (*pChAg); inAt++, pChAg++){
        pChStt[inAt] = *pChAg;
    }
    
}
static void displayTask(struct StStackAndContext* pStTcbAg, void* pVdPrmAg )
{
    clearDisplay();
    dfWait(100);   // wait get 10 charcter
    intrTsk_displayText(stReceivedDisplayData.chArBufferStt);
    for(;;){
        dfWait(100);
        intrTsk_displayText(stReceivedDisplayData.chArBufferStt
            + stReceivedDisplayData.m_byDisplayedChar++);
        if ( stReceivedDisplayData.m_byDisplayedChar
            == stReceivedDisplayData.m_bySizeReceivedData){
            break;
        }
    }
    dfWait(100);
    clearDisplay();
}

static void differedFunctionCall(void)
{
    if ( dfIsDormantStt() ){
        //dfSetPrmStt(&stReceivedDisplayData);
        dfStartStt(displayTask);
    }else{
        // displayTask(.pVdAg) �� pVdAg ���o�R���� 0x55 �l����`���邱�Ƃ��ł���
        //dfRestartStt(0x55);
    }
}

#define dfGnrtDfcCdInvlvFnctn differedFunctionCall
#include <DfcOOP.h>

static void initializeIntr(void);

void IntrTsk_Initialize(void)
{
    initializeIntr();
    operate_FileMap();
    initializeDisplay();
}

static StStckFrmContext& rStStckFrmIntTskStt = dfStTcbStt_;


/*----------------- interrupt task Begin ----------------------------------*/
unsigned char intrReg, Port1, Port1IO, signalPort1;

#include <IntOOP.h>

void IntrTsk_Initialize(void);
void endIntrTask(void)
{
    DfBit(Port1IO).bit0 = 0;    // make SDA pin input mode
    DfBit(Port1IO).bit1 = 0;    // make SCA pin output mode

    intrReg = 0;                // initialize interrupt
    DfBit(intrReg).bit3 = 1;   // mask SCA interrupt
    DfBit(intrReg).bit6 = 1;   // set SDA negative edge interrupt
    dfMakeDormantStt();
}

static void intrTask(struct StIntContext* pTcbAg, void* pVdAg)
{
    DfBit(intrReg).bit5 = 1;   // set SCA positive edg interrupt
    DfBit(intrReg).bit7 = 0;   // 
    DfBit(intrReg).bit3 = 0;   // claer SCA interrupt mask

    // get address
    // inAtStt �� auto �ϐ��ɂ��Ȃ��Bcontext switch ���������Ă��l��ێ�������
    static int inStt = 0;
    static unsigned char byChSerialDataStt = 0;
    for(;;){
        dfWait(pTcbAg);
        inStt++;
        byChSerialDataStt <<= 1;
        byChSerialDataStt |= DfBit(Port1).bit0; // copy SDA port bit in LSB
        if ( inStt == 8){
            break;
        }
    }
    if ( byChSerialDataStt != 0xb2 ){
        // �A�h���X���قȂ�̂ł���ȏ�̏������s��Ȃ�
        endIntrTask();
        return;
    }

    // 0xb2 �A�h���X����M�����̂� _ACK ��Ԃ�
    DfBit(intrReg).bit5 = 0;   // set SCA negative edg interrupt
    DfBit(intrReg).bit7 = 1;   // 
    dfWait(pTcbAg);
    DfBit(Port1).bit0 = 0;    // activate _Ack, Port1.bit0: SDA == Low
    DfBit(Port1IO).bit0 = 1;    // make SDA pin output mode

    dfWait(pTcbAg);
    DfBit(Port1IO).bit0 = 0;    // make SDA pin input mode
    DfBit(Port1).bit0 = 1;    // negate _Ack, Port1.bit0: SDA == High �O�̂���

    // recieve display data from external I^2C device
    for(;stReceivedDisplayData.m_bySizeReceivedData != 255
        ;stReceivedDisplayData.m_bySizeReceivedData++
    ){
        DfBit(intrReg).bit5 = 1;   // set SCA positive edg interrupt
        DfBit(intrReg).bit7 = 0;   // 
        byChSerialDataStt = 0;
        for(inStt=0; inStt<8 ; inStt++){
            dfWait(pTcbAg);
            byChSerialDataStt <<= 1;
            byChSerialDataStt |= DfBit(Port1).bit0; // copy SDA port bit in LSB
        }
        // 1 byte ���̃f�[�^����M�����̂� _ACK ��Ԃ�
        DfBit(intrReg).bit5 = 0;   // set SCA negative edg interrupt
        DfBit(intrReg).bit7 = 1;   // 
        dfWait(pTcbAg);
        DfBit(Port1).bit0 = 0;    // activate _Ack, Port1.bit0: SDA == Low
        DfBit(Port1IO).bit0 = 1;    // make SDA pin output mode

        dfWait(pTcbAg);
        DfBit(Port1IO).bit0 = 0;    // make SDA pin input mode
        DfBit(Port1).bit0 = 1;    // negate _Ack, Port1.bit0: SDA == High �O�̂���

        stReceivedDisplayData.
            chArBufferStt[
               stReceivedDisplayData.m_bySizeReceivedData
            ] = byChSerialDataStt;
        dfRequestDfcStt();
    }
}

void intrB(void)    // SDA interrupt
{
     if ( !dfIsDormantStt() ){
        dfRestartStt(0);
    }
    DfBit(intrReg).bit1 = 0;
}
void intrA(void)    // SDA interrupt
{
    if ( (DfBit(intrReg).bit6 == 1) // negative edge interrupt is activated
      && (DfBit(intrReg).bit4 == 0) // positive edge interrupt is negated
      && (DfBit(Port1).bit1 == 1  ) // SCA == 1
    ){ 
        // now I^2C start consition
        dfStartStt(intrTask, 0);
    }else if ( (DfBit(intrReg).bit6 ==0 ) // negative edge interrupt
      && (DfBit(intrReg).bit4 == 1) // positive edge interrupt is negated
      && (DfBit(Port1).bit1 == 1  ) // SCA == 1
    ){
        endIntrTask();
    }
    DfBit(intrReg).bit0 = 0;
}

static void initializeIntr(void)
{
    DfBit(Port1IO).bit0 = 0;    // make SDA pin input mode
    DfBit(Port1IO).bit1 = 0;    // make SCA pin output mode

    intrReg = 0;                // initialize interrupt
    DfBit(intrReg).bit3 = 1;   // mask SCA interrupt
    DfBit(intrReg).bit6 = 1;   // set SDA negative edge interrupt
}

/*----------------- interrupt task End ----------------------------------*/

/*---------------- Beginning of Simulation -----------------*/
#ifdef DfVrfyX
#include <TestVct.h>
#include <STLContext.h>

using namespace std;
using namespace kk;

class ClI2C : public ClStkFrmCntxt{
//class ClI2C : public ClContextWithStack{
    virtual void task(void);
    bool blSDA;
    bool blSCA;
    string m_strTransferData;
    virtual bool polling(void);


    bool sendByte(void);
    char m_chSendByteAg;

    void stopI2cBus(void);
  public:
    ClI2C():ClStkFrmCntxt(true), blSDA(true), blSCA(true){}
    friend void setTransferString(const string& crStrAg);
};

bool ClI2C::polling(void)
{
    //ClContextWithStack::polling(); coding lefted ��������
    if ( DfBit(Port1IO).bit0 == 1 ){ // Port1:SDA is output mode
        if (blSDA && (DfBit(Port1).bit0 == 1) ){
            DfBit(signalPort1).bit0 = 1;
        }else{
            DfBit(signalPort1).bit0 = 0;
        }
    }else{
        DfBit(signalPort1).bit0 = blSDA;
    }
    DfBit(signalPort1).bit1 = blSCA;    // I^2C clock

    if ( (DfBit(Port1IO).bit0 == 0) ){
        // input mode
        DfBit(Port1).bit0 = DfBit(signalPort1).bit0;
    }
    DfBit(Port1).bit1 = DfBit(signalPort1).bit1;

    static unsigned char signalOld;
    if ( signalOld != signalPort1){
        if ( (DfBit(signalOld).bit0 != DfBit(signalPort1).bit0 )
          && !DfBit(intrReg).bit2
        ){
            // SDA �̐M�����ω������B������ intrA ���荞�݃}�X�N���|�����Ă��Ȃ�
            if ( DfBit(signalPort1).bit0 && DfBit(intrReg).bit4){
                // positive edge
                DfBit(intrReg).bit0 = 1;
            }else if ( !DfBit(signalPort1).bit0 && DfBit(intrReg).bit6){
                // negative edge
                DfBit(intrReg).bit0 = 1;
            }
        }

        if ( ( DfBit(signalOld).bit1 != DfBit(signalPort1).bit1 )
            && !DfBit(intrReg).bit3
        ){
            // SCA �̐M�����ω������B������ intrB ���荞�݃}�X�N���|�����Ă��Ȃ�
            if ( DfBit(signalPort1).bit1 && DfBit(intrReg).bit5){
                // positive edge
                DfBit(intrReg).bit1 = 1;
            }else if ( !DfBit(signalPort1).bit1 && DfBit(intrReg).bit7){
                // negative edge
                DfBit(intrReg).bit1 = 1;
            }
        }

        signalOld = signalPort1;
    }

    if (DfBit(intrReg).bit0 == 1){
        intrA();
    }
    if (DfBit(intrReg).bit1 == 1){
        intrB();
    }

    return ClStkFrmCntxt::polling();
}


void ClI2C::stopI2cBus(void)
{
    // ack �G���[����������
    wait(55);
    blSDA = false;
    wait(55);
    blSCA = true;
    wait(195);
    blSDA = true;
    wait(195);
    returnFromTaskSub(0);
}
// Error ��������� false ��Ԃ�
bool ClI2C::sendByte(void)
{
    static char chStt;
    // send 8 bit data
    for(chStt=0; chStt<8; chStt++){
        wait(55);
        blSDA = DfBit(m_chSendByteAg).bit7;
        m_chSendByteAg <<= 1;
        wait(55);
        blSCA = true;
        wait(390);
        blSCA = false;
    }

    // recieve _ACK
    wait(55);
    blSDA = true;
    wait(55);
    blSCA = true;
    wait(195);
    if ( DfBit(signalPort1).bit0 ){
        // Ack ���A���Ă��Ȃ�
        wait(195);
        //call( ( int(ClContextWithStack::*)(void) )stopI2cBus);
        call( ( int(ClStkFrmCntxt::*)(void) )stopI2cBus);
        returnFromTaskSub(false);
    }
    wait(195);
    blSCA = false;
    returnFromTaskSub(true);
    return 0;    // damiee instruction to avoid warning
}
// uSec simulation
void ClI2C::task(void)
{
    blSDA = false;                // make I2C start condition
    wait(195);
    m_chSendByteAg = (char)0xb2;  // address
    blSCA = false;                // I2C clock
    //if (!call( ( int(ClContextWithStack::*)(void) )sendByte) ){
    if (!call( ( int(ClStkFrmCntxt::*)(void) )sendByte) ){
        // ack �G���[����������
        return;
    }

    static int inCountStt;
    for(inCountStt=0; inCountStt<m_strTransferData.size(); inCountStt++){
        m_chSendByteAg = m_strTransferData[inCountStt];
        //if (!call( ( int(ClContextWithStack::*)(void) )sendByte) ){
        if (!call( ( int(ClStkFrmCntxt::*)(void) )sendByte) ){
            // ack �G���[����������
            return;
        }
    }
    call( ( int(ClStkFrmCntxt::*)(void) )stopI2cBus);
}

class ClVrfyTestIntr : public ClClMnLpSgltTestVct {
  protected:
    virtual void doAtInitialVl( const string& crStrAg);
};

static ClVrfyTestIntr  clVrfyTestIntrStt;

ClI2C* pClI2CStt;

void setTransferString(const string& crStrAg)
{
    pClI2CStt->m_strTransferData = crStrAg;
    pClI2CStt->Start();
}

void sendText(const string& crStrAg)
{
    for(int i=0; i< crStrAg.size() && i<256 ; i++){
        stReceivedDisplayData.
                chArBufferStt[i] = crStrAg[i];
    }
    stReceivedDisplayData.m_bySizeReceivedData = crStrAg.size();
    dfRequestDfcStt();
}

void ClVrfyTestIntr::doAtInitialVl( const string& crStrAg)
{
    if ( IsSameNocase(crStrAg,"v\\intrI2c.vrf")
      || IsSameNocase(crStrAg,"v\\display.vrf")
      || IsSameNocase(crStrAg,"test.vrf")
    ){
        ClTestVct::doAtInitialVl(crStrAg);
        cout << "Now simulation input file is " << crStrAg << " in intrTask.c" << endl;

        pClI2CStt = new ClI2C;
        tfRgstFnctnStr(this ,setTransferString, "setTransferString");
        tfRgstVerified(this, Port1 ,"Port1");
#if 0
    //01.05.24 coding lefted
        tfRgstMntrVrfy(Port1 ,&clVrfyTestIntrStt ,"Port1");
        registMonitoredNum(Port1IO,"Port1IO");
        registMonitoredNum(signalPort1,"signalPort1");
        registMonitoredNum(
                stReceivedDisplayData.m_byDisplayedChar, "m_byDisplayedChar");;

        registVerifiedNum(*pChStt,"HeadDisp");
        registFunctionStr(sendText,"sendText");
#endif
    }
}
#endif  /* DfVrfy*/
