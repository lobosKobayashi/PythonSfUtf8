/*---------------- Beginning of Simulation -----------------*/
#include <VrfyLib.h>
using namespace std;
using namespace kk;

class ClHmncOsc : public ClVfLibMthd{
    double m_dbPosition;
    double m_dbVelosity;
    double m_dbK;
    // if m_blLeapFlog is false then we caluculate velosity
    bool   m_blLeapFlog;
    double m_dbHalfCycle;
  protected:
    void mainVl(void)
    {
       if ( m_blLeapFlog == false){
            //caluculate velosity
            m_dbVelosity -= m_dbK * m_dbPosition * m_dbHalfCycle * 2;
       }else{
            //caluculate position
            m_dbPosition += m_dbVelosity * m_dbHalfCycle * 2;
       } 
        m_blLeapFlog ^= true;
        Start(ClLongIn(m_dbHalfCycle));
    }

  public:
    ClHmncOsc(double dbCycleAg=0.001, double kAg = 1.0)
        : m_dbK(kAg), m_blLeapFlog(false)
    {
        m_dbHalfCycle = dbCycleAg/2;

        // set -��t/2 �ł̑��x
        m_dbVelosity += m_dbK * m_dbPosition * dbCycleAg / 2;

        Start(ClLongIn(m_dbHalfCycle)); // m_tmCycle = dbPeriodAg/2
    }

    void Register(ClTestVct* pClAg, const string& crStrAg)
    {
        RgstVfMt(pClAg
            , new TcVrfyFp<double>(m_dbPosition, crStrAg+".m_dbPosition", 0.0001)
            , new TcMonitored<double>(m_dbPosition, crStrAg+".m_dbPosition") );
        RgstVfMt(pClAg
            , new TcVrfyFp<double>(m_dbVelosity, crStrAg+".m_dbVelosity", 0.0001)
            , new TcMonitored<double>(m_dbVelosity, crStrAg+".m_dbVelosity") );
        //tfRgstVerified(pClAg, m_dbVelosity, crStrAg+".m_dbVelosity", 0.0001);
    }
};

static ClHmncOsc clHmncOscStt(0.01, 10.0);

class ClTestVctD2 : public ClVfLibActn {
  public:
    ClTestVctD2(const string crStrAg):ClVfLibActn(crStrAg){}
    virtual void doAtInitialVl( const string& crStrAg);
};

ClTestVctD2 clTestVctD2Stt("testTask2");


void ClTestVctD2::doAtInitialVl( const string& crStrAg)
{
    if ( IsSameNocase(crStrAg,"v\\test2.vrf")
      || IsSameNocase(crStrAg,"v\\T2Test.vrf")
    ){
        ClVfLibActn::doAtInitialVl(crStrAg);  // open crStrAg file
        cout << "Now simulation input file is " << crStrAg << " in testTask2.c" << endl;

        clHmncOscStt.Register(&clTestVctD2Stt, "clHmncOscStt");
    }
}
