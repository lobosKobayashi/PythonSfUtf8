// 01.05.24 test singleton and namespace
namespace kkTest{
class ClTest{
  private:
    std::list<int>* m_pLstInt;
    static ClTest* m_pTheClTestStt;
    ClTest(void)
    {
        m_pLstInt = new std::list<int>;
    }
    
 public:
    // Use GetInstanceStt() function name, not GetStt()
    // indicating user to define the singleton instance m_pTheClTestStt.
    static ClTest* GetInstanceStt()
    {
        if ( m_pTheClTestStt == 0){
            m_pTheClTestStt = new ClTest;
        }
        return m_pTheClTestStt;
    }
    void Add(int inAg){ m_pLstInt->push_back(inAg);}
    void Print(void)
    {
        std::ostream_iterator<int> oItrAt(std::cout, " ");
        std::copy(m_pLstInt->begin(), m_pLstInt->end(), oItrAt);
        std::cout << std::endl;
    }
};

}   //namespace kkTest
