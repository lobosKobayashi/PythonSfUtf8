/* _REMOCON interrupt signal processing*/
#include "mntr\IntOOP.h"
#include <string>
using namespace std;

static bool blAtmtnHalfStt = false;    /* 1,0  � decode auto maton State */
    
static TyWord wSharpCodeShifted;
static unsigned char by15bitPointer;

enum { EnINTP0, EnINTTM1 };
#ifdef DfVrfy
    static TyWord wdCode;   // shart code �� simulation �Ŋm�F���邽��
#endif /* DfVrfy */

extern void SetDownTimer(const string& crStrDelayAg);
#define DfStopVal "0mS"
#define DfHalfTVal "500uS"
#define Df1TVal "1mS"
#define Df2TVal "2mS"
#define Df3TVal "3mS"

static void task(struct StIntContext* pStTcbAg_, void* pVdPrmAg)
{
    by15bitPointer= 0; 
    do {
        /* Detect Half of 1/2 T timing */
        wSharpCodeShifted >>= 1;
        SetDownTimer(DfHalfTVal);
        for(;;){
            dfWait(pStTcbAg_);
            if ( pVdPrmAg == (void*)EnINTTM1 ){
                break;
            }
        }

        /* Detect 1T:0 2T:1 bit */
        SetDownTimer(Df1TVal);  // detect end
        dfWait(pStTcbAg_);
        if ( pVdPrmAg == (void*)EnINTP0 ){
            /* detect 1T:0 bit */
            wSharpCodeShifted &= 0x3fff;    /*~(0x4000); 0x00 �ɂȂ�*/
        }else{
            /* now happen INTTM0 1T interrupt, and start to detect 2T:1 bit */
            SetDownTimer(Df1TVal);  // detect end
            dfWait(pStTcbAg_);
            if ( pVdPrmAg == (void*)EnINTP0 ){
                /* detect 2T:1 bit */
                wSharpCodeShifted |= 0x4000;
            }else{
                /* now happen INTTM0 2T interrupt, There is no remcon code.
                 * Start to detect blank bit
                 */
                SetDownTimer(Df3TVal);  // detect end
                for (;;){
                    dfWait(pStTcbAg_);
                    if ( pVdPrmAg == (void*)EnINTTM1 ){
                        SetDownTimer(DfStopVal);
                        dfMakeDormantStt();
                        return;
                    }
                }
            }
        }

         by15bitPointer++;
    }while ( by15bitPointer < 15 );

    SetDownTimer(Df3TVal);  // detect end
    for (;;){
        dfWait(pStTcbAg_);
        if ( pVdPrmAg == (void*)EnINTTM1 ){
            extern void remocon_requestDPC(TyWord wdSharpCodeAg);
#ifdef DfVrfy
            // wRemoIntr_sharpCodeBffr �͂����ɕς��
            wdCode = wSharpCodeShifted;
#endif /* DfVrfyC */
            remocon_requestDPC(wSharpCodeShifted);
        }
        wSharpCodeShifted = 0;
        SetDownTimer(DfStopVal);
        dfMakeDormantStt();
        return;
    }
}

static void rmcnintr_INTP0(void)
{
    if ( dfIsDormantStt() ){
        dfStartStt(task, 0);
    }else{
        if ( blAtmtnHalfStt == true ){
            return;
        }else{
            dfRestartStt( EnINTP0 );
        }
    }
}
            
/********** timer interval interrupt *************************/
void rmcnintr_INTTM1(void)
{
    dfRestartStt( EnINTTM1 );
}

#ifdef DfVrfy
/*---------------- Beginning of Simulation -----------------*/
#include <VrfyRtosPrdc.h>
//#include <VrfyRtos.h>
#include <iostream>

using namespace kk;

#include <VrfyLib.h>

class ClSimInFileRemo : public ClVrfyRtosActnPrdc{
  public:
    ClSimInFileRemo():ClVrfyRtosActnPrdc("remoIntr"){}
    virtual void doAtInitialVl( const string& crStrAg);
};

static ClSimInFileRemo clSimInFileRemo;
void RemoIntr_differed_INTP0(void)
{
    clSimInFileRemo.DifferedInterruptCall(rmcnintr_INTP0);
}

void ClSimInFileRemo::doAtInitialVl( const string& crStrAg)
{
    if ( IsSameNocase(crStrAg,"v\\RemoIntr.vrf") ){
        ClVrfyRtosActnPrdc::doAtInitialVl(crStrAg);  // open crStrAg file
        cout << "Now construct test vector at RemoIntr.c "<< crStrAg << endl;

        RgstVerified(this, tfNewVfFnctnSpl(rmcnintr_INTP0, "rmcnintr_INTP0") );


        // monitor �ϐ����ւ炵�Ă��������̂ŁA�f�o�b�O�ɂ����g��Ȃ� wSharpCodeShifted
        // �͓o�^���Ȃ�
        RgstVerified(this, tfNewVerified(by15bitPointer, "by15bitPointer") );
        RgstVerified(this, tfNewVerified(blAtmtnHalfStt, "blAtmntHalfStt") );
        RgstVerified(this, tfNewVerified(wdCode, "wdCode") );

    }
}

//---------------------------------------------------- 
#endif  /* DfVrfy */




