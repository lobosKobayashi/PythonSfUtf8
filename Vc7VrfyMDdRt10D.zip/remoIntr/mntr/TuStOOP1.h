#ifndef DfTimeupP1OOP_H_
#define DfTimeupP1OOP_H_
#include <timeup.h>
#include <CntxtGrp.h>
/***********************************************************
 * Timeup Stationary task OOP header file  2000,09.08
 * Kenji Kobayashi's copy right
 */

/*------------------- OOP program code Begin--------------------------*/
static struct StGroupVTable const * pStGroupVTableNextTs1Stt__;
static struct StStateDelay stStateDelayTs1Stt__;

#ifdef dfUseDifferedFunctionCall
#   ifndef dfDifferedFunctionCall
#       define dfDifferedFunctionCall differedFunctionCallTs1__
        static void differedFunctionCallTs1__(void);
#   endif /*dfDifferedFunctionCall*/

#   ifndef DfVrtlDfcPollingTs1_
#       define DfVrtlDfcPollingTs1_ pollingTs1_
#   endif /* DfVrtlDfcPollingTs1_ */

    /* dfIsDfcRequested() �� bool �l��Ԃ�*/ 
#   undef dfIsDfcRequesttedStt
#   define dfIsDfcRequesttedStt()  (btDfcRequestTs1==1)

    static void pollingTs1_(void)
    {
        if ( btDfcRequestTs1 ){
            dfDifferedFunctionCall();
            btDfcRequestTs1 = 0;
        }
    }
#else
#   ifndef DfVrtlDfcPollingTs1_
#       define DfVrtlDfcPollingTs1_ DlyState_onlyReturn
#   endif /* DfVrtlDfcPollingTs1_ */
#endif /* dfUseDifferedFunctionCall */


#ifndef DfTimeupFunction
    static void timeup(struct StDelayPcContext* pStCntxtAg, void* pVdPrmAg);
#   define DfTimeupFunction timeup
#endif

static void* pVdArPcTaskTsPrm1__[1];
static const struct StGroupVTable cstVTableTs1Stt__
        = { &stStateDelayTs1Stt__ 
          , DlyState_decrementDelay
          , (struct StDelayPcContext*)0, DfVrtlDfcPollingTs1_
          , TmUp_checkAndExecuteStationary, (void(*)(struct StDelayPcContext*))DfTimeupFunction
          , &pStGroupVTableNextTs1Stt__
          , pVdArPcTaskTsPrm1__ , 1};  /* task parameter size == 1 */

/*------------------- OOP program code End--------------------------*/

#include <undfkuOS.h>

#define dfSetPrmStt( pVdAg)\
        (pVdArPcTaskTsPrm1__[0] = (void*)(pVdAg))
#define dfWhatPrmStt()  (pVdArPcTaskTsPrm1__[0])

#define dfStartStt()\
    (*(int*)&stStateDelayTs1Stt__ = 0x8000)
#define dfDelayedStartStt( wdDelayAg)\
    assert( wdDelayAg >= DfTickUnit_);\
    (*(int*)&stStateDelayTs1Stt__ = (EnDefaultWait*0x1000 + wdDelayAg/DfTickUnit_) )
    
#define dfTaskFnc(taskSample, pVdDamiAg__)\
        void taskSample(struct StDelayPcContext* pStContextAg__, void* pVdDamiAg__)
#define dfTaskEnd

#define dfIsTerminatedStt()\
         DlyState_isTerminated( &(stStateDelayTs1Stt__) )

/* �O������̋����I���̂Ƃ� dfTerminateStt() ���K�v�ƂȂ� */
#define dfTerminateStt()\
         DlyState_terminate( &(stStateDelayTs1Stt__) )

#define dfLinkStt()\
        DlyState_initialize(&stStateDelayTs1Stt__);\
        CntxtGrp_pushback(&cstVTableTs1Stt__)
#define dfUnlinkStt()  CntxtGrp_popback(&cstVTableTs1Stt__)

#define dfWhatDelayTimeStt() DlyState_whatDelay(\
        &(stStateDelayTs1Stt__) )
/* �^�X�N�֐��̒�����Ăяo�� */
#define dfWhatDelayTime() DlyState_whatDelay( pStContextAg__)


#endif /*DfTimeupP1OOP_H_*/
