#ifndef DfFullContextOOP_H_
#define DfFullContextOOP_H_

#include <setjmp.h>
#include <TaskBase.h>

#ifndef dfStackSize
#   if DfVC_
#       define dfStackSize 4000
#   elif defined(Df78K4_)
#       define dfStackSize 512
#   endif
#endif

struct StFullContext {
    struct StTaskBase m_stTaskBase;
#ifdef DfVC_
    enum En86Reg { EnEbp, EnEbx, EnEdi, EnEsi, EnEsp, EnEip, EnRegistration,
        EnTryLevel, EnCokkie,  EnUnwindFunc, EnUnwindData0 };
#endif
    jmp_buf m_jmpTask;
};

void FllCntxt_execute(const struct StGroupVTable* cpStVTableAg);
void FllCntxt_executeTaskLoop(const struct StGroupVTable* cpStVTableAg);
#endif  /* DfFullContextOOP_H_*/


/* ------------- generate OOP code begin ----------------*/
#ifdef dfGnrtFllCntxtCd

#   define dfStTcbArg_ StFullContext

#   define dfFnExecute_ FllCntxt_execute
#   define dfFnLoopingExecute_ FllCntxt_executeTaskLoop

/* �X�^�b�N�� integer alignment ��������@�킪����Bchar* �͎g���Ȃ�*/
static unsigned int dfWdArTaskStackStt_[dfStackSize/sizeof(int)];
#define dfpWdTaskStackBottomStt_ \
        ( dfWdArTaskStackStt_+dfStackSize/sizeof(int) )

#ifdef DfVC_
#   define dfStartStt(pfAg_)\
         DelayCue_erase(&dfCstVTableStt_);\
         dfStTcbStt_.m_jmpTask[StFullContext::EnEip] = (unsigned long)pfAg_;\
         TaskBase_start(&dfCstVTableStt_)
#elif (defined(Df78K4_)
#   define dfStartStt(pfAg_)\
         DelayCue_erase(&dfCstVTableStt_);\
         *(void(**)())(&(dfStTcbStt_.m_jmpTask[11]) ) = pfAg_;\
         TaskBase_start(&dfCstVTableStt_)
#endif

#define dfRestartStt() DelayCue_erase(&dfCstVTableStt_);\
    TaskBase_restart(&dfCstVTableStt_)

/* dfSynStartStt(.) dfSynRestartStt() �́ATCB �� DelayCue �Ƀ����N���Ă���Ƃ� DfTickUnit_
 * �ɗʎq�����ꂽ�������x��ă^�X�N���J�n�E�ĊJ�����܂��B
 */
#ifdef DfVC_
#   define dfSynStartStt(pfAg_)\
         dfStTcbStt_.m_jmpTask[StFullContext::EnEip] = (unsigned long)pfAg_;\
         ReadyCue_start(&dfCstVTableStt_)
#elif (defined(Df78K4_)
#   define dfSyncStartStt(pfAg_)\
         *(void(**)())(&(dfStTcbStt_.m_jmpTask[11]) ) = pfAg_;\
         ReadyCue_start(&dfCstVTableStt_)
#endif

#define dfSyncRestartStt() TaskBase_restart(&dfCstVTableStt_)

#endif /* dfGnrtFllCntxtCd */
/* ------------- generate OOP code end ----------------*/
enum EnmTaskState FllCntxt_wait( TyWord wdDelayAg);
enum EnmTaskState FllCntxt_doTaskPolling( TyWord wdDelayAg);
extern struct StFullContext* pStFullContextStt; /* ���s���^�X�N�� TCB ���w�� */

#define dfLoopingWait(delayAg_)\
        while ( FllCntxt_doTaskPolling( delayAg_) == EnLoopingWait_ )

#define dfWait(delayAg_) FllCntxt_wait(delayAg_)

#define dfBreakLooping()\
        assert( pStFullContextStt!= 0);\
        pStFullContextStt->m_stTaskBase.m_enTaskState = EnRun_;\
        break
        

