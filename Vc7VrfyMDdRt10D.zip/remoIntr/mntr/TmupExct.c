#include <TmUpOOP.h>
//#include <CntxtCue.h>
/* 99.04.09 doAtTimeUp(struct StDelayAndContext*) �� TimeUp_checkAndExecute(.) 
 * �̑�p�ƂȂ�BTimeUp.c �͎g��Ȃ��B
 */
void Timeup_exeute(const struct StGroupVTable* cpStVTableAg)
{
    extern void CntxtCue_loadTaskParameter(const struct StGroupVTable* cpStVTableAg, void** ppInPrmAg);
    extern void CntxtCue_restoreTaskParameter(const struct StGroupVTable* cpStVTableAg, void** ppVdPrmAg);

    assert ( cpStVTableAg->m_pStTaskBase->m_blReady == true );
    if (cpStVTableAg->m_pStTaskBase->m_blReady == true){
        switch (cpStVTableAg->m_pStTaskBase->m_enTaskState){
        case EnTimeup_:
        case EnRestart_:
            void* pVdArDamieAt[3];

            /* EnRun_ ��Ԃɂ��邱�ƂŊ��荞�݋֎~��Ԃ��p������*/
            *(int*)(cpStVTableAg->m_pStTaskBase) = EnRun_ * 0x1000;
            CntxtCue_loadTaskParameter(cpStVTableAg, pVdArDamieAt);
            /* time up ���Ɏ��s����悤�� StGroupVTable �ɓo�^�����֐����Ăяo�� */
            cpStVTableAg->m_pfExecute(
                /* �֐��v���g�^�C�v�����킹�邽�߂ɃL���X�e�B���O����B���ۂɎg���̂�
                 * StTaskBase* �ł���
                 */
                (struct StGroupVTable*)cpStVTableAg->m_pStTaskBase
            );
            CntxtCue_restoreTaskParameter(cpStVTableAg, pVdArDamieAt);
    
            if ( cpStVTableAg->m_pStTaskBase->m_enTaskState == EnRun_ ){
                *(int*)(cpStVTableAg->m_pStTaskBase) = 0;
            }
        }
    }
}

void Timeup_wait(struct StTaskBase** ppStCntxtAg, TyWord wdDelayAg)
{
    extern void TaskBase_setDelay(struct StTaskBase* pStTaskBaseAg, enum EnmTaskState enAg, TyWord wdDelayAg);
    
    assert( (wdDelayAg/DfTickUnit_) <= 0xfff);
    assert( (*ppStCntxtAg)->m_enTaskState == EnRun_);
    TaskBase_setDelay( *ppStCntxtAg, EnWait_, wdDelayAg);
}

