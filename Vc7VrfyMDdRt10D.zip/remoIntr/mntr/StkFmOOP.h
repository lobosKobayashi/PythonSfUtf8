#ifndef DfTTaskStackFrameOOP_H_
#define DfTTaskStackFrameOOP_H_

#include <FrmCntxt.h>
#include <FrmTkDf.h>

#define dfStTcbArg_ StStckFrmContext

#define dfFnExecute_ FrmCntxt_execute
#define dfFnLoopingExecute_ FrmCntxt_executeTaskLoop

#ifndef dfTaskStackSize
#   define dfTaskStackSize 10
#endif

/* Stack �ɂ� integer alignment ��������@�킪����̂� unsigned char ���g��Ȃ�*/
static unsigned int dfWdArTaskStackStt_[dfTaskStackSize/sizeof(int)];
#define dfpWdTaskStackBottomStt_ \
        ( dfWdArTaskStackStt_+dfTaskStackSize/sizeof(int) )

/*--------------------task control macro begin -------------------------------*/
#define dfReturnValue(inRetAg) FrmCntxt_returnWithValue(inRetAg)
#define dfCall( pfAg) \
            FrmCntxt_call( (int(*)(struct StStckFrmContext* )) pfAg)
#define dfPush( pVdAg__ ) FrmCntxt_push( pVdAg__)
#define dfPop( pVdAg__ )  FrmCntxt_pop( pVdAg__)

/* M50 �𓮍삳���邽�߂̓��ʂ̃^�X�N�֐��Ăяo�� */
extern void key_initTaskStack( void );
#define dfInitCall( pfAg) \
            key_initTaskStack();\
            FrmCntxt_call( (int(*)(struct StStckFrmContext* )) pfAg)

#endif  /* DfTTaskStackFrameOOP_H_*/
