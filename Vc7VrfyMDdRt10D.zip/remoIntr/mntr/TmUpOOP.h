#ifndef DfTimeupOOP_H_
#define DfTimeupOOP_H_

//#include <TmupExct.h>
#include <CntxtCue.h>
#include <TaskBase.h>
void Timeup_exeute(const struct StGroupVTable* cpStGroupAg);
void Timeup_wait(struct StTaskBase** ppStCntxtAg, TyWord wdDelayAg);
#endif  /* DfTimeupOOP_H_*/

/*------------------------ gegerate OOP code ----------------------------*/
#ifdef dfGnrtTmupCdInvlvFnctn
#   define dfStTcbArg_ StTaskBase

#   define dfFnExecute_ dfGnrtTmupCdInvlvFnctn
#   define dfFnLoopingExecute_ 0


#   define dfpWdTaskStackBottomStt_ 0

#   define dfStTcbArg_ StTaskBase

/*---------------- static TCB �ϐ��������Ƃ���^�X�N����֐��}�N�� begin ---------*/
#   define dfDelayedStartStt(delayAg_)\
         TaskBase_setDelay(&dfStTcbStt_, EnWait_, delayAg_);\
         DelayCue_pushFront(&dfCstVTableStt_);

/*---------------- static TCB �ϐ��������Ƃ���^�X�N����֐��}�N�� end ---------*/
#endif  /*dfGnrtTmupCdInvlvFnctn*/

