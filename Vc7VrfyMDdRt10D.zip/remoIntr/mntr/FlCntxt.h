#ifndef DfFullContext_H_
#define DfFullContext_H_
#include <DlyState.h>
#include <CntxtGrp.h>

#ifdef DfVC_
#   include <setjmp.h>
#   include <assert.h>
#elif defined( Df78K4_ )
#   include "ksetjmp.h"
/*#   include <setjmp.h>*/
#endif

/* StStackAndContext �� StDelayPcContext �ɃL���X�e�B���O��������
 * PcCntxt.h �̋@�\���g��
 */
struct StFullContext{
    jmp_buf jumpBuffer;
    struct StStateDelay m_stStateDelay;
};

/*------------------****** global functions *****-------------------------*/
/* TCB �𐧌䂷���{�֐�*/
void flCntxt_setStackAndStartAddress(struct StTCB *pStTCB
                 ,int *piTaskStackBottomAddress,void (*pfTaskFunctionStart)());
void flCntxt_wait(TyWord delayValue);
void flCntxt_restart(struct StFullContext*);
void flCntxt_terminate(struct StTCB *pStTCB);

#if 0
void taskCB_sleep(struct StTCB *pStTCB );
void taskCB_independentFunction( struct StTCB *pStTCB,
void taskCB_notContextTerminate(struct StTCB *pStTCB);/*F10amp �ł͖��g�p*/
/* TCB �𕡍����䂷��֗��Ȋ֐�*/
void taskCB_continueWaitWithPolling( struct StTCB *pStTCB);
void taskCB_waitWithPolling(struct StTCB *pStTCB,
/* TCB �̏�Ԃ𒲂ׂ�֐�*/
bitReturn void taskCB_checkDelay( struct StTCB *pStTCB );
void taskCB_clearDelay( struct StTCB *pStTCB );
TyWord taskCB_getDelay( struct StTCB *pStTCB );
bitReturn void taskCB_checkDormant( struct StTCB *pStTCB );
#endif







int StkCntxt_call(struct StStackAndContext** ppStCntxtAg, int (*pfAg)(struct StStackAndContext* ) );
void StkCntxt_push(struct StStackAndContext** ppStCntxtAg, void* pVdAg);
void StkCntxt_pop(struct StStackAndContext** ppStCntxtAg, void** ppVdAg);
void StkCntxt_returnWithValue(struct StStackAndContext** ppStCntxtAg, int inRetValueAg);

#endif /*DfFullContext_H_*/

