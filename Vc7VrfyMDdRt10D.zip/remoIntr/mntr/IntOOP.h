#ifndef DfIntContextOOP_H_
#define DfIntContextOOP_H_
#include <common.h>
#include <uOsCnst.h>
struct StIntContext {
    void (*m_pTimeUpAddress)( struct StDelayPcContext*);
#ifdef H8
    /* 99.03.31 code lefted */
#endif
#ifdef Df78K4_
    /*sp-hl ���ꂪ�Ȃ��ƁAcontext �؂�ւ��̌�� subroutine call �� 
     *auto variable ������
     */
    int m_ppStCntxt_sp;    
    /*int m_sp_hl;    */
#elif defined( DfVC_)
    // VC task context
    int m_ppStCntxt_sp;
    int m_inEBX;
    int m_inESI;
    int m_inEDI;
#endif
};

extern void IntCntxt_startImmediately( struct StIntContext* pStAg
        , void(*pfAg)(struct StIntContext*, void*), void* pVdStartAg);
extern void IntCntxt_restartImmediately( struct StIntContext* pStIntContextAg, void* pVdRestartAg);
extern void IntCntxt_suspend( struct StIntContext** ppStIntContextAg);
#endif  /* DfIntContextOOP_H_*/


#define dfStIntContextSttBff_(x) dfStIntContextStt__##x##_
#define dfStIntContextN_(x) dfStIntContextSttBff_(x)
#define dfStIntContextStt_ dfStIntContextN_(dfN)

static struct StIntContext dfStIntContextStt_;

#include <undfkuOS.h>

#undef dfStartStt
#undef dfRestartStt
#undef dfWait
#undef dfMakeDormantStt
#undef dfIsDormantStt

#define dfStartStt( pfAg, pVdAg)\
    IntCntxt_startImmediately( &dfStIntContextStt_,\
        (void(*)(struct StIntContext*, void*))(pfAg), (void*)pVdAg)
#define dfRestartStt( pVdAg)\
    assert((int)dfStIntContextStt_.m_pTimeUpAddress != 0);\
    IntCntxt_restartImmediately( &dfStIntContextStt_, (void*)pVdAg);

/* task( struct StDelayPcContext* pStIntContextAg__, void* pVdAg) ��
 * pStIntContextAg  pVdAg ��̈������� task(.) ������ */
#define dfWait(pStTcbAg_) IntCntxt_suspend( &pStTcbAg_ )
#define dfMakeDormantStt() (dfStIntContextStt_.m_pTimeUpAddress = 0)
#define dfIsDormantStt() (dfStIntContextStt_.m_pTimeUpAddress == 0)

#ifdef Df78K4_
#    define dfSetStackFrame(pStTcbAg_, pVdAg_)\
        pStTcbAg_->m_ppStCntxt_sp = \
        (int)((int)&pVdAg_ - (int)&pStTcbAg_)
#else
#    define dfSetStackFrame(pStTcbAg_, pVdAg_)
#endif  /* Df78K4_ */

