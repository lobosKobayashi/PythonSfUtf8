#ifndef DfStackInterruptTask_H_
#define DfStackInterruptTask_H_

#include <uOsCnst.h>
#include <IntCntxt.h>

struct StIntStackCntxt {
    void (*m_pTimeUpAddress)( struct StIntStackCntxt*,void*);
#ifdef DfVC_
    // VC task context
    int m_ppStCntxt_sp;
    int m_inEBX;
    int m_inESI;
    int m_inEDI;
#elif defined(Df78K4_)
    int m_ppStCntxt_sp;
#endif
    void*               m_pVdPrm;     /* parameter ��ǉ����� */
    unsigned char*      m_pByStack;
};

/* m_pByStack �v�f���}�X�N���� StIntStackCntxt ���R�s�[���邽�߂�
 * struct StIntCntxtVdPrmDamie �\���̌^�����
 */
struct StIntCntxtDamie {
    void (*m_pTimeUpAddress)( struct StIntStackCntxt*, void*);
#ifdef DfVC_
    // VC task context
    int m_ppStCntxt_sp;
    int m_inEBX;
    int m_inESI;
    int m_inEDI;
#elif defined(Df78K4_)
    int m_ppStCntxt_sp;
#endif
    void*               m_pVdPrm;     /* parameter ��ǉ����� */
};

void IntCntxt_startImmediately( struct StIntContext* pStAg
        , void(*pfAg)(struct StIntContext*, void*), void* pVdAg);
void IntCntxt_restartImmediately( struct StIntContext* pStIntContextAg, void* pVdRestartAg);
void SkIntCnt_setCallPrm(struct StIntStackCntxt** ppStIntStackCntxtAg
        ,int(*pfAg)(struct StIntStackCntxt*, void*), void* pVdAg );

void SkIntCnt_returnFromTaskSub( struct StIntStackCntxt** ppStAg);
int SkIntCnt_call( struct StIntStackCntxt** ppStAg);

#endif /*DfStackInterruptTask_H_ */
