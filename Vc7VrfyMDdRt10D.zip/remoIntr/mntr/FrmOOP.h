#ifndef DfTFrameOOP_H_
#define DfTFrameOOP_H_

#include <FrmCntxt.h>

#include <FrmTkDf.h>

#define dfStTcbArg_ StFrameContext

#define dfpByTaskStackBottomStt_ 0
#define dfpWdTaskStackBottomStt_ 0

#define dfFnExecute_ FrmCntxt_execute
#define dfFnLoopingExecute_ FrmCntxt_executeTaskLoop


#endif  /* DfTFrameOOP_H_*/
