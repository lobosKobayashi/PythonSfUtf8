#ifndef DfIntContext_H_
#define DfIntContext_H_
#include <common.h>
#include <uOsCnst.h>
struct StIntContext {
    void (*m_pTimeUpAddress)( struct StDelayPcContext*);
#ifdef H8
    /* 99.03.31 code lefted */
#endif
#ifdef Df78K4_
    /*sp-hl ���ꂪ�Ȃ��ƁAcontext �؂�ւ��̌�� subroutine call �� 
     *auto variable ������
     */
    int m_ppStCntxt_sp;    
    /*int m_sp_hl;    */
#elif defined( DfVC_)
    // VC task context
    int m_ppStCntxt_sp;
    int m_inEBX;
    int m_inESI;
    int m_inEDI;
#endif
};

extern void IntCntxt_startImmediately( struct StIntContext* pStAg
        , void(*pfAg)(struct StIntContext*, void*), void* pVdStartAg);
extern void IntCntxt_restartImmediately( struct StIntContext* pStIntContextAg, void* pVdRestartAg);
extern void IntCntxt_suspend( struct StIntContext** ppStIntContextAg);



#endif  /* DfIntContext_H_*/

