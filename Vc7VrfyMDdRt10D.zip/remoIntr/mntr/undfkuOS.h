#   undef DfTaskOOP_H_
#   undef dfNmTaskParameterSize   /* Max 4 */
#   undef DfBlUseLoopingWait

#   undef dfGnrtTmupCdInvlvFnctn
#   undef dfGnrtDynPllngCdInvlvFnctn
#   undef dfGnrtFrmCntxtCd
#   undef dfGnrtTskStckFrmCntxtCd
#       undef DfTaskStackSize
#   undef dfGnrtFllCntxtCd

#   undef dfStTcbSttBff_
#   undef dfStTcbSttN_
#   undef dfStTcbStt_

#   undef dfpStGroupVTableNextSttBff_
#   undef dfpStGroupVTableNextSttN_
#   undef dfpStGroupVTableNextStt_

#   undef dfpStGroupLoopingNextSttBff_
#   undef dfpStGroupLoopingNextSttN_
#   undef dfpStGroupLoopingNextStt_

#   undef dfCstVTableSttBff_
#   undef dfCstVTableSttN_
#   undef dfCstVTableStt_

#   undef dfWdArTaskStackSttBff_
#   undef dfWdArTaskStackSttN_
#   undef dfWdArTaskStackStt_

#   undef dfpWdTaskStackBottomStt_

#   undef dfStTcbArg_
#   undef dfFnExecute_
#   undef dfFnLoopingExecute_
#   undef dfpByTaskStackBottomStt_

#   undef dfStackSize

#   undef dfSetPrmStt
#   undef dfWhatPrmStt
#   undef dfStartStt
#   undef dfDelayedStartStt
#   undef dfRestartStt
#   undef dfCall
#   undef dfWait
#   undef dfIsDefaultWaitStt
#   undef dfIsDefaultRestartStt
#   undef dfFunction
#   undef dfTaskFnc
#   undef dfIsDormantStt
#   undef dfMakeDormantStt
#   undef dfLinkStt
#   undef dfUnlinkStt
#   undef dfLoopEnd
#   undef dfBreakLoop
#   undef dfDoLoopTimeup    // dfLoopingWait
#   undef dfAtLoopTimeup
#   undef dfWhatDelayTimeStt
#   undef dfWhatDelayTime
#   undef dfReturnVoid
#   undef dfReturnValue
#   undef dfWhatFirstAddressStt
#   undef dfSuspend
#   undef dfSetStartAddressInStack
#   undef dfInitializeStack
#   undef dfTaskEnd
#   undef dfPush
#   undef dfPop
#   undef dfTaskFncDeclare

#   undef dfNumStackNestingLevel

