#include <VrfyThrd.h>

using namespace std;
using namespace kk;

//--------------- call 10mSec interval interrupt begin -----------
//        string strAtStt("10mS");
class Cl10mSecIntervalTask: public ClVrfyThrd{
  public:
    Cl10mSecIntervalTask(void){ Start();}
  protected:
    virtual void mainVl(void)
    {
        for(;;){
            if ( IsTerminated() ){
                break;
            }
            extern void interrupt_10mSecInterval(void);
            Wait(TyTime(10, k_mS));    // 10mSec delay
            //Wait(TyTime(strAtStt));    // 10mSec delay
            interrupt_10mSecInterval();
        }
    }  
};
static Cl10mSecIntervalTask cl10mSecIntervalTaskStt;

//--------------- call 10mSec interval interrupt end -----------

//--------------- Down Count Timer begin -----------
void SetDownTimer(const string& crStrDelayAg);
class ClDownTimer: public ClVrfyThrd{
#if 0
    TyTime m_tmDelay;
  protected:
    bool polling(void)
    {
        if (m_strArg == "0mS"){
            Terminate();
        }else{
            Start(m_strArg);
        }
        return true;
    }
#endif
  public:
    virtual void mainVl(void)
    {
        extern void rmcnintr_INTTM1(void);
        //Wait(m_tmDelay);
        rmcnintr_INTTM1();
//        m_tmDelay = TyTime(m_strArg);
    }
};

static ClDownTimer clDownTimerStt;

class ClDamie: public ClVrfyThrd{
    string m_strArg;
  public:
    virtual void mainVl(void)
    {
        clDownTimerStt.Terminate();
        if (m_strArg != "0mS"){
            clDownTimerStt.Start(TyTime(m_strArg) );
        }
    }
    friend void SetDownTimer(const string& crStrDelayAg);
} clDamieStt;

void SetDownTimer(const string& crStrDelayAg)
{
    clDamieStt.m_strArg = crStrDelayAg;
    clDamieStt.Start();
}
//--------------- Down Count Timer end -----------
//--------------- Remocon interrupt generator begin -----------
void StartRemoconInterrupt(int inCodeAg);
bool blSgnlStt;
class ClRemoIntr: public ClVrfyThrd{
    int m_inCode;   // 15th MSB first. ignore 16th MSB
  public:
    virtual void mainVl(void)
    {
        extern void RemoIntr_differed_INTP0(void);
        RemoIntr_differed_INTP0();
        for(int i=0; i<15;i++){
            if ( m_inCode & 0x01 ){
                Wait(TyTime(1500, k_uS));    // 2T PPM
                blSgnlStt = true;
                Wait(TyTime(500, k_uS));
                blSgnlStt = false;
            }else{
                Wait(TyTime(500, k_uS));    // 1T PPM
                blSgnlStt = true;
                Wait(TyTime(500, k_uS));
                blSgnlStt = false;
            }
            RemoIntr_differed_INTP0();
            m_inCode >>= 1;
        }
    }
    friend void StartRemoconInterrupt(int inCodeAg);
};

static ClRemoIntr clRemoIntrStt;
void StartRemoconInterrupt(int inCodeAg)
{
    clRemoIntrStt.m_inCode = inCodeAg;
    clRemoIntrStt.Start();
}
//--------------- Down Count Timer end -----------

class ClTestTask4: public ClVrfyThrd{
  protected:
    virtual void mainVl(void);  
};

//static ClTestTask4 clTestTask4Stt;
ClTestTask4 clTestTask4Stt;

static unsigned char portStt;

void ClTestTask4::mainVl(void)
{
    int inAt=3;
    Wait(TyTime(3100, k_mS));
    inAt += 4;
    while ( LoopingWait(TyTime(5, k_S) ) == EnLoopingWait){
        if ( portStt == 0x03){
            //coding lefted 01.06.11 abolishLoopingDelay() �ɕς���
            //KuoSoC ���ƈꏏ�ɕύX����
            //01.07.22 abolishLoopingDelay() �ł͂Ȃ� breakLoopingWait();�ɂ���
            // �^�X�N�� EnRestart ��Ԃɂ��āA���̃��C���E���[�v�� EnRestart ��
            // EnLoopingWait �ł͂Ȃ��Ȃ�
            //   == EnLoopingWait ���]���ł���B���[�U�ɂƂ��Ă͖߂�l��
            //   Yes/No �����ő����̏ꍇ�\���ł��B�K�v�Ȃ�΁A���̌��
            //   �R�[�h�� IsTimeup() �Ȃǂ��g���Ē��ׂ܂�
            m_enTaskState = EnRun;
            break;
        }
    }
    inAt = 2;
    Wait(TyTime(2010, k_mS));
}

/*---------------- Beginning of Simulation -----------------*/
#ifdef DfVrfy

class ClTestVctD4: public ClVrfyThrdActn{
  public:
    ClTestVctD4():ClVrfyThrdActn("xxx"){}

    
    virtual void doAtInitialVl(const string& crStrAg);
};
static ClTestVctD4 clTestVctD4Stt;

static void start(void)
{
    clTestTask4Stt.Start();
}

static void restart(void)
{
    clTestTask4Stt.Restart();
}

static void terminat(void)
{
    clTestTask4Stt.Terminate();
}

void ClTestVctD4::doAtInitialVl(const string& crStrAg)
{
    if ( IsSameNocase(crStrAg,"test.vrf")
      || IsSameNocase(crStrAg,"v\\TestTsk4.vrf")
    ){
        ClVrfyThrdActn::doAtInitialVl(crStrAg);
        //cout << "Now simulation input file is " << crStrAg << " in testTsk4.c" << endl;
    
        //tfRgstVerified(this, portStt, "port");
        RgstVerified(this, tfNewVfFnctnSpl(start, "start") );
        RgstVerified(this, tfNewVfFnctnSpl(terminat, "terminat") );

        RgstVfMt(this
                , tfNewVerified(portStt, "port")
                , tfNewMonitored(portStt, "port"));
        RgstVfMt(this
                , tfNewVerified(blSgnlStt, "blSgnlStt")
                , tfNewMonitored(blSgnlStt, "blSgnlStt"));
    }
}

#endif  /* DfVrfy*/
