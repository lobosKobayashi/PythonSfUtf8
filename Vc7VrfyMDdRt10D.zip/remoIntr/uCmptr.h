#ifndef DfMicroComputer_H_
#define DfMicroComputer_H_
#include "common.h"
/*************************************************************************
 *              78K0 �v���O�������ʃw�b�_
 *  �S�Ẵv���O�����E���W���[���ɋ��ʂȌ^���`����B
 *�@�v���O�����S�̂Ŏg�p����P��̏ȗ��`�ƁA���� full spell �̈ꗗ�\������
 ************************************************************************/
/* bit �^�ϐ��ɂ��g�p����*/
enum EnBool {EnNo, EnYes, EnOff=0, EnOn, EnLow=0, EnHigh, EnDown=0,EnUp};
enum En3Value { EnCenter, En3Down=-1, En3Up=1, En3No=0, En3Yes=1, EnError=-1};
enum {EnBit0 = 0x01, EnBit1 = 0x02, EnBit2 = 0x04, EnBit3 = 0x08,
    EnBit4 = 0x10, EnBit5 = 0x20, EnBit6 = 0x40, EnBit7 = 0x80
};

#define bitReturn               /* btRtn �ɕԋp�l������ĕԂ��֐�������*/

typedef unsigned char TyBool;   /* yes,no �̂Q�l�����ϐ��^�������B       */
                                /* �ϐ��̍ŏ��ɁA�^������"bl"�̃v���t�B�b�N*/
                                /* �t����B                             �@ */

#ifdef DfVC_
#include <assert.h>

#   define VcStatic
#   define sfr
#   define interrupt
#   define boolean unsigned char   /* boolean �� 78k0 �ł̂ݎg�p����*/
#   define callt
#   define DisableInterrupt()
#   define EnableInterrupt()

/*#   define TyEnum enum*/
#   define staticN static
#   define constN const
#   define DfSregByte struct StBit
/*#   define boolean enum EnBool*/          /* H8 ��������Ȃ� */
#   define norec 
#   define sreg
#   define __sreg1
#   define iram
    extern bit btRtn;               /* inline.c �ɋL�q���Ă���*/
#   define DfStatic static

    /** HREF <A HREF="htm\soft.htm#sfr��I/O"> */
#   if 1
    extern /*sreg*/ TyByte P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13;  /*ff00--ff0d*/
    extern /*sreg*/ TyWord TM0, CR00, CR01;
    extern /*sreg*/ TyByte TMC0, dm1, TOC0, dm2;                   /*ff10--ff1d*/
    extern /*sreg*/ TyByte PRM0, damie3;
    extern /*sreg*/ TyWord  damie4;

    extern TyByte PM0,PM1,PM2,PM3;                                     /*ff20--    */
    extern TyByte PM4;
    extern TyByte PM5,PM6,PM7;                                         
    extern TyByte PM8,PM9;
    extern TyByte PM10,PM11,PM12,PM13;                                 /*    --ff2d*/
    extern TyByte PU0, damie13,PU2, damie14,PU3, PU7,PU8;
    extern TyByte damie15 , PU10,PU12;                                 /*    --ff3c*/

    extern TyByte CKS, damie19, PF2, damie20, damie21,damie22, damie23, damie24;
    extern TyByte PUO, damie31;                                         /*0xfff3a*/
    extern TyByte TM1,TM2, CR10, CR20,   TMC1, TMC2, PRM1, PRM2;       /*0xfff50--57*/

    extern TyByte TM5,TM6,TM7,TM8, CR50,CR60,CR70,CR80;                /*0xfff60 -- */
    extern TyByte TMC5,TMC6,TMC7,TMC8, PRM5,PRM6,PRM7,PRM8;            /* -- 0xfff6f*/

    #define RXB1 TXS1
    #define RXB2 TXS2
    extern TyByte ASIM1,ASIM2,ASIS1,ASIS2, TXS1,TXS2,BRGC1,BRGC2;
    extern TyByte CC;                                                  /*0xfff7A*/

    extern TyByte ADM,ADIS,damie46,ADCR, DACS0, DACS1,DAM0,DAM1;       /* -- 0xfff87*/
    extern TyByte EBTS;                                                /* 0xfff8c */

    extern TyByte CSIM0,CSIM1,CSIM2,damie54, SIO0,SIO1,SIO2,damie55;   /*0xfff90 -- */
    extern TyByte RTBL,RTBH,RTPM, RTPC, WTM,damie56,damie57,damie58;   /* -- 0xfff9f*/

    extern TyByte EGP0,damie59,EGN0,damie60;                           /*0xfffa0 -- */
    extern TyByte ISPR,SNMI,IMC,damie65, MK0L,MK0H,MK1L,MK1H;          /* -- 0xfffaf*/
    extern TyByte IICC0,damie66,SPRM0,damie67, SVA0,damie68,IICS0,damie69;
    extern TyByte IIC0,damie70,damie71,damie72, damie73,damie74,damie75,damie76;

    extern TyByte STBC,damie77,WDM,damie78, MM,damie79,damie80,PWC1;
    extern TyByte PCS,OSTS;

    extern TyByte WDTIC,PIC0,PIC1,PIC2, PIC3,PIC4,PIC5,PIC6;
    extern TyByte CSIIC0,SERIC1,SRIC1,STIC1, SERIC2,SRIC2,STIC2,TIIC3;

    extern TyByte TMIC00,TMIC01,TMIC1,TMIC2, ADIC,TMIC5,TMIC6,TMIC7;
    extern TyByte TMIC8,WTIC,KRIC,damif03, IMS,damif04,damif05,damif06;

#endif  //0
#else
#define VcStatic static
#endif


#ifdef Df78K4_
enum { false=0, true };

#   define DfBool boolean
#   define DfTrue 1
#   define DfFalse 0

    /* bit field �ϐ��𑼂̌���ł��g����悤�ɂ��邽�� */
/*    typedef unsigned char TyEnum;*/
#   define staticN /* bit, boolean �ϐ��� static �ɂł��Ȃ����� */
#   define constN  /*compiler bug �΍� typedef �Ƒg�ݍ��킹���Ƃ�*/
#   define DfSregByte sreg TyByte
/*#   define EnBool*/
#   define En3Value
    /*register �ϐ��� SRAM �̈���g���Ȃ� */
#   define register
#   define assert(x)    /* assert ���������ύX����*/

#   define bit0 0
#   define bit1 1
#   define bit2 2
#   define bit3 3
#   define bit4 4
#   define bit5 5
#   define bit6 6
#   define bit7 7

#   define DfBit(x) ( x )   /* for sreg variable*/
#   define iram sreg
#   define DfExtern
#   define DfStatic         /*78K0 compiler �� static bit ���`�ł��Ȃ�*/
    extern bit btRtn;
#endif

extern sreg char commonWork[16];
#define work0 (commonWork[0])
#define work1 (commonWork[1])
#define work2 (commonWork[2])
#define work3 (commonWork[3])
#define work4 (commonWork[4])
#define work5 (commonWork[5])
#define work6 (commonWork[6])
#define work7 (commonWork[7])
#define work8 (commonWork[8])
#define work9 (commonWork[9])




#endif /*DfMicroComputer_H_ */


