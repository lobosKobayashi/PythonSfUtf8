#include "inc\common.h"
/***************************/
/*  Timer interrupt object */
/***************************/
extern void dnn_tic500uSec(void); /* in DENON OBJECT */

/* timer buffer. MSB ��10mSec�o�߃t���O�Ƃ���B*/
static iram TyByte byTimer10mSec;
static bit btTimeUp;

#ifdef H8
    interrupt [0x1e]    /* Timer E interrupt vector */
#endif
void timer_interrupt()
{
    extern void SCI2_500uSec(void);
    extern iram TyByte IRR2;

    dnn_tic500uSec(); /* to DENON BUS Object*/
    SCI2_500uSec();
    /* 512uSec �����̊��肱�ݏ������L�q����B*/
    if( ++byTimer10mSec > 20 ){
        byTimer10mSec -= 20;
        btTimeUp = EnYes;
    }
    DfBit(IRR2).bit4 = EnOff;   /* clear Timer E interrupt request bit */
}

enum EnBool timer_isTimeUp10mSec(void)
{
#ifdef TURBOCNotUsed
/* Debug in PC98 � �� � ӳ�١ */
    static TyWord wdCount;
    if( ++wdCount >= 10){  /* wdCount � loop counter � �١ > 10 � ��� � ����� ��*/
        wdCount = 0;
        btTimeUp = EnYes;
    }
#endif    
    if (btTimeUp){
        btTimeUp = EnNo;
        return EnYes;
    }else{
        return EnNo;
    }
}

/************* timer initilize routine *******************/
/* constructor */
void timerIntr(void)
{
    extern iram TyByte IRR2, TME, IENR2;
    extern iram TyByte TLE;
    
    DfBit(IRR2).bit4 = EnNo; /* clear IRRTE ; Timer E interrupt request flag*/
    TME = 0x86;     /* auto reload, Phai/32: 131KHz: 7.64uSec */
    *(char*)&TLE =  -67;     /* 512 uSec interval */
    DfBit(IENR2).bit4 = EnYes; /* IENTE  of H8; Enable Timer E interrupt */
}

        
#ifdef TURBOC
EnBool TimeIntr_is10mSecTime0()
{
    return byTimer10mSec ? EnNo: EnYes;
}
#endif
    

/*@@@*/
/*copy #####.### tst.c*/
/*c:\borlandc\bin\bcc @c:\hekm\tst.inc -ms -c -v -rd -H -DTURBOC -otimeintr.obj c:\Hekm\dx\tst.c */

